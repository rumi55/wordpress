# WordPress MySQL database backup
#
# Generated: Thursday 28. November 2013 13:22 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_commentmeta`
#
 
INSERT INTO `wp_commentmeta` VALUES (1, 1, 'akismet_history', 'a:4:{s:4:"time";d:1385480633.0470368862152099609375;s:7:"message";s:49:"admin a changé le statut du commentaire en trash";s:5:"event";s:12:"status-trash";s:4:"user";s:5:"admin";}'); 
INSERT INTO `wp_commentmeta` VALUES (2, 1, '_wp_trash_meta_status', '1'); 
INSERT INTO `wp_commentmeta` VALUES (3, 1, '_wp_trash_meta_time', '1385480633');
#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_comments`
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Monsieur WordPress', '', 'http://wordpress.org/', '', '2013-11-15 13:54:16', '2013-11-15 13:54:16', 'Bonjour, ceci est un commentaire.\nPour supprimer un commentaire, connectez-vous et affichez les commentaires de cet article. Vous pourrez alors les modifier ou les supprimer.', 0, 'trash', '', '', 0, 0);
#
# End of data contents of table `wp_comments`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=497 DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_options`
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost/wordpress', 'yes'); 
INSERT INTO `wp_options` VALUES (2, 'blogname', 'Save My Smartphone', 'yes'); 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', 'Nous sauvons vos smartphones et tablettes', 'yes'); 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes'); 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'damien@savemysmartphone.fr', 'yes'); 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes'); 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '0', 'yes'); 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes'); 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes'); 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes'); 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes'); 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes'); 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes'); 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes'); 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes'); 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes'); 
INSERT INTO `wp_options` VALUES (17, 'default_category', '1', 'yes'); 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'open', 'yes'); 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'open', 'yes'); 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '1', 'yes'); 
INSERT INTO `wp_options` VALUES (21, 'posts_per_page', '10', 'yes'); 
INSERT INTO `wp_options` VALUES (22, 'date_format', 'j F Y', 'yes'); 
INSERT INTO `wp_options` VALUES (23, 'time_format', 'G \\h i \\m\\i\\n', 'yes'); 
INSERT INTO `wp_options` VALUES (24, 'links_updated_date_format', 'j F Y G \\h i \\m\\i\\n', 'yes'); 
INSERT INTO `wp_options` VALUES (25, 'links_recently_updated_prepend', '<em>', 'yes'); 
INSERT INTO `wp_options` VALUES (26, 'links_recently_updated_append', '</em>', 'yes'); 
INSERT INTO `wp_options` VALUES (27, 'links_recently_updated_time', '120', 'yes'); 
INSERT INTO `wp_options` VALUES (28, 'comment_moderation', '0', 'yes'); 
INSERT INTO `wp_options` VALUES (29, 'moderation_notify', '1', 'yes'); 
INSERT INTO `wp_options` VALUES (30, 'permalink_structure', '/%postname%/', 'yes'); 
INSERT INTO `wp_options` VALUES (31, 'gzipcompression', '0', 'yes'); 
INSERT INTO `wp_options` VALUES (32, 'hack_file', '0', 'yes'); 
INSERT INTO `wp_options` VALUES (33, 'blog_charset', 'UTF-8', 'yes'); 
INSERT INTO `wp_options` VALUES (34, 'moderation_keys', '', 'no'); 
INSERT INTO `wp_options` VALUES (35, 'active_plugins', 'a:8:{i:0;s:19:"akismet/akismet.php";i:1;s:36:"contact-form-7/wp-contact-form-7.php";i:2;s:43:"google-analyticator/google-analyticator.php";i:3;s:9:"hello.php";i:4;s:41:"responsive-add-ons/responsive-add-ons.php";i:5;s:33:"seo-automatic-links/seo-links.php";i:6;s:24:"wordpress-seo/wp-seo.php";i:7;s:29:"wp-db-backup/wp-db-backup.php";}', 'yes'); 
INSERT INTO `wp_options` VALUES (36, 'home', 'http://localhost/wordpress', 'yes'); 
INSERT INTO `wp_options` VALUES (37, 'category_base', '', 'yes'); 
INSERT INTO `wp_options` VALUES (38, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'); 
INSERT INTO `wp_options` VALUES (39, 'advanced_edit', '0', 'yes'); 
INSERT INTO `wp_options` VALUES (40, 'comment_max_links', '2', 'yes'); 
INSERT INTO `wp_options` VALUES (41, 'gmt_offset', '1', 'yes'); 
INSERT INTO `wp_options` VALUES (42, 'default_email_category', '1', 'yes'); 
INSERT INTO `wp_options` VALUES (43, 'recently_edited', 'a:5:{i:0;s:70:"C:\\wamp\\www\\wordpress/wp-content/plugins/wp-db-backup/wp-db-backup.php";i:2;s:74:"C:\\wamp\\www\\wordpress/wp-content/plugins/seo-automatic-links/seo-links.php";i:3;s:82:"C:\\wamp\\www\\wordpress/wp-content/plugins/responsive-add-ons/responsive-add-ons.php";i:4;s:60:"C:\\wamp\\www\\wordpress/wp-content/themes/responsive/style.css";i:5;s:0:"";}', 'no'); 
INSERT INTO `wp_options` VALUES (44, 'template', 'strappress', 'yes'); 
INSERT INTO `wp_options` VALUES (45, 'stylesheet', 'strappress', 'yes'); 
INSERT INTO `wp_options` VALUES (46, 'comment_whitelist', '1', 'yes'); 
INSERT INTO `wp_options` VALUES (47, 'blacklist_keys', '', 'no'); 
INSERT INTO `wp_options` VALUES (48, 'comment_registration', '0', 'yes'); 
INSERT INTO `wp_options` VALUES (49, 'html_type', 'text/html', 'yes'); 
INSERT INTO `wp_options` VALUES (50, 'use_trackback', '0', 'yes'); 
INSERT INTO `wp_options` VALUES (51, 'default_role', 'subscriber', 'yes'); 
INSERT INTO `wp_options` VALUES (52, 'db_version', '25824', 'yes'); 
INSERT INTO `wp_options` VALUES (53, 'uploads_use_yearmonth_folders', '1', 'yes'); 
INSERT INTO `wp_options` VALUES (54, 'upload_path', '', 'yes'); 
INSERT INTO `wp_options` VALUES (55, 'blog_public', '1', 'yes'); 
INSERT INTO `wp_options` VALUES (56, 'default_link_category', '2', 'yes'); 
INSERT INTO `wp_options` VALUES (57, 'show_on_front', 'posts', 'yes'); 
INSERT INTO `wp_options` VALUES (58, 'tag_base', '', 'yes'); 
INSERT INTO `wp_options` VALUES (59, 'show_avatars', '1', 'yes'); 
INSERT INTO `wp_options` VALUES (60, 'avatar_rating', 'G', 'yes'); 
INSERT INTO `wp_options` VALUES (61, 'upload_url_path', '', 'yes'); 
INSERT INTO `wp_options` VALUES (62, 'thumbnail_size_w', '150', 'yes'); 
INSERT INTO `wp_options` VALUES (63, 'thumbnail_size_h', '150', 'yes'); 
INSERT INTO `wp_options` VALUES (64, 'thumbnail_crop', '1', 'yes'); 
INSERT INTO `wp_options` VALUES (65, 'medium_size_w', '300', 'yes'); 
INSERT INTO `wp_options` VALUES (66, 'medium_size_h', '300', 'yes'); 
INSERT INTO `wp_options` VALUES (67, 'avatar_default', 'mystery', 'yes'); 
INSERT INTO `wp_options` VALUES (68, 'large_size_w', '1024', 'yes'); 
INSERT INTO `wp_options` VALUES (69, 'large_size_h', '1024', 'yes'); 
INSERT INTO `wp_options` VALUES (70, 'image_default_link_type', 'file', 'yes'); 
INSERT INTO `wp_options` VALUES (71, 'image_default_size', '', 'yes'); 
INSERT INTO `wp_options` VALUES (72, 'image_default_align', '', 'yes'); 
INSERT INTO `wp_options` VALUES (73, 'close_comments_for_old_posts', '0', 'yes'); 
INSERT INTO `wp_options` VALUES (74, 'close_comments_days_old', '14', 'yes'); 
INSERT INTO `wp_options` VALUES (75, 'thread_comments', '1', 'yes'); 
INSERT INTO `wp_options` VALUES (76, 'thread_comments_depth', '5', 'yes'); 
INSERT INTO `wp_options` VALUES (77, 'page_comments', '0', 'yes'); 
INSERT INTO `wp_options` VALUES (78, 'comments_per_page', '50', 'yes'); 
INSERT INTO `wp_options` VALUES (79, 'default_comments_page', 'newest', 'yes'); 
INSERT INTO `wp_options` VALUES (80, 'comment_order', 'asc', 'yes'); 
INSERT INTO `wp_options` VALUES (81, 'sticky_posts', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES (82, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES (83, 'widget_text', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES (84, 'widget_rss', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES (85, 'uninstall_plugins', 'a:0:{}', 'no'); 
INSERT INTO `wp_options` VALUES (86, 'timezone_string', '', 'yes'); 
INSERT INTO `wp_options` VALUES (87, 'page_for_posts', '0', 'yes'); 
INSERT INTO `wp_options` VALUES (88, 'page_on_front', '0', 'yes'); 
INSERT INTO `wp_options` VALUES (89, 'default_post_format', '0', 'yes'); 
INSERT INTO `wp_options` VALUES (90, 'link_manager_enabled', '0', 'yes'); 
INSERT INTO `wp_options` VALUES (91, 'initial_db_version', '25824', 'yes'); 
INSERT INTO `wp_options` VALUES (92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'); 
INSERT INTO `wp_options` VALUES (93, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES (94, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES (95, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES (96, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES (97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES (98, 'sidebars_widgets', 'a:11:{s:19:"wp_inactive_widgets";a:0:{}s:12:"main-sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"right-sidebar";a:0:{}s:12:"left-sidebar";N;s:17:"left-sidebar-half";N;s:18:"right-sidebar-half";N;s:13:"home-widget-1";N;s:13:"home-widget-2";N;s:13:"home-widget-3";N;s:14:"contact-widget";N;s:13:"array_version";i:3;}', 'yes'); 
INSERT INTO `wp_options` VALUES (99, 'cron', 'a:6:{i:1385646862;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1385648013;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1385653012;a:1:{s:14:"yoast_tracking";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1385661600;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1385725234;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'); 
INSERT INTO `wp_options` VALUES (101, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:2:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:49:"http://fr.wordpress.org/wordpress-3.7.1-fr_FR.zip";s:6:"locale";s:5:"fr_FR";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:49:"http://fr.wordpress.org/wordpress-3.7.1-fr_FR.zip";s:10:"no_content";b:0;s:11:"new_bundled";b:0;s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.7.1";s:7:"version";s:5:"3.7.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.6";s:15:"partial_version";s:0:"";}i:1;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:41:"https://wordpress.org/wordpress-3.7.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:41:"https://wordpress.org/wordpress-3.7.1.zip";s:10:"no_content";s:52:"https://wordpress.org/wordpress-3.7.1-no-content.zip";s:11:"new_bundled";s:53:"https://wordpress.org/wordpress-3.7.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.7.1";s:7:"version";s:5:"3.7.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.6";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1385644509;s:15:"version_checked";s:5:"3.7.1";s:12:"translations";a:0:{}}', 'yes'); 
INSERT INTO `wp_options` VALUES (105, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1385644512;s:7:"checked";a:1:{s:10:"strappress";s:5:"2.1.1";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes'); 
INSERT INTO `wp_options` VALUES (108, 'dashboard_widget_options', 'a:4:{s:25:"dashboard_recent_comments";a:1:{s:5:"items";i:5;}s:24:"dashboard_incoming_links";a:5:{s:4:"home";s:26:"http://localhost/wordpress";s:4:"link";s:102:"http://blogsearch.google.com/blogsearch?scoring=d&partner=wordpress&q=link:http://localhost/wordpress/";s:3:"url";s:135:"http://blogsearch.google.com/blogsearch_feeds?scoring=d&ie=utf-8&num=10&output=rss&partner=wordpress&q=link:http://localhost/wordpress/";s:5:"items";i:10;s:9:"show_date";b:0;}s:17:"dashboard_primary";a:7:{s:4:"link";s:28:"http://www.wordpress-fr.net/";s:3:"url";s:48:"http://feeds.feedburner.com/WordpressFrancophone";s:5:"title";s:14:"Blog WordPress";s:5:"items";i:2;s:12:"show_summary";i:1;s:11:"show_author";i:0;s:9:"show_date";i:1;}s:19:"dashboard_secondary";a:7:{s:4:"link";s:35:"http://www.wordpress-fr.net/planet/";s:3:"url";s:55:"http://feeds2.feedburner.com/WordpressFrancophonePlanet";s:5:"title";s:46:"Autres actualités de WordPress (en français)";s:5:"items";i:5;s:12:"show_summary";i:0;s:11:"show_author";i:0;s:9:"show_date";i:0;}}', 'yes'); 
INSERT INTO `wp_options` VALUES (109, 'can_compress_scripts', '1', 'yes'); 
INSERT INTO `wp_options` VALUES (144, 'theme_mods_twentythirteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1384524873;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}}}}', 'yes'); 
INSERT INTO `wp_options` VALUES (145, 'current_theme', 'StrapPress', 'yes'); 
INSERT INTO `wp_options` VALUES (146, 'theme_mods_responsive', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1384855304;s:4:"data";a:13:{s:19:"wp_inactive_widgets";a:0:{}s:12:"main-sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"right-sidebar";a:0:{}s:12:"left-sidebar";N;s:17:"left-sidebar-half";N;s:18:"right-sidebar-half";N;s:13:"home-widget-1";N;s:13:"home-widget-2";N;s:13:"home-widget-3";N;s:14:"gallery-widget";N;s:15:"colophon-widget";N;s:10:"top-widget";N;s:13:"footer-widget";N;}}}', 'yes'); 
INSERT INTO `wp_options` VALUES (147, 'theme_switched', '', 'yes'); 
INSERT INTO `wp_options` VALUES (148, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1385644512;s:7:"checked";a:8:{s:19:"akismet/akismet.php";s:5:"2.5.9";s:36:"contact-form-7/wp-contact-form-7.php";s:5:"3.5.4";s:43:"google-analyticator/google-analyticator.php";s:5:"6.4.5";s:9:"hello.php";s:3:"1.6";s:41:"responsive-add-ons/responsive-add-ons.php";s:5:"1.0.4";s:33:"seo-automatic-links/seo-links.php";s:5:"2.7.6";s:29:"wp-db-backup/wp-db-backup.php";s:5:"2.2.4";s:24:"wordpress-seo/wp-seo.php";s:6:"1.4.19";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes'); 
INSERT INTO `wp_options` VALUES (151, 'recently_activated', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES (189, '_site_transient_wporg_theme_feature_list', 'a:5:{s:6:"Colors";a:15:{i:0;s:5:"black";i:1;s:4:"blue";i:2;s:5:"brown";i:3;s:4:"gray";i:4;s:5:"green";i:5;s:6:"orange";i:6;s:4:"pink";i:7;s:6:"purple";i:8;s:3:"red";i:9;s:6:"silver";i:10;s:3:"tan";i:11;s:5:"white";i:12;s:6:"yellow";i:13;s:4:"dark";i:14;s:5:"light";}s:7:"Columns";a:6:{i:0;s:10:"one-column";i:1;s:11:"two-columns";i:2;s:13:"three-columns";i:3;s:12:"four-columns";i:4;s:12:"left-sidebar";i:5;s:13:"right-sidebar";}s:5:"Width";a:2:{i:0;s:11:"fixed-width";i:1;s:14:"flexible-width";}s:8:"Features";a:19:{i:0;s:8:"blavatar";i:1;s:10:"buddypress";i:2;s:17:"custom-background";i:3;s:13:"custom-colors";i:4;s:13:"custom-header";i:5;s:11:"custom-menu";i:6;s:12:"editor-style";i:7;s:21:"featured-image-header";i:8;s:15:"featured-images";i:9;s:15:"flexible-header";i:10;s:20:"front-page-post-form";i:11;s:19:"full-width-template";i:12;s:12:"microformats";i:13;s:12:"post-formats";i:14;s:20:"rtl-language-support";i:15;s:11:"sticky-post";i:16;s:13:"theme-options";i:17;s:17:"threaded-comments";i:18;s:17:"translation-ready";}s:7:"Subject";a:3:{i:0;s:7:"holiday";i:1;s:13:"photoblogging";i:2;s:8:"seasonal";}}', 'yes'); 
INSERT INTO `wp_options` VALUES (190, '_site_transient_timeout_wporg_theme_feature_list', '1384872816', 'yes'); 
INSERT INTO `wp_options` VALUES (199, 'theme_mods_wordpress-bootstrap-master/wordpress-bootstrap-master', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1384861003;s:4:"data";a:6:{s:19:"wp_inactive_widgets";a:0:{}s:8:"sidebar1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:8:"sidebar2";a:0:{}s:7:"footer1";N;s:7:"footer2";N;s:7:"footer3";N;}}}', 'yes'); 
INSERT INTO `wp_options` VALUES (200, 'optionsframework', 'a:2:{s:2:"id";s:10:"strappress";s:12:"knownoptions";a:2:{i:0;s:70:"optionsframework_wordpress_bootstrap_master_wordpress_bootstrap_master";i:1;s:10:"strappress";}}', 'yes'); 
INSERT INTO `wp_options` VALUES (201, 'optionsframework_wordpress_bootstrap_master_wordpress_bootstrap_', 'a:25:{s:18:"heading_typography";a:4:{s:4:"size";a:63:{i:0;i:9;i:1;i:10;i:2;i:11;i:3;i:12;i:4;i:13;i:5;i:14;i:6;i:15;i:7;i:16;i:8;i:17;i:9;i:18;i:10;i:19;i:11;i:20;i:12;i:21;i:13;i:22;i:14;i:23;i:15;i:24;i:16;i:25;i:17;i:26;i:18;i:27;i:19;i:28;i:20;i:29;i:21;i:30;i:22;i:31;i:23;i:32;i:24;i:33;i:25;i:34;i:26;i:35;i:27;i:36;i:28;i:37;i:29;i:38;i:30;i:39;i:31;i:40;i:32;i:41;i:33;i:42;i:34;i:43;i:35;i:44;i:36;i:45;i:37;i:46;i:38;i:47;i:39;i:48;i:40;i:49;i:41;i:50;i:42;i:51;i:43;i:52;i:44;i:53;i:45;i:54;i:46;i:55;i:47;i:56;i:48;i:57;i:49;i:58;i:50;i:59;i:51;i:60;i:52;i:61;i:53;i:62;i:54;i:63;i:55;i:64;i:56;i:65;i:57;i:66;i:58;i:67;i:59;i:68;i:60;i:69;i:61;i:70;i:62;i:71;}s:4:"face";s:5:"Arial";s:5:"style";s:6:"Normal";s:5:"color";s:0:"";}s:20:"main_body_typography";a:4:{s:4:"size";a:63:{i:0;i:9;i:1;i:10;i:2;i:11;i:3;i:12;i:4;i:13;i:5;i:14;i:6;i:15;i:7;i:16;i:8;i:17;i:9;i:18;i:10;i:19;i:11;i:20;i:12;i:21;i:13;i:22;i:14;i:23;i:15;i:24;i:16;i:25;i:17;i:26;i:18;i:27;i:19;i:28;i:20;i:29;i:21;i:30;i:22;i:31;i:23;i:32;i:24;i:33;i:25;i:34;i:26;i:35;i:27;i:36;i:28;i:37;i:29;i:38;i:30;i:39;i:31;i:40;i:32;i:41;i:33;i:42;i:34;i:43;i:35;i:44;i:36;i:45;i:37;i:46;i:38;i:47;i:39;i:48;i:40;i:49;i:41;i:50;i:42;i:51;i:43;i:52;i:44;i:53;i:45;i:54;i:46;i:55;i:47;i:56;i:48;i:57;i:49;i:58;i:50;i:59;i:51;i:60;i:52;i:61;i:53;i:62;i:54;i:63;i:55;i:64;i:56;i:65;i:57;i:66;i:58;i:67;i:59;i:68;i:60;i:69;i:61;i:70;i:62;i:71;}s:4:"face";s:5:"Arial";s:5:"style";s:6:"Normal";s:5:"color";s:0:"";}s:10:"link_color";s:0:"";s:16:"link_hover_color";s:0:"";s:17:"link_active_color";s:0:"";s:12:"nav_position";s:0:"";s:16:"top_nav_bg_color";s:0:"";s:19:"showhidden_gradient";b:0;s:29:"top_nav_bottom_gradient_color";s:0:"";s:18:"top_nav_link_color";s:0:"";s:24:"top_nav_link_hover_color";s:0:"";s:21:"top_nav_dropdown_item";s:0:"";s:25:"top_nav_dropdown_hover_bg";s:0:"";s:10:"search_bar";b:0;s:13:"branding_logo";s:0:"";s:9:"site_name";s:1:"1";s:17:"showhidden_themes";b:0;s:10:"wpbs_theme";s:7:"default";s:24:"showhidden_slideroptions";b:0;s:14:"slider_options";s:1:"5";s:18:"hero_unit_bg_color";s:0:"";s:25:"suppress_comments_message";s:1:"1";s:9:"blog_hero";s:1:"1";s:11:"favicon_url";s:0:"";s:8:"wpbs_css";s:0:"";}', 'yes'); 
INSERT INTO `wp_options` VALUES (210, 'category_children', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES (215, 'theme_mods_strappress', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:7:"top-bar";i:3;s:11:"footer-menu";i:4;}}', 'yes'); 
INSERT INTO `wp_options` VALUES (216, 'strappress', 'a:41:{s:11:"logo_upload";s:64:"http://localhost/wordpress/wp-content/uploads/2013/11/logo22.png";s:12:"nav_position";s:5:"fixed";s:9:"nav_color";s:5:"black";s:10:"search_bar";s:1:"1";s:10:"link_color";s:0:"";s:16:"link_hover_color";s:0:"";s:17:"link_active_color";s:0:"";s:11:"breadcrumbs";s:1:"1";s:14:"copyright_text";s:0:"";s:12:"powered_text";s:0:"";s:12:"scroll_arrow";s:1:"1";s:10:"hero_radio";s:8:"featured";s:16:"featured_heading";s:0:"";s:16:"home_subheadline";s:0:"";s:17:"home_content_area";s:0:"";s:14:"display_button";s:1:"1";s:8:"cta_text";s:0:"";s:7:"cta_url";s:0:"";s:8:"cta_size";s:4:"mini";s:12:"button_block";s:1:"1";s:9:"cta_color";s:7:"default";s:16:"featured_content";s:0:"";s:16:"portfolio_column";s:5:"three";s:11:"filter_btns";s:1:"1";s:10:"f_btn_size";s:4:"mini";s:11:"f_btn_color";s:7:"default";s:12:"project_btns";s:1:"1";s:14:"p_button_block";s:1:"1";s:10:"p_btn_size";s:4:"mini";s:11:"p_btn_color";s:7:"default";s:13:"p_button_text";s:0:"";s:13:"project_title";s:1:"1";s:13:"header_social";b:0;s:13:"footer_social";s:1:"1";s:11:"twitter_url";s:31:"https://twitter.com/damienmorin";s:6:"fb_url";s:41:"https://www.facebook.com/savemysmartphone";s:13:"pinterest_url";s:0:"";s:12:"linkedin_url";s:0:"";s:10:"google_url";s:51:"https://plus.google.com/107957583297179616406/posts";s:10:"github_url";s:0:"";s:7:"rss_url";s:0:"";}', 'yes'); 
INSERT INTO `wp_options` VALUES (220, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'); 
INSERT INTO `wp_options` VALUES (276, 'tagportfolio_children', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES (281, '_site_transient_timeout_browser_50800665b97ae80ddd3fd2b7704251fc', '1385734608', 'yes'); 
INSERT INTO `wp_options` VALUES (282, '_site_transient_browser_50800665b97ae80ddd3fd2b7704251fc', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"31.0.1650.57";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES (317, '_site_transient_timeout_browser_0746f044265515ad12713cf5e2c283a6', '1385981877', 'yes'); 
INSERT INTO `wp_options` VALUES (318, '_site_transient_browser_0746f044265515ad12713cf5e2c283a6', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:7:"Firefox";s:7:"version";s:4:"25.0";s:10:"update_url";s:23:"http://www.firefox.com/";s:7:"img_src";s:50:"http://s.wordpress.org/images/browsers/firefox.png";s:11:"img_src_ssl";s:49:"https://wordpress.org/images/browsers/firefox.png";s:15:"current_version";s:2:"16";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES (357, 'wpcf7', 'a:1:{s:7:"version";s:5:"3.5.4";}', 'yes'); 
INSERT INTO `wp_options` VALUES (362, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1385490918', 'yes'); 
INSERT INTO `wp_options` VALUES (363, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"3898";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2456";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2344";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"1930";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"1856";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1583";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1329";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1325";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1310";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1260";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1225";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1121";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1000";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:3:"982";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:3:"974";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:3:"950";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:3:"844";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"821";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:3:"780";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"722";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"686";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"681";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"678";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"623";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"615";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"595";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"572";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"570";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"541";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"539";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"530";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"522";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"506";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"505";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"471";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"458";}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";s:3:"453";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"452";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"436";}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";s:3:"432";}}', 'yes'); 
INSERT INTO `wp_options` VALUES (364, 'wpseo', 'a:28:{s:20:"disableadvanced_meta";s:2:"on";s:7:"version";s:6:"1.4.19";s:11:"theme_check";a:1:{s:11:"description";b:1;}s:14:"tracking_popup";s:4:"done";s:14:"yoast_tracking";b:1;s:10:"cleanslugs";s:2:"on";s:10:"title-home";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:12:"title-author";s:42:"%%name%%, Author at %%sitename%% %%page%% ";s:13:"title-archive";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:12:"title-search";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:9:"title-404";s:35:"Page Not Found %%sep%% %%sitename%%";s:15:"noindex-archive";s:2:"on";s:19:"noindex-post_format";s:2:"on";s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"title-project";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:23:"title-ptarchive-project";s:51:"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%";s:14:"title-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:14:"title-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:17:"title-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:18:"title-tagportfolio";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";i:0;b:0;s:16:"enablexmlsitemap";s:2:"on";s:36:"post_types-attachment-not_in_sitemap";b:1;s:9:"opengraph";s:2:"on";s:11:"ignore_tour";s:6:"ignore";}', 'yes'); 
INSERT INTO `wp_options` VALUES (365, 'wpseo_titles', 'a:16:{s:10:"title-home";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:12:"title-author";s:42:"%%name%%, Author at %%sitename%% %%page%% ";s:13:"title-archive";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:12:"title-search";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:9:"title-404";s:35:"Page Not Found %%sep%% %%sitename%%";s:15:"noindex-archive";s:2:"on";s:19:"noindex-post_format";s:2:"on";s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"title-project";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:23:"title-ptarchive-project";s:51:"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%";s:14:"title-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:14:"title-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:17:"title-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:18:"title-tagportfolio";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";}', 'yes'); 
INSERT INTO `wp_options` VALUES (366, 'wpseo_xml', 'a:2:{s:16:"enablexmlsitemap";s:2:"on";s:36:"post_types-attachment-not_in_sitemap";b:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES (367, 'wpseo_social', 'a:2:{s:9:"opengraph";s:2:"on";s:12:"fbconnectkey";s:32:"1363a02aa102a4201395ed18b850a79e";}', 'yes'); 
INSERT INTO `wp_options` VALUES (368, 'wpseo_rss', 'a:1:{s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";}', 'yes'); 
INSERT INTO `wp_options` VALUES (369, 'wpseo_permalinks', 'a:1:{s:10:"cleanslugs";s:2:"on";}', 'yes'); 
INSERT INTO `wp_options` VALUES (372, 'SEOLinks', 'a:29:{s:4:"post";s:2:"on";s:8:"postself";s:0:"";s:4:"page";s:2:"on";s:8:"pageself";s:0:"";s:7:"comment";s:0:"";s:14:"excludeheading";s:2:"on";s:6:"lposts";s:2:"on";s:6:"lpages";s:2:"on";s:5:"lcats";s:0:"";s:5:"ltags";s:0:"";s:6:"ignore";s:6:"about,";s:10:"ignorepost";s:7:"contact";s:8:"maxlinks";i:3;s:9:"maxsingle";i:1;s:8:"minusage";i:1;s:9:"customkey";s:0:"";s:30:"customkey_preventduplicatelink";b:0;s:13:"customkey_url";s:0:"";s:19:"customkey_url_value";s:0:"";s:22:"customkey_url_datetime";s:0:"";s:6:"nofoln";s:0:"";s:6:"nofolo";s:0:"";s:6:"blankn";s:0:"";s:6:"blanko";s:0:"";s:10:"onlysingle";s:2:"on";s:8:"casesens";s:0:"";s:9:"allowfeed";s:0:"";s:12:"maxsingleurl";s:1:"1";s:6:"notice";i:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES (405, 'ga_version', '6.4.5', 'yes'); 
INSERT INTO `wp_options` VALUES (412, 'key_ga_show_ad', '1', 'yes'); 
INSERT INTO `wp_options` VALUES (427, '_transient_random_seed', '26df35f76b8106719c7d5fe33a0db213', 'yes'); 
INSERT INTO `wp_options` VALUES (428, 'rewrite_rules', 'a:95:{s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:14:"sitemap\\.xslt$";s:16:"index.php?xslt=1";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:10:"project/?$";s:27:"index.php?post_type=project";s:40:"project/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=project&feed=$matches[1]";s:35:"project/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=project&feed=$matches[1]";s:27:"project/page/([0-9]{1,})/?$";s:45:"index.php?post_type=project&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:35:"project/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"project/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"project/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"project/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"project/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"project/([^/]+)/trackback/?$";s:34:"index.php?project=$matches[1]&tb=1";s:48:"project/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?project=$matches[1]&feed=$matches[2]";s:43:"project/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?project=$matches[1]&feed=$matches[2]";s:36:"project/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?project=$matches[1]&paged=$matches[2]";s:43:"project/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?project=$matches[1]&cpage=$matches[2]";s:28:"project/([^/]+)(/[0-9]+)?/?$";s:46:"index.php?project=$matches[1]&page=$matches[2]";s:24:"project/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"project/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"project/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"project/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"project/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:54:"tag-portfolio/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?tagportfolio=$matches[1]&feed=$matches[2]";s:49:"tag-portfolio/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?tagportfolio=$matches[1]&feed=$matches[2]";s:42:"tag-portfolio/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?tagportfolio=$matches[1]&paged=$matches[2]";s:24:"tag-portfolio/([^/]+)/?$";s:34:"index.php?tagportfolio=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes'); 
INSERT INTO `wp_options` VALUES (429, 'ga_enable_remarketing', '0', 'yes'); 
INSERT INTO `wp_options` VALUES (430, 'key_ga_track_login', '0', 'yes'); 
INSERT INTO `wp_options` VALUES (431, 'ga_status', 'disabled', 'yes'); 
INSERT INTO `wp_options` VALUES (432, 'ga_uid', 'UA-XXXXXXXX-X', 'yes'); 
INSERT INTO `wp_options` VALUES (433, 'ga_admin_status', 'enabled', 'yes'); 
INSERT INTO `wp_options` VALUES (434, 'ga_admin_disable', 'remove', 'yes'); 
INSERT INTO `wp_options` VALUES (435, 'ga_admin_role', 'a:1:{i:0;s:13:"administrator";}', 'yes'); 
INSERT INTO `wp_options` VALUES (436, 'ga_dashboard_role', 'a:1:{i:0;s:13:"administrator";}', 'yes'); 
INSERT INTO `wp_options` VALUES (437, 'ga_adsense', '', 'yes'); 
INSERT INTO `wp_options` VALUES (438, 'ga_extra', '', 'yes'); 
INSERT INTO `wp_options` VALUES (439, 'ga_extra_after', '', 'yes'); 
INSERT INTO `wp_options` VALUES (440, 'ga_event', 'enabled', 'yes'); 
INSERT INTO `wp_options` VALUES (441, 'ga_outbound', 'enabled', 'yes'); 
INSERT INTO `wp_options` VALUES (442, 'ga_outbound_prefix', 'outgoing', 'yes'); 
INSERT INTO `wp_options` VALUES (443, 'ga_downloads', '', 'yes'); 
INSERT INTO `wp_options` VALUES (444, 'ga_downloads_prefix', 'download', 'yes'); 
INSERT INTO `wp_options` VALUES (445, 'ga_widgets', 'enabled', 'yes'); 
INSERT INTO `wp_options` VALUES (446, 'ga_annon', '', 'yes'); 
INSERT INTO `wp_options` VALUES (447, 'ga_defaults', 'yes', 'yes'); 
INSERT INTO `wp_options` VALUES (448, 'ga_google_token', '', 'yes'); 
INSERT INTO `wp_options` VALUES (462, '_site_transient_timeout_theme_roots', '1385646311', 'yes'); 
INSERT INTO `wp_options` VALUES (463, '_site_transient_theme_roots', 'a:1:{s:10:"strappress";s:7:"/themes";}', 'yes'); 
INSERT INTO `wp_options` VALUES (465, '_transient_timeout_feed_eebbfad72cfaf76c4edc5695ad275b05', '1385688027', 'no'); 
INSERT INTO `wp_options` VALUES (466, '_transient_feed_eebbfad72cfaf76c4edc5695ad275b05', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:4:"\n  \n";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:83:"\n    \n    \n    \n    \n    \n    \n    \n    \n    \n    \n    \n    \n    \n    \n    \n    \n  ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:4:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"link:http://localhost/wordpress/ - Google Blog Search";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://www.google.com/search?ie=utf-8&q=link:http://localhost/wordpress/&tbm=blg&tbs=sbd:1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:20:"About 68,500 results";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"How to install ioncube loader in xampp | Bugtreat Blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://www.bugtreat.com/blog/how-to-install-ioncube-loader-in-xampp/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:301:"<b>...</b> safety disabled. 2. Download ionCube loader from: <em>http</em>://www. <b>...</b> Run (or restart) XAMPP, and open the following <em>link http</em>://<em>localhost</em>/ioncube/loader-wizard.php. 6. For security <b>...</b> Featuring Recent Posts <em>WordPress</em> Widget development by YD.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:13:"Bugtreat Blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"admin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Thu, 28 Nov 2013 08:19:02 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:75:"javascript - jQuery form plugin doesn&amp;#39;t work in IE - Stack Overflow";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:80:"http://stackoverflow.com/questions/20253308/jquery-form-plugin-doesnt-work-in-ie";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:342:"Programmers &middot; Unix &amp; Linux &middot; Ask Different (Apple) &middot; <em>WordPress</em> Answers &middot; Geographic Information Systems &middot; Electrical Engineering &middot; Android Enthusiasts &middot; Information Security &middot; Database Administrators &middot; Drupal Answers &middot; SharePoint &middot; User&nbsp;<b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:33:"Recent Questions - Stack Overflow";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"1linecode";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Wed, 27 Nov 2013 21:21:41 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"Pentoo (Gentoo) Based Linux Review, Features and Screenshot Tour";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://www.tecmint.com/pentoo-linux-review-features-and-screenshot-tour/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:543:"Scanner Tools (Hunt, Skinfish, etc along with <em>Http</em> and Windows Scanner Tools. Wireless Tools (Aircrackng, Asleap, <b>...</b> Download Pentoo ISO Images. Pentoo Download <em>links</em> Contain both 32 and 64 bit Downloads. <b>...</b> tecmint@<em>localhost</em>:~/ Downloads$ sha1sum pentooi6862013.0_RC1.9.iso 3855c867adaca66bcedad5147786db7c61d90cb2 pentooi6862013.0_RC1.9.iso. Match the above HASH from the <b>...</b> Linux Services &amp; Free <em>WordPress</em> Setup. Our post is simply &#39;DIY&#39; aka &#39;Do It&nbsp;<b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:41:"Tecmint: Linux Howtos, Tutorials & Guides";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Avishek Kumar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Wed, 27 Nov 2013 10:21:31 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:105:"redirect - Trouble running local &lt;b&gt;WordPress&lt;/b&gt; in Google App Engine &lt;b&gt;...&lt;/b&gt;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:104:"http://wordpress.stackexchange.com/questions/124569/trouble-running-local-wordpress-in-google-app-engine";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:275:"Created an app for <em>WordPress</em>, created database and user on <em>localhost</em> and edited <em>WordPress</em> config accordingly. Started the app in the Google App Engine Launcher. Clicking Browse leads to blank page at <em>http</em>://<em>localhost</em>:8080/. Hmmm..";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:36:"Recent Questions - WordPress Answers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"OC2PS";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Tue, 26 Nov 2013 17:32:24 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:87:"Docker 0.7 runs on all Linux distributions – and 6 other major &lt;b&gt;...&lt;/b&gt;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:83:"http://blog.docker.io/2013/11/docker-0-7-docker-now-runs-on-any-linux-distribution/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:539:"Feature 1: Standard Linux support; Feature 2: Storage drivers; Feature 3: Offline transfer; Feature 4: <em>Links</em>; Feature 5: Container naming; Feature 6: Advanced port redirects; Feature 7: Quality <b>...</b> port 8080 of the container to all interfaces of the host with a dynamically allocated port; -p 8080:8080 will publish port 8080 of the container to all interfaces of the host with a static port of 8080; -p <em>127.0.0.1</em>:80:80 # Publish port 80 of the container to <em>localhost</em> of the host with a static port to 80.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:11:"Docker Blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Solomon Hykes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Tue, 26 Nov 2013 14:00:34 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"Integrating R with Cloudera Impala for Real-Time Queries on &lt;b&gt;...&lt;/b&gt;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:109:"http://bighadoop.wordpress.com/2013/11/25/integrating-r-with-cloudera-impala-for-real-time-queries-on-hadoop/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:570:"The third option is to use ODBC driver and <em>connect</em> some of the well-known popular BI tools to Impala. Cloudera <b>....</b> You can download e.g. Google stock prices from <em>http</em>://finance.yahoo.com (symbol: GOOG). <b>...</b> impala-shell [<em>localhost</em>. localdomain:21000] &gt; create external table stock (stock_date string, stock_open float, stock_high float, stock_low float, stock_close_ float, stock_volume int, stock_adjclose float) row format delimited fields terminated by &#39;,&#39; lines terminated by &#39;\\n&#39; location&nbsp;<b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:9:"BigHadoop";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"istvanszegedi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Mon, 25 Nov 2013 09:48:20 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:102:"Installing your local &lt;b&gt;Wordpress&lt;/b&gt; plugin development in Ubuntu &lt;b&gt;...&lt;/b&gt;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:95:"http://figurebelow.com/2013/11/24/installing-your-local-wordpress-plugin-development-in-ubuntu/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:296:"If everything worked , browsing <em>http</em>://<em>localhost</em> should display the standard Apache welcome page: <b>...</b> I chose to download the <em>wordpress</em> directly from the web, the latest version is always at this <em>link</em> : <em>http</em>://<em>wordpress</em>.org/latest.zip.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:11:"FigureBelow";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Ruben";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Sun, 24 Nov 2013 12:57:05 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:93:"Install &lt;b&gt;WordPress&lt;/b&gt; on Your Computer Using WampServer &lt;b&gt;...&lt;/b&gt;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://blog.arnabpal.in/?p=8";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:275:"We need to navigate back to <em>http</em>://<em>localhost</em> and then click on the phpmyadmin <em>link</em> towards the bottom of the Server Configuration screen, under Your Aliases. Once phpMyAdmin launches, create a new database with the same name as your&nbsp;<b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:11:"iamArnabPal";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"arnabpal";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Sat, 23 Nov 2013 08:13:00 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:86:"Best Lpi 117-102 test training guide | The latest, high-quality &lt;b&gt;...&lt;/b&gt;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://exam.ibm-certification.com/?p=2743";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:540:"Answer: C. Lpi 117-102 117-102 117-102 117-102. NO.9 Which statement is true regarding the following /etc/resolv.conf file? search example.com <em>127.0.0.1</em> 208.77.188.166. A. There is a syntax error. B. If DNS queries to the <em>localhost</em> fail, the server 208.77.188.166 will be queried. C. example.com will be appended to all host lookups. D. The DNS servers at <b>...</b> Article <em>Link</em>: <em>http</em>://www.pass4test.com/117-102.html. This entry was posted in Lpi and tagged 117-102, Lpi on November 23,&nbsp;<b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:68:"The latest, high-quality, reliable IT certification exam - pass4test";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"admin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Sat, 23 Nov 2013 03:28:06 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:43:"Open LDAP no Mac | Rodrigo Portela da Costa";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://rodrigoportela.blog.br/2013/11/open-ldap-no-mac/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:286:"Baixar o MacPorts no <em>link http</em>://www.macports.org/install.php. Selecione sua versão. O arquivo será baixado para seu <b>...</b> BASE dc=rodrigoportela,dc=blog,dc=br URI ldap://<em>127.0.0.1</em> 389. E é só salvar. Se você utilizou o vi como editor, digite&nbsp;<b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:24:"Rodrigo Portela da Costa";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"bloggermaster";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Sat, 23 Nov 2013 01:28:32 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:36:"http://a9.com/-/spec/opensearch/1.1/";a:3:{s:12:"totalResults";a:1:{i:0;a:5:{s:4:"data";s:5:"68500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:10:"startIndex";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:12:"itemsPerPage";a:1:{i:0;a:5:{s:4:"data";s:2:"10";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:28:"text/xml; charset=ISO-8859-1";s:4:"date";s:29:"Thu, 28 Nov 2013 13:20:27 GMT";s:7:"expires";s:2:"-1";s:13:"cache-control";s:18:"private, max-age=0";s:10:"set-cookie";a:2:{i:0;s:143:"PREF=ID=2667952539d330ae:FF=0:TM=1385644827:LM=1385644827:S=R4_9ck5odhrcR1SE; expires=Sat, 28-Nov-2015 13:20:27 GMT; path=/; domain=.google.com";i:1;s:212:"NID=67=uFuBqVDnLUcTftNSsKBaVG2a7ItVC3EIRQg-o-A4oMCW-kmxF0S3_rzHFDiRvfkHXsNoe0dtHxWq9s5zq5yR_OGcLJL-LHn1D8jAPnWBoT_jQmnhMfE1cjOBXIfiEKfT; expires=Fri, 30-May-2014 13:20:27 GMT; path=/; domain=.google.com; HttpOnly";}s:3:"p3p";s:122:"CP="This is not a P3P policy! See http://www.google.com/support/accounts/bin/answer.py?hl=en&answer=151657 for more info."";s:6:"server";s:3:"gws";s:16:"x-xss-protection";s:13:"1; mode=block";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20131115134507";}', 'no'); 
INSERT INTO `wp_options` VALUES (467, '_transient_timeout_feed_mod_eebbfad72cfaf76c4edc5695ad275b05', '1385688027', 'no'); 
INSERT INTO `wp_options` VALUES (468, '_transient_feed_mod_eebbfad72cfaf76c4edc5695ad275b05', '1385644827', 'no'); 
INSERT INTO `wp_options` VALUES (469, '_transient_timeout_dash_20494a3d90a6669585674ed0eb8dcd8f', '1385688027', 'no'); 
INSERT INTO `wp_options` VALUES (470, '_transient_dash_20494a3d90a6669585674ed0eb8dcd8f', '<ul>\n	<li><strong>admin</strong> a fait un lien vers ce site <a href="http://www.bugtreat.com/blog/how-to-install-ioncube-loader-in-xampp/">en écrivant</a> &laquo;&nbsp;... safety disabled. 2. Download ionCube loader fr &hellip;&nbsp;&raquo;</li>\n	<li><strong>1linecode</strong> a fait un lien vers ce site <a href="http://stackoverflow.com/questions/20253308/jquery-form-plugin-doesnt-work-in-ie">en écrivant</a> &laquo;&nbsp;Programmers &middot; Unix &amp; Linux &middot; Ask &hellip;&nbsp;&raquo;</li>\n	<li><strong>Avishek Kumar</strong> a fait un lien vers ce site <a href="http://www.tecmint.com/pentoo-linux-review-features-and-screenshot-tour/">en écrivant</a> &laquo;&nbsp;Scanner Tools (Hunt, Skinfish, etc along with Http &hellip;&nbsp;&raquo;</li>\n	<li><strong>OC2PS</strong> a fait un lien vers ce site <a href="http://wordpress.stackexchange.com/questions/124569/trouble-running-local-wordpress-in-google-app-engine">en écrivant</a> &laquo;&nbsp;Created an app for WordPress, created database and &hellip;&nbsp;&raquo;</li>\n	<li><strong>Solomon Hykes</strong> a fait un lien vers ce site <a href="http://blog.docker.io/2013/11/docker-0-7-docker-now-runs-on-any-linux-distribution/">en écrivant</a> &laquo;&nbsp;Feature 1: Standard Linux support; Feature 2: Stor &hellip;&nbsp;&raquo;</li>\n	<li><strong>istvanszegedi</strong> a fait un lien vers ce site <a href="http://bighadoop.wordpress.com/2013/11/25/integrating-r-with-cloudera-impala-for-real-time-queries-on-hadoop/">en écrivant</a> &laquo;&nbsp;The third option is to use ODBC driver and connect &hellip;&nbsp;&raquo;</li>\n	<li><strong>Ruben</strong> a fait un lien vers ce site <a href="http://figurebelow.com/2013/11/24/installing-your-local-wordpress-plugin-development-in-ubuntu/">en écrivant</a> &laquo;&nbsp;If everything worked , browsing http://localhost s &hellip;&nbsp;&raquo;</li>\n	<li><strong>arnabpal</strong> a fait un lien vers ce site <a href="http://blog.arnabpal.in/?p=8">en écrivant</a> &laquo;&nbsp;We need to navigate back to http://localhost and t &hellip;&nbsp;&raquo;</li>\n	<li><strong>admin</strong> a fait un lien vers ce site <a href="http://exam.ibm-certification.com/?p=2743">en écrivant</a> &laquo;&nbsp;Answer: C. Lpi 117-102 117-102 117-102 117-102. NO &hellip;&nbsp;&raquo;</li>\n	<li><strong>bloggermaster</strong> a fait un lien vers ce site <a href="http://rodrigoportela.blog.br/2013/11/open-ldap-no-mac/">en écrivant</a> &laquo;&nbsp;Baixar o MacPorts no link http://www.macports.org/ &hellip;&nbsp;&raquo;</li>\n</ul>\n', 'no'); 
INSERT INTO `wp_options` VALUES (471, '_transient_timeout_feed_66a70e9599b658d5cc038e8074597e7c', '1385688029', 'no'); 
INSERT INTO `wp_options` VALUES (472, '_transient_feed_66a70e9599b658d5cc038e8074597e7c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"\n\n\n";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"\n	\n	\n	\n	\n	\n	\n		\n		\n	\n	\n		\n		\n		\n		\n		\n		\n		\n		\n		\n	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"WordPress Francophone";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:27:"http://www.wordpress-fr.net";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:70:"La communauté francophone autour du CMS WordPress et son écosystème";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Nov 2013 16:00:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"fr-FR";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:27:"http://wordpress.org/?v=3.7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:60:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n		\n		\n		\n\n		\n		\n				\n			\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"L’Hebdo WordPress n°209 : BuddyPress – Veille – Contribution";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/YqF0QRIza80/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:101:"http://www.wordpress-fr.net/2013/11/26/lhebdo-wordpress-n209-buddypress-veille-contribution/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 26 Nov 2013 06:16:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:7:{i:0;a:5:{s:4:"data";s:7:"Astuces";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:10:"Extensions";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"Thèmes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:10:"BuddyPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:5:"Hebdo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:10:"Sécurité";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://www.wordpress-fr.net/?p=6500";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:369:"BuddyPress : Codex et traduction Le Codex de BuddyPress a été mis à jour (en), notamment avec des articles de nos amis français iMath et Chouf1. En outre, des informations concernant la traduction de l&#8217;extension sociale sont également fournies, ainsi qu&#8217;une liste de tâche pour améliorer la situation. BP Show Friends 2.0 iMath met à jour [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Benoît";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3628:"<h3>BuddyPress : Codex et traduction</h3>\n<p><a href="http://bpdevel.wordpress.com/2013/11/18/bp-codex-update-and-buddypress-translations/">Le Codex de BuddyPress a été mis à jour (en)</a>, notamment avec des articles de nos amis français iMath et Chouf1. En outre, des informations concernant la traduction de l&rsquo;extension sociale sont également fournies, ainsi qu&rsquo;une liste de tâche pour améliorer la situation.</p>\n<h3>BP Show Friends 2.0</h3>\n<p>iMath met à jour <a href="http://imathi.eu/2013/11/24/bp-show-friends-2-0/">sa première extension BuddyPress</a>. C&rsquo;est forcément un mini événement !</p>\n<h3>Flux RSS, Panda et Penguin</h3>\n<p><a href="http://yoast.com/rss-feeds-panda-penguin/">L&rsquo;analyse de Yoast sur ce sujet fort intéressant (en)</a> qu&rsquo;est le déclin du flux RSS et l&rsquo;arrivée de Panda et Penguin, les mises à jour des bases de Google.</p>\n<h3>Simple Theme</h3>\n<p>ThemeSmarts propose un thème gratuit : <a href="http://themesmarts.com/themes/simple-dark-wordpress-theme/">Simple Theme</a> (en).</p>\n<h3>Comment organiser son blog avec WordPress ?</h3>\n<p><a href="http://www.lipaonline.com/creer-blog/1149">Quelques idées</a> pour mieux bloguer avec WordPress.</p>\n<h3>La sécurité de WordPress</h3>\n<p><a href="http://www.wpexplorer.com/wordpress-security-tips/">La sécurité de WordPress (en) </a>est toujours au cœur des préoccupations.</p>\n<h3>Contribuer à WordPress en étant un pro</h3>\n<p>Quel intérêt pour un professionnel de contribuer à la communauté WordPress ? <a href="http://10up.com/blog/giving-back-to-wordpress/">Voici une réponse</a> (en).</p>\n<h3>La veille WordPress</h3>\n<p>Un sujet qui m&rsquo;intéresse forcément. <a href="http://wpformation.com/ma-veille-wordpress/">Fabrice évoque l&rsquo;art de la veille</a> en prenant exemple sur ce qu&rsquo;il fait pour WordPress.</p>\n<h3>WooCommerce 2.1 Beta 1</h3>\n<p>L&rsquo;extension e-commerce bien connue pour WordPress, <a href="http://develop.woothemes.com/woocommerce/2013/11/woocommerce-2-1-beta-1-is-ready/">WooCommerce débarque en bersion 2.1 beta 1</a> (en). A vos tests !</p>\n<h3>Joomla! vs WordPress</h3>\n<p>La bataille commence ! <a href="http://www.cree1site.com/wordpress-vs-joomla-seo/">Qui de WordPress ou de Joomla!</a> l&rsquo;emportera en combat singulier ?</p>\n<h3>Rendre visible ses activités à travers un blog WordPress</h3>\n<p>Stephanie Booth a fait un atelier présentant les intérêts de bloguer et de WordPress. <a href="http://www.pressmitic.ch/atelier-du-15-novembre-rendre-visible-ses-activites-a-travers-un-blog-wordpress/">La vidéo est en ligne</a> !</p>\n<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=YqF0QRIza80:Uyh-h2BrDoI:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=YqF0QRIza80:Uyh-h2BrDoI:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=YqF0QRIza80:Uyh-h2BrDoI:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=YqF0QRIza80:Uyh-h2BrDoI:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=YqF0QRIza80:Uyh-h2BrDoI:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=YqF0QRIza80:Uyh-h2BrDoI:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/YqF0QRIza80" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:97:"http://www.wordpress-fr.net/2013/11/26/lhebdo-wordpress-n209-buddypress-veille-contribution/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:92:"http://www.wordpress-fr.net/2013/11/26/lhebdo-wordpress-n209-buddypress-veille-contribution/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:45:"\n		\n		\n		\n		\n		\n				\n		\n\n		\n		\n				\n			\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.8 beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/DfxKjx6zZzs/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:69:"http://www.wordpress-fr.net/2013/11/23/wordpress-3-8-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 23 Nov 2013 17:23:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:14:"Développement";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:13:"WordPress 3.8";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://www.wordpress-fr.net/?p=6492";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:339:"La première beta de 3.8 est disponible au téléchargement. Les prochaines dates à retenir sont pour le gel du code le 5 décembre et la sortie de la version finale le 12 décembre. 3.8 rassemble plusieurs des fonctions développées comme des projets d&#8217;extensions (en) et bien que cela ne soit pas notre premier essai du [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Benoît";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3764:"<p>La première beta de 3.8 est disponible au téléchargement. Les prochaines dates à retenir sont pour le gel du code le 5 décembre et la sortie de la version finale le 12 décembre.</p>\n<p>3.8 rassemble plusieurs des fonctions développées comme <a href="http://make.wordpress.org/core/features-as-plugins/">des projets d&rsquo;extensions (en)</a> et bien que cela ne soit pas notre premier essai du genre, considéré tout ceci encore plus beta que d&rsquo;habitude. Les éléments à tester en premier sont :</p>\n<ul>\n<li>La nouvelle interface d&rsquo;admin et son nouvel aspect responsive. Essayez-la sur différents supports et navigateurs, regardez comment ça se passe, notamment les pages les plus complexes telles que l&rsquo;interface des widgets ou celles les moins utilisées comme &laquo;&nbsp;Press-Minute&nbsp;&raquo;. Le choix des couleurs, que vous pouvez changer dans votre profil a également été refait.</li>\n<li>La page d&rsquo;accueil du tableau de bord a été rafraichie.</li>\n<li>Choisir un thème dans Apparence est complétement différent, essayez de jouer avec autant que possible.</li>\n<li>Il y a un nouveau thème par défaut : Twenty Fourteen.</li>\n<li>Plus de 250 problèmes ont déjà été résolus.</li>\n</ul>\n<p>Étant donné le nombre de choses dans l&rsquo;admin qui ont changé c&rsquo;est super important de tester autant d&rsquo;extensions et de thèmes que possible avec les pages d&rsquo;administration contre tous les nouveaux trucs. Aussi, si vous êtes développeurs, voyez comment vous pouvez adapter votre administration à la nouvelle interface MP6.</p>\n<p>Comme toujours, si vous pensez avoir trouvé un bug, vous pouvez le dire dans le forum officiel : <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta (en)</a>. Ou, si vous êtes en mesure de rédiger un rapport de bug, <a href="http://core.trac.wordpress.org/">rapportez-le sur le WordPress Trac (en)</a>. Vous trouverez une <a href="http://core.trac.wordpress.org/report/5">liste des bugs connus (en)</a> et <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.8">tout ce qui a été corrigé (en).</a></p>\n<p><a href="http://wordpress.org/wordpress-3.8-beta-1.zip">Téléchargez WordPress 3.8 Beta 1</a> (zip) ou utilisez l&rsquo;extension <a href="http://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> (vous voudrez “bleeding edge nightlies”).</p>\n<p><em>Soupe à l&rsquo;Alphabet</em><br />\n<em>Extensions comme fonction à gogo</em><br />\n<em>Le futur c&rsquo;est maintenant<br />\n</em></p>\n<p><em><strong>NB</strong> : Cet article est une traduction adaptée de l&rsquo;<a href="http://wordpress.org/news/2013/11/wordpress-3-8-beta-1/">article original de Matt</a>.</em></p>\n<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=DfxKjx6zZzs:IDOjiIf0W2o:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=DfxKjx6zZzs:IDOjiIf0W2o:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=DfxKjx6zZzs:IDOjiIf0W2o:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=DfxKjx6zZzs:IDOjiIf0W2o:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=DfxKjx6zZzs:IDOjiIf0W2o:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=DfxKjx6zZzs:IDOjiIf0W2o:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/DfxKjx6zZzs" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:65:"http://www.wordpress-fr.net/2013/11/23/wordpress-3-8-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:60:"http://www.wordpress-fr.net/2013/11/23/wordpress-3-8-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:51:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n\n		\n		\n				\n			\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:79:"L’Hebdo WordPress n°208 : WordCamp Paris 2014 – BuddyPress 1.9 – Brèves";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/eWMHFBm5mpY/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:112:"http://www.wordpress-fr.net/2013/11/19/lhebdo-wordpress-n208-wordcamp-paris-2014-buddypress-1-9-breves/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 19 Nov 2013 06:39:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:4:"Blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:5:"Hebdo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:8:"wordcamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://www.wordpress-fr.net/?p=6479";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:359:"WordCamp Paris 2014 On sait donc que le WordCamp Paris 2014 se déroulera les 17 et 18 janvier prochain. L&#8217;appel à sponsors est lancé. Si vous voulez nous aider dans l&#8217;organisation de cet événement alors devenez partenaire ! Si vous voulez être sur scène et partager votre passion pour WordPress, alors l&#8217;appel à orateur est [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Benoît";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4667:"<h3>WordCamp Paris 2014</h3>\n<p>On sait donc que le WordCamp Paris 2014 se déroulera les 17 et 18 janvier prochain. L&rsquo;<a href="http://2014.paris.wordcamp.org/2013/11/13/appel-a-sponsors/">appel à sponsors est lancé</a>. Si vous voulez nous aider dans l&rsquo;organisation de cet événement alors devenez partenaire ! Si vous voulez être sur scène et partager votre passion pour WordPress, alors <a href="http://2014.paris.wordcamp.org/2013/10/29/appel-a-orateurs/">l&rsquo;appel à orateur est ici</a>.</p>\n<h3>WordCamp Cape Town</h3>\n<p><a href="http://www.youtube.com/watch?v=YOVqmjgdEcg&amp;feature=youtu.be">Le WordCamp de Cap Town fait son résumé en vidéo (en)</a>. Classe !</p>\n<h3>Un forum pour les WordCamp</h3>\n<p>WordCamp Central met en place un <a href="http://plan.wordcamp.org/forums/">forum pour les organisateur (en)</a>.</p>\n<h3>Langage et vocabulaire</h3>\n<p>Diane fait le point sur<a href="http://dianebourque.com/2013/11/11/le-langage-et-vocabulaire-de-wordpress/"> les langages et vocabulaires utilisées dans WordPress</a>.</p>\n<h3>BuddyPress et le futur de son thème par défaut</h3>\n<p>La version 1.9 de BuddyPress va redéfinir <a href="http://bpdevel.wordpress.com/2013/11/13/the-future-of-the-bp-default-theme/">la stratégie du thème par défaut (en)</a> pour <a href="http://bp-fr.net/la-fin-du-theme-bp-default/">préparer son abandon</a>.</p>\n<h3>BuddyPress 1.9 Beta 1</h3>\n<p><a href="http://buddypress.org/2013/11/buddypress-1-9-beta-1-is-now-available/">BuddyPress 1.9 beta 1 est disponible (en)</a>.</p>\n<h3>Pippin en interview</h3>\n<p>Pippin Williamson bien connu pour son site pippinsplugins.com a été <a href="http://build.codepoet.com/2013/11/13/pippin-williamson-interview/">interviewé par Code Poet</a>.</p>\n<h3>Améliorer vos commentaires</h3>\n<p>Willy propose son extension qui va permettre d&rsquo;améliorer la gestion des commentaires de votre site : <a href="http://www.geekpress.fr/wordpress/extension/mention-comments-authors-1961/">Mention Comment&rsquo;s Author</a>. Cette extension permet de répondre aux commentaires précédents de manière intuitive.</p>\n<h3>Mettre à jour WordPress automatiquement ?</h3>\n<p>C&rsquo;est la question que se pose Rodrigue. <a href="http://www.cree1site.com/plugin-mise-a-jour-de-plugin-automatique/">Voici les éléments de réponses qu&rsquo;il apporte</a>.</p>\n<h3>Une vulnérabilité dans le framework Themify</h3>\n<p>Une vulnérabilité a été découverte dans le framework Themify. <a href="http://themify.me/blog/urgent-vulnerability-found-in-themify-framework-please-read">Toutes les informations ici</a> (en).</p>\n<h3>Mystique et les mises à jour automatiques</h3>\n<p><a href="http://www.lumieredelune.com/encrelune/utilisateurs-mystique-attention,2013,11">Lumière de Lune met en garde les utilisateurs du thème Mystique</a> avec les mises à jour automatique.</p>\n<h3>Pressnomics, le bon, le mauvais et le génial</h3>\n<p>Chris Lema fait <a href="http://chrislema.com/pressnomics-good-bad-awesome/">son résumé du PressNomics</a>. (en)</p>\n<h3>WordPress 3.8 : A quoi s&rsquo;attendre ?</h3>\n<p>Quelles sont les <a href="http://slocumstudio.com/2013/11/wordpress-3-8-proposals/">nouveautés à attendre de WordPress 3.8</a> ?</p>\n<h3>Installer une extension depuis Github</h3>\n<p><a href="http://www.wptavern.com/how-to-install-wordpress-plugins-directly-from-github">C&rsquo;est ce que nous propose de découvrir WPTavern</a> (en).</p>\n<h3>3 extensions pour gérer LinkedIn</h3>\n<p>Si vous voulez intégrer <a href="http://www.wpjedi.com/linkedin-import-wordpress-plugins/">votre compte LinkedIn avec votre site web</a> (en), voici des extensions utiles.</p>\n<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=eWMHFBm5mpY:WWGPBaP3lrg:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=eWMHFBm5mpY:WWGPBaP3lrg:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=eWMHFBm5mpY:WWGPBaP3lrg:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=eWMHFBm5mpY:WWGPBaP3lrg:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=eWMHFBm5mpY:WWGPBaP3lrg:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=eWMHFBm5mpY:WWGPBaP3lrg:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/eWMHFBm5mpY" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:108:"http://www.wordpress-fr.net/2013/11/19/lhebdo-wordpress-n208-wordcamp-paris-2014-buddypress-1-9-breves/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"5";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:103:"http://www.wordpress-fr.net/2013/11/19/lhebdo-wordpress-n208-wordcamp-paris-2014-buddypress-1-9-breves/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:54:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n		\n\n		\n		\n				\n			\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"L’Hebdo WordPress n°207 : WordPress 3.8 – Communautés – Automattic";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/-r3940AtkOw/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:107:"http://www.wordpress-fr.net/2013/11/13/lhebdo-wordpress-n207-wordpress-3-8-communautes-automattic/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Nov 2013 14:16:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:7:"Astuces";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"Brèves";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:11:"communauté";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:13:"WordPress 3.8";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://www.wordpress-fr.net/?p=6461";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:319:"Avec un jour de retard, voici mon hebdo ! Merci pour votre patience ! WordPress 3.8 Une date de sortie pour WordPress 3.8 (en) : le 12 décembre 2013 (en). Les fonctions qui seront intégrées au core de WordPress 3.8 (en). WordPress 3.8 aura-t-il un générateur de mot de passe (en) ? Dernière ligne droite [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Benoît";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:10355:"<p>Avec un jour de retard, voici mon hebdo ! Merci pour votre patience !</p>\n<h3>WordPress 3.8</h3>\n<ul>\n<li>Une <a href="http://www.bobwp.com/wordpress-3-8-schedule/">date de sortie pour WordPress 3.8 (en)</a> : <a href="http://make.wordpress.org/core/version-3-8-project-schedule/">le 12 décembre 2013</a> (en).</li>\n<li><a href="http://www.wptavern.com/breaking-new-features-selected-to-merge-into-wordpress-3-8-core">Les fonctions qui seront intégrées au core de WordPress 3.8 (en).</a></li>\n<li><a href="http://www.wptavern.com/should-wordpress-include-a-password-generator">WordPress 3.8 aura-t-il un générateur de mot de passe (en)</a> ?</li>\n<li><a href="http://www.wptavern.com/wordpress-twenty-fourteen-project-enters-crunch-time-for-3-8-release">Dernière ligne droite pour le thème 2014 (en)</a>.</li>\n<li>La <a href="http://www.wptavern.com/the-future-of-wordpress-widgets-a-better-ui-with-real-time-previews">nouvelle interface de gestion des widgets (en)</a>.</li>\n</ul>\n<h3>Session WordPress MX</h3>\n<p>La prochaine session WordPress MX (la communauté WordPress du Sud Ouest) <a href="https://www.facebook.com/events/395437210559441/?ref=3&amp;ref_newsfeed_story_type=regular">aura lieu le samedi 23 novembre 2013</a>.</p>\n<h3>Résumé du meetup de Nantes par iMath</h3>\n<p>iMath intervenait au meetup de Nantes la semaine dernière consacré à BuddyPress. <a href="http://imathi.eu/2013/11/08/buddypress-meetup/">Voici son résumé</a>. CMS.fr, présent à ce meetup en profite pour faire <a href="http://www.cms.fr/cms/wordpress/articles-wordpress/375-creer-un-reseau-social-avec-wordpress-et-buddypress.html">une présentation de BuddyPress</a>.</p>\n<h3>Profiter des options de BuddyPress</h3>\n<p>Il est possible de profiter des options de BuddyPress <a href="http://codex.buddypress.org/plugindev/taking-benefits-from-buddypress-settings-to-add-your-plugins-options/">pour ajouter des options à ses extensions </a>(en).</p>\n<h3>WordPress pour Android</h3>\n<p><a href="http://android.wordpress.org/2013/11/11/2-5-release/">La dernière version de WordPress pour Android</a> (en) est disponible au téléchargement.</p>\n<h3>Un bouton &laquo;&nbsp;suivre&nbsp;&raquo; pour wordpress.com</h3>\n<p>WordPress.com, la plateforme commerciale d&rsquo;Automattic vient de <a href="http://www.fredzone.org/bouton-suivre-wordpress-334">mettre à disposition un bouton &laquo;&nbsp;suivre&nbsp;&raquo;</a> installable n&rsquo;importe où.</p>\n<h3>La réussite d&rsquo;Automattic par Matt</h3>\n<p>Matt est interviewé <a href="http://www.businessinsider.com/automattic-no-email-no-office-workers-2013-11">au sujet de la réussite d&rsquo;Automattic</a> (en).</p>\n<h3>Comment participer au développement de WordPress</h3>\n<p>Une vidéo présente<a href="http://speakinginbytes.com/2013/11/contribute-to-wordpress/"> comment participer au développement de WordPress</a> (en).</p>\n<h3>Le futur du développement d&rsquo;extension et la théorie de la ruée vers l&rsquo;or</h3>\n<p>Chris Lema explique <a href="http://chrislema.com/future-wordpress-plugin-development/">sa vision de l&rsquo;avenir du développement d’extensions</a> sur WordPress (en) au travers de la théorie de la ruée vers l&rsquo;or&#8230; <a href="http://wplift.com/wordpress-gold-rush">reprise aussi par WPLift</a> (en).</p>\n<h3>Les notifications dans BuddyPress</h3>\n<p>John James Jacoby présente les <a href="http://jaco.by/2013/11/07/buddypress-notifications/">notifications dans BuddyPress (en)</a>.</p>\n<h3>Présentation de WP-Rocket</h3>\n<p>Une nouvelle présentation de l&rsquo;<a href="http://www.web-geek.fr/wprocket-plugin-cache-wordpress/">extension premium WP-Rocket</a>&#8230; avec une vidéo en prime.</p>\n<h3>La cuvée WordPress</h3>\n<p>Pour les amateurs de bons crus, <a href="https://plus.google.com/u/0/photos/+RodrigueFenard/albums/5943558310403607409/5943558307186656754?sqi=104465035194704257922&amp;sqsi=acc44b17-a607-4d89-99ff-509dcce8ae02&amp;pid=5943558307186656754&amp;oid=104152106088973822260">le millésime WordPress est un choix inévitable</a> !</p>\n<h3>35 % de part de marché en France</h3>\n<p>Selon le site CMSCrawler, WordPress possède <a href="http://www.cmscrawler.com/country/FR">près de 35 % de part de marché en France</a>.</p>\n<h3>Introduction à WP-CLI</h3>\n<p>WP-CLI est très à la mode, c&rsquo;est une interface en ligne de commande pour gérer WordPress. Voici une <a href="http://www.wpmayor.com/code/introduction-wp-cli/">présentation réalisée par WP Mayor</a> (en).</p>\n<h3>ThemeForest atteint 3 millions de dollars de vente</h3>\n<p>ThemeForest vient d&rsquo;atteindre le chiffre impressionnant de <a href="http://www.wpmayor.com/news/themeforest-author-hits-3000000-sales/">3 millions de dollars de ventes totales de thèmes</a> (en).</p>\n<h3>Gravity Form 1.8 Beta 1</h3>\n<p>L&rsquo;extension de formulaires bien connue arrive en <a href="http://www.wptavern.com/gravityforms-1-8-beta-released-introduces-api">version 1.8 et offre plusieurs nouveautés</a> (en).</p>\n<h3>WordPress logo et typographie</h3>\n<p><a href="http://www.frederiquegame.fr/wordpress-logo-et-typographie/">Frédérique Game propose une petite analyse du logo et de la typographie</a> de WordPress.</p>\n<h3>Comment créer un thème enfant</h3>\n<p>Je remets souvent des articles présentant les thèmes enfants car c&rsquo;est vraiment important de connaitre ce fonctionnement des thèmes. <a href="http://wpmu.org/create-wordpress-child-theme/">WPMU.org nous propose donc une nouvelle présentation</a> (en).</p>\n<h3>7 raisons pourquoi les débutants ne devraient pas auto-héberger WordPress</h3>\n<p><a href="http://wpmu.org/7-reasons-why-novices-should-not-self-host-wordpress/">C&rsquo;est provocateur et c&rsquo;est un avis à mon sens très personnel de l&rsquo;auteur</a> (en). Il n&rsquo;a pas tort sur toute la ligne, mais tout le monde ne partagera peut-être pas son avis.</p>\n<h3>Déménager vers un serveur local</h3>\n<p>Il est souvent utile de travailler en local, et déménager son site est parfois complexe. <a href="http://www.wpbeginner.com/wp-tutorials/how-to-move-live-wordpress-site-to-local-server/">Voici une solution en anglais</a> sans WAMP&#8230; <a href="http://www.crazyws.fr/tutos/utiliser-wordpress-en-local-avec-wamp-6YAX8.html">et une autre en français avec WAMP</a>.</p>\n<h3>Programmer une connexion d&rsquo;utilisateur</h3>\n<p>Si vous avez besoin de programmer une connexion d&rsquo;un utilisateur <a href="http://www.wprecipes.com/log-in-a-wordpress-user-programmatically">cette démarche peut vous intéresser</a> (en).</p>\n<h3>Optimiser son référencement</h3>\n<p><a href="http://wpformation.com/optimiser-referencement-wordpress/">Fabrice présente le nouveau livre de Daniel Roch </a>sur le référencement.</p>\n<h3>Comment faire une recherche sous forme de bouton rétractable</h3>\n<p>Un tutoriel vous apprendra comment réaliser un<a href="http://www.wpbeginner.com/wp-themes/how-to-add-a-search-toggle-effect-in-wordpress/"> champ de recherche qui s&rsquo;ouvre à la demande</a> (en).</p>\n<h3>WordPress et le SEO</h3>\n<p>Le <a href="http://fr.slideshare.net/SeoMix/wordpress-et-seo-seocampus-2013">diaporama de Daniel Roch</a> utilisé lors du SEOCamp 2013 est en ligne.</p>\n<h3>Créer des règles pour vos auteurs</h3>\n<p><a href="http://www.cree1site.com/regles-auteurs-wordpress/">Rodrigue explique comment créer des règles</a> pour les auteurs.</p>\n<h3>Posez-moi une question</h3>\n<p><a href="http://boiteaweb.fr/posez-question-1-action-page-7705.html">Julio se lance dans la réponse aux questions des utilisateurs</a>. La règle du jeu est simple. Il prend une question parmi celle qu&rsquo;on lui pose via un formulaire et y répond.</p>\n<h3>Une réflexion sur les défauts de WordPress</h3>\n<p>WordPress a aussi des défauts, <a href="http://eamann.com/biz/wordpress-falling-behind-still-leading/">voici quelques critiques</a>, qui se veulent constructives (en).</p>\n<h3>Le WordPress des blogueurs</h3>\n<p><a href="http://wpformation.com/blogueurs-wordpress/">Fabrice a demandé à des blogueurs</a> de décrire leur utilisation de WordPress, ainsi que les thèmes et extensions utilisés.</p>\n<h3>Pourquoi WordPress est le meilleur outil pour votre site web ?</h3>\n<p>TeslaThemes démontre pourquoi <a href="http://teslathemes.com/blog/why-wordpress-is-the-best-solution-for-your-website/">WordPress est le meilleur outil pour un site web (en).</a>.. et donc pourquoi ils l&rsquo;utilisent.</p>\n<h3>Exclure les formats d&rsquo;articles de la boucle</h3>\n<p><a href="http://wpchannel.com/exclure-post_formats-formats-articles-boucle-wordpress/">WP Channel explique comment exclure les formats d&rsquo;article de la la boucle</a> WordPress.</p>\n<h3>2 tutos pour personnaliser son WordPress</h3>\n<ul>\n<li><a href="http://wp.tutsplus.com/tutorials/creative-coding/customizing-the-wordpress-admin-adding-styling/">Personnaliser l&rsquo;admin</a> (en).</li>\n<li><a href="http://wp.tutsplus.com/tutorials/theme-development/a-guide-to-the-wordpress-theme-customizer-review-and-resources/">Personnaliser son thème.</a> (en)</li>\n</ul>\n<h3>Matt en conférence chez Joomla !</h3>\n<p>Lors du rendez-vous annuel de Joomla! Matt Mullenweg était invité. <a href="http://www.wptavern.com/wordpress-co-founder-matt-mullenweg-keynotes-joomla-world-conference">Il a parlé de WordPress, évidemment</a> (en) !</p>\n<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=-r3940AtkOw:UGJrjenxuEc:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=-r3940AtkOw:UGJrjenxuEc:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=-r3940AtkOw:UGJrjenxuEc:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=-r3940AtkOw:UGJrjenxuEc:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=-r3940AtkOw:UGJrjenxuEc:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=-r3940AtkOw:UGJrjenxuEc:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/-r3940AtkOw" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:103:"http://www.wordpress-fr.net/2013/11/13/lhebdo-wordpress-n207-wordpress-3-8-communautes-automattic/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"9";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:98:"http://www.wordpress-fr.net/2013/11/13/lhebdo-wordpress-n207-wordpress-3-8-communautes-automattic/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:48:"\n		\n		\n		\n		\n		\n				\n		\n		\n\n		\n		\n				\n			\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:40:"WordPress Francophone et l’affiliation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/mKzBNZZi8IM/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:83:"http://www.wordpress-fr.net/2013/11/13/wordpress-francophone-laffiliation/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Nov 2013 06:18:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:21:"WordPress Francophone";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:11:"affiliation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:11:"communauté";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://www.wordpress-fr.net/?p=6455";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:409:"En raison d&#8217;une recrudescence de liens affiliés dans les contenus que nous souhaitons publier, nous avons souhaité préciser notre position éditoriale à ce sujet. Nous voulions vraiment davantage de transparence à propos de l&#8217;affiliation. Quels contenus ont leur place dans les publications (Hebdo, Planet, etc.) de WordPress Francophone (WPFR) ? Avec l&#8217;utilisation de plus en [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Benoît";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:7111:"<p>En raison d&rsquo;une recrudescence de liens affiliés dans les contenus que nous souhaitons publier, nous avons souhaité préciser notre position éditoriale à ce sujet. Nous voulions vraiment davantage de transparence à propos de l&rsquo;affiliation.</p>\n<p>Quels contenus ont leur place dans les publications (Hebdo, <a href="En raison d\'une recrudescence de liens affiliés dans les contenus que nous souhaitons publier, nous avons souhaité préciser notre position éditoriale à ce sujet. Nous voulions vraiment davantage de transparence à propos de l\'affiliation.  Quels contenus ont leur place dans les publications (Hebdo, Planet, etc.) de WordPress Francophone (WPFR) ?  Avec l\'utilisation de plus en plus fréquente de liens affiliés dans les articles diffusés, nous devions prendre une décision.  Jusqu\'à maintenant, notre ligne de conduite était stricte. Les contenus avec liens affiliés étaient proscrits des publications de WPFR. Ainsi les liens publiés dans l\'hebdo se révélant contenir de l\'affiliation étaient supprimés, souvent a posteriori lorsqu\'ils n\'avaient pas été décelés avant. De même, les sites utilisant l\'affiliation en masse n\'ont pas leur place dans le Planet (cela ne changera pas).  La réalité est que de plus en plus de sites, dont le contenu est pourtant intéressant, utilisent des liens affiliés. En les supprimant ou en ne les diffusant pas, nous nous privons donc de contenus pertinents. C\'est pourquoi nous avons décidé d\'assouplir quelque peu nos règles, non pas pour encourager l\'affiliation, mais pour l\'encadrer, et ce de la manière suivante :  si un contenu est juste une collection de liens d\'affiliation, sans réelle valeur ajoutée, il ne sera pas diffusé sur WPFR. si un contenu réalise une vraie recherche / explication et est pertinent, qu\'il propose aussi des liens non affiliés et diffuse de temps en temps des liens affiliés, il pourra être diffusé dans l\'hebdo. si un contenu avec lien d’affiliation est déjà passé dans le Planet (parce qu\'un site déjà validé pour le Planet diffuse un lien affilié), il ne repassera pas dans l\'hebdo, à moins que ce contenu soit vraiment exceptionnel. si un site présent dans le Planet se met à user largement de l\'affiliation au détriment de son contenu, il pourra être supprimé du Planet. un site non présent dans le Planet usant en masse de l\'affiliation perdra toute chance d\'y figurer s\'il en fait la demande. Nous pensons que ces quelques règles permettent de maintenir un certain équilibre afin que la communauté ne passe pas au travers de contenus vraiment intéressants. Simplement, WPFR n\'a pas vocation à devenir une vitrine commerciale pour les sites qui chercheraient uniquement à profiter du trafic de notre portail.  Et parce que nous ne sommes que des êtres humains, n\'hésitez pas à nous signaler les liens où notre vigilance à failli !  Les commentaires sont ouverts... et le débat aussi. Vous pouvez donner votre avis sur cette question Ô combien polémique qu\'est l\'affiliation.  P.S. : Étant en congé, j\'ai pris quelques largesse sur le jour de la publication de l\'hebdo... mais comme on dit, mieux vaut tard que jamais ! Il paraîtra dans la journée.">Planet</a>, etc.) de WordPress Francophone (WPFR) ?</p>\n<p>Avec l&rsquo;utilisation de plus en plus fréquente de liens affiliés dans les articles diffusés, nous devions prendre une décision.</p>\n<p>Jusqu&rsquo;à maintenant, notre ligne de conduite était stricte. Les contenus avec liens affiliés étaient proscrits des publications de WPFR. Ainsi les liens publiés dans l&rsquo;hebdo se révélant contenir de l&rsquo;affiliation étaient supprimés, souvent a posteriori lorsqu&rsquo;ils n&rsquo;avaient pas été décelés avant. De même, les sites utilisant l&rsquo;affiliation en masse n&rsquo;ont pas leur place dans le Planet (cela ne changera pas).</p>\n<p>La réalité est que de plus en plus de sites, dont le contenu est pourtant intéressant, utilisent des liens affiliés. En les supprimant ou en ne les diffusant pas, nous nous privons donc de contenus pertinents. C&rsquo;est pourquoi nous avons décidé d&rsquo;assouplir quelque peu nos règles, non pas pour encourager l&rsquo;affiliation, mais pour l&rsquo;encadrer, et ce de la manière suivante :</p>\n<ul>\n<li>si un contenu est juste une collection de liens d&rsquo;affiliation, sans réelle valeur ajoutée, il ne sera pas diffusé sur WPFR.</li>\n<li>si un contenu réalise une vraie recherche / explication et est pertinent, qu&rsquo;il propose aussi des liens non affiliés et diffuse de temps en temps des liens affiliés, il pourra être diffusé dans l&rsquo;hebdo.</li>\n<li>si un contenu avec lien d’affiliation est déjà passé dans le Planet (parce qu&rsquo;un site déjà validé pour le Planet diffuse un lien affilié), il ne repassera pas dans l&rsquo;hebdo, à moins que ce contenu soit vraiment exceptionnel.</li>\n<li>si un site présent dans le Planet se met à user largement de l&rsquo;affiliation au détriment de son contenu, il pourra être supprimé du Planet.</li>\n<li>un site non présent dans le Planet usant en masse de l&rsquo;affiliation perdra toute chance d&rsquo;y figurer s&rsquo;il en fait la demande.</li>\n</ul>\n<p>Nous pensons que ces quelques règles permettent de maintenir un certain équilibre afin que la communauté ne passe pas au travers de contenus vraiment intéressants. Simplement, WPFR n&rsquo;a pas vocation à devenir une vitrine commerciale pour les sites qui chercheraient uniquement à profiter du trafic de notre portail.</p>\n<p>Et parce que nous ne sommes que des êtres humains, n&rsquo;hésitez pas à nous signaler les liens où notre vigilance à failli !</p>\n<p>Les commentaires sont ouverts&#8230; et le débat aussi. Vous pouvez donner votre avis sur cette question Ô combien polémique qu&rsquo;est l&rsquo;affiliation.</p>\n<p><em><strong>P.S.</strong> : Étant en congé, j&rsquo;ai pris quelques largesse sur le jour de la publication de l&rsquo;hebdo&#8230; mais comme on dit, mieux vaut tard que jamais ! Il paraîtra dans la journée.</em></p>\n<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=mKzBNZZi8IM:0tm1X7f_edU:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=mKzBNZZi8IM:0tm1X7f_edU:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=mKzBNZZi8IM:0tm1X7f_edU:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=mKzBNZZi8IM:0tm1X7f_edU:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=mKzBNZZi8IM:0tm1X7f_edU:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=mKzBNZZi8IM:0tm1X7f_edU:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/mKzBNZZi8IM" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:79:"http://www.wordpress-fr.net/2013/11/13/wordpress-francophone-laffiliation/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:74:"http://www.wordpress-fr.net/2013/11/13/wordpress-francophone-laffiliation/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:51:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n\n		\n		\n				\n			\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WordCamp Paris 2014 : et si vous étiez orateur ?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/g_h34lO6c00/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:90:"http://www.wordpress-fr.net/2013/11/05/wordcamp-paris-2014-si-vous-etiez-orateur/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 05 Nov 2013 11:31:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:16:"Association WPFR";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:11:"Evènements";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://www.wordpress-fr.net/?p=6434";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:367:"Le 17 janvier prochain (2014) se tiendra le troisième WordCamp Paris. On espère que ça sera pour autant de gens que possible l’occasion de se retrouver pour échanger, apprendre et… s’amuser autour de WordPress. Un WordCamp, c’est avant tout des conférences sur  WordPress. Mais de quoi y parle-t-on exactement ? Vous voulez quelques exemples ? [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Benjamin Lupu";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:5749:"<p><strong>Le 17 janvier prochain (2014) se tiendra le troisième WordCamp Paris.</strong> On espère que ça sera pour autant de gens que possible l’occasion de se retrouver pour échanger, apprendre et… s’amuser autour de WordPress.</p>\n<p>Un WordCamp, c’est avant tout <strong>des conférences sur  WordPress</strong>. Mais de quoi y parle-t-on exactement ? Vous voulez quelques exemples ? C’est parti !</p>\n<h2>De la technique</h2>\n<p>Les conférences d’un WordCamp sont-elles forcément techniques ? Non bien sûr. Mais c’est quand même l’occasion de bénéficier de conférences sur les bonnes pratiques techniques pour WordPress (développements de plugins et thèmes, performance, sécurité, déploiements…).</p>\n<h2>Des études de cas</h2>\n<p>Vous êtes décisionnaire en entreprise ? Entrepreneur ? Agence ? Freelance ? Responsable associatif ? Alors qu’est-ce qu’on peut faire avec WordPress ? Des orateurs viennent présenter leurs réalisations WordPress avec les bons et les mauvais côtés (pas de blah blah). On peut aussi parler de comment on monte un projet WordPress.</p>\n<h2>Du marketing</h2>\n<p>WordPress peut être un très bon outil marketing. SEO, Analytics, social, quelles sont les bonnes pratiques pour tirer le maximum de WordPress et soigner son marketing digital ?</p>\n<h2>L’écosystème WordPress</h2>\n<p>WordPress, c’est un logiciel mais c’est aussi un écosystème : thèmes, plugins, hébergeurs, services SaaS, gratuit ou premium ? Comment on s’y retrouve ? Comment choisir ? Comment profiter au maximum de cet écosystème ?</p>\n<h2>Au-delà de WordPress et vers l’infini</h2>\n<p>WordPress est peut-être un peu plus qu’un CMS. Ajoutez-y une pincée de BuddyPress et le voilà Réseau social, installez BBPress et vous aurez un forum de support. Deux exemples parmi beaucoup d’autres sur les 1001 visages de WordPress.</p>\n<h2>La communauté</h2>\n<p>Essentielle ! Comment organise-t-on un meetup, un WordCamp, comment peut-on participer et s’impliquer dans le développement de WordPress (qu&rsquo;on soit technicien ou pas) ?</p>\n<h2>Alors prêt(e) pour être orateur ou oratrice au prochain WordCamp ?</h2>\n<p>Le fameux « <a title="Lien vers l\'appel à orateurs du WordCamp Paris 2014" href="http://2014.paris.wordcamp.org/2013/10/29/appel-a-orateurs/">appel à orateurs</a> »a été lancé. Alors pourquoi pas vous ? Il n’y a pas besoin d’être un orateur ou une oratrice professionnel(le). La communauté est plutôt bienveillante. Elle est même avide d’apprendre et d’échanger avec vous en fait. Si vous pensez pouvoir développer un sujet dont vous êtes fier(e) et de le partager, n’hésitez pas une seconde ! L’expérience en vaut le coup.</p>\n<h2>Petite mention finale (mais qui a son importance)</h2>\n<p>Les WordCamps ne sont pas des tribunes commerciales, politiques ou religieuses. Ils ont vocation à faire la promotion de la démarche open source (et de WordPress bien sûr). Quoi, je ne peux pas parler business ?! Si, si (et de bien d’autres choses) mais en respectant certaines règles simples.</p>\n<ul>\n<li>La première et la plus simple : votre sujet doit avoir un rapport avec… WordPress <img src=\'http://www.wordpress-fr.net/wp-includes/images/smilies/icon_wink.gif\' alt=\';-)\' class=\'wp-smiley\' /> </li>\n<li>Vous pouvez vous présenter brièvement, ainsi que votre société, activité, association… Cette présentation doit avant tout servir au public à savoir à qui il a affaire (développeur, designer, entrepreneur, amateur…)</li>\n<li>La mention des activités commerciales doit avant tout servir d’exemple et de retour d’expérience et non pas à faire une promotion brute d’un service payant</li>\n</ul>\n<p>Donc les agences, les entreprises, les services premiums, c’est n’est pas le mal mais le WordCamp n’est pas un terrain de chasse pour les commerciaux avant-vente. C’est un espace de partage ouvert et attentif aux besoins des utilisateurs. Vos réponses doivent avoir une valeur ajoutée (et j’ai tendance à croire que c’est aussi  une des meilleures formes d’avant-vente mais ça n’engage que moi).</p>\n<p>Attendez-vous aussi à des questions du public sur la démarche open source de votre activité ou votre entreprise. Les gens chercheront à savoir ce que vous apportez à la communauté (et je vous encourage à apporter quelque chose à la communauté).</p>\n<h3 style="text-align: center;"><a title="Lien vers l\'appel à orateurs pour le WordCamp Paris 2014" href="http://2014.paris.wordcamp.org/2013/10/29/appel-a-orateurs/">Je propose une ou plusieurs conférences</a></h3>\n<p>&nbsp;</p>\n<p><strong>Voilà, on espère vous voir nombreux et en forme le 17 janvier prochain ! A bientôt.</strong></p>\n<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=g_h34lO6c00:RVTsZHl76rU:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=g_h34lO6c00:RVTsZHl76rU:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=g_h34lO6c00:RVTsZHl76rU:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=g_h34lO6c00:RVTsZHl76rU:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=g_h34lO6c00:RVTsZHl76rU:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=g_h34lO6c00:RVTsZHl76rU:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/g_h34lO6c00" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:86:"http://www.wordpress-fr.net/2013/11/05/wordcamp-paris-2014-si-vous-etiez-orateur/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"20";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:81:"http://www.wordpress-fr.net/2013/11/05/wordcamp-paris-2014-si-vous-etiez-orateur/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:66:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n		\n		\n		\n		\n		\n\n		\n		\n				\n			\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:73:"L’Hebdo WordPress n°206 : Communautés – Interview – WordPress 3.8";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/fnqmpPtvQrc/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:106:"http://www.wordpress-fr.net/2013/11/05/lhebdo-wordpress-n206-communautes-interview-wordpress-3-8/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 05 Nov 2013 06:02:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:9:{i:0;a:5:{s:4:"data";s:7:"Astuces";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:14:"Développement";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:21:"WordPress Francophone";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:11:"communauté";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:5:"Hebdo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:7;a:5:{s:4:"data";s:8:"wordcamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:8;a:5:{s:4:"data";s:13:"WordPress 3.8";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://www.wordpress-fr.net/?p=6429";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:363:"WordCamp Europe 2013 Julio propose un débriefing 1 mois après. WPArmchair (en) : le site qui suit les WordCamps à la trace. Explications (en). L&#8217;interview de Benoît Catherineau sur Code Poet Une interview de votre digne serviteur (en) (oui moi quoi ! ^^) sur le site codepoet.com où il est question de la communauté francophone&#8230; entre [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Benoît";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:8566:"<h3>WordCamp Europe 2013</h3>\n<ul>\n<li>Julio propose <a href="http://boiteaweb.fr/wordcamp-europe-2013-un-mois-apres-7659.html">un débriefing 1 mois après</a>.</li>\n<li><a href="http://wparmchair.com/">WPArmchair (en)</a> : le site qui suit les WordCamps à la trace. <a href="http://www.wptavern.com/monitor-wordcamps-online-with-wp-armchair">Explications (en)</a>.</li>\n</ul>\n<h3>L&rsquo;interview de Benoît Catherineau sur Code Poet</h3>\n<p><a href="http://build.codepoet.com/2013/10/31/benoit-catherineau-interview/">Une interview de votre digne serviteur (en)</a> (oui moi quoi ! ^^) sur le site codepoet.com où il est question de la communauté francophone&#8230; entre autres choses. C&rsquo;est en anglais.</p>\n<h3>La communauté belge renait ?</h3>\n<p>La communauté belge serait elle de retour ? <a href="http://wpmeetup.be/">En tout cas des projets semblent éclore.</a></p>\n<h3>BuddyPress : des requêtes par groupes</h3>\n<p>Depuis la version 1.8, il est possible de faire des <a href="http://codex.buddypress.org/plugindev/group-meta-queries-usage-example/">requêtes par groupes de données (en)</a>.</p>\n<h3>WordPress 3.8 : projet d&rsquo;interface widgets</h3>\n<p>L&rsquo;interface des widgets de WordPress 3.8 <a href="https://cloudup.com/cnzqmrlxcaL">pourrait ressembler à cela (en)</a>.</p>\n<h3>The Walking Web n°12 : WordPress</h3>\n<p><a href="http://www.youtube.com/watch?v=L9JnwSU7Txg&amp;feature=youtu.be">Le podcast The Walking Web</a> aborde pour sa douzième édition le thème de WordPress, avec Noël Tock comme invité.</p>\n<h3>Rentabiliser votre site mais pas en monnaie</h3>\n<p>Une façon de rentabiliser votre site sans parler d&rsquo;argent ? <a href="http://wpmu.org/how-to-power-your-wordpress-site-with-a-social-paywall/">Jeter un oeil ici(en)</a>.</p>\n<h3>Un guide pour les styles d&rsquo;interface</h3>\n<p>Voici un <a href="http://www.wptavern.com/wordpress-style-guide-a-reference-for-admin-ui-components">guide pour les styles (en)</a> d&rsquo;interfaces utilisateurs de vos extensions.</p>\n<h3>Optimiser la vitesse de votre site</h3>\n<p>Des conseils pour <a href="http://www.catswhocode.com/blog/speeding-up-your-wordpress-blog-7-effective-solutions">accélérer la vitesse de votre site (en)</a>.</p>\n<h3>1001 icônes HD pour WordPress</h3>\n<p><a href="http://wpformation.com/icones-wordpress-plugin/">Fabrice présente 1001 icônes</a> (je les ai pas comptées hein ! Je te fais confiance Fabrice <img src=\'http://www.wordpress-fr.net/wp-includes/images/smilies/icon_wink.gif\' alt=\';)\' class=\'wp-smiley\' />  ) pour WordPress&#8230; et en HD !</p>\n<h3>Activer la mise à jour automatique pour les versions majeures</h3>\n<p>WordPress 3.7 apporte les mises à jour automatique pour les versions mineures de sécurité et maintenance. Si vous souhaitez aussi activer les mises à jour automatiques pour les versions majeures, <a href="http://www.wpbeginner.com/wp-tutorials/how-to-enable-automatic-updates-in-wordpress-for-major-releases/">les explications sont dans cet article (en)</a>.</p>\n<h3>jQuery et WordPress : Une barre latérale flottante</h3>\n<p>Comment créer une <a href="http://wpchannel.com/jquery-sidebar-flottante-wordpress/">barre latérale flottante qui suivra les scrolls de la souris</a> ? facile !</p>\n<h3>Un T-Shirt pour WordPress 3.7</h3>\n<p>WordPress 3.7 <a href="https://twitter.com/dimensionmedia/status/395300465555943424/photo/1">aura son T-Shirt</a> !</p>\n<h3>Installer une extension depuis Github</h3>\n<p>Si vous vous voulez installer une extension depuis Github, <a href="http://www.wptavern.com/how-to-install-wordpress-plugins-directly-from-github">voici la démarche à suivre (en)</a>.</p>\n<h3>WordPress 3.7.1 : une mise à jour historique</h3>\n<p>Eh oui ! C&rsquo;est la <a href="http://www.wptavern.com/wordpress-3-7-1-a-historical-maintenance-release">première mise à jour a se faire automatiquement (en)</a>. Apprenez à <a href="http://www.wptavern.com/how-to-configure-automatic-core-updates-for-wordpress-3-7">configurer cette nouvelle fonctionnalité (en)</a>&#8230; ou à <a href="http://www.vingthuitzerotrois.fr/wordpress/desactiver-les-mises-a-jour-automatiques-de-wordpress-15558/">la désactiver</a>.</p>\n<h3>100 000 000 000 (100 milliards) d&rsquo;indésirables bloqués par Akismet</h3>\n<p>L&rsquo;extension antispam Akismet vient de <a href="http://ma.tt/2013/10/akismet-100b/">bloquer son 100 000 000 000e spam (en)</a>.</p>\n<h3>WordPress.com au 7e rang de trafic américain</h3>\n<p>WordPress.com vient d&rsquo;atteindre <a href="http://www.wptavern.com/wordpress-com-moves-up-to-7-ranked-website-for-us-traffic">le 7e rang des sites au plus fort trafic (en)</a>.</p>\n<h3>9 thèmes d&rsquo;hôtel</h3>\n<p>Vous souhaitez réaliser un site pour un hôtel, choisissez <a href="http://www.geekpress.fr/wordpress/guide/themes-hotel-attractif-1940/">parmi cette liste de 9 thèmes</a>.</p>\n<h3>Comment créer une base de données MySQL</h3>\n<p>Démarche originale s&rsquo;il en est, <a href="http://wp-site-pro.com/wordpress-comment-creer-base-donnees-mysql/">la création de la base de données de WordPress</a>&#8230; juste au cas où ! ^^</p>\n<h3>Les locaux d&rsquo;Automattic sur Google Maps en Street View</h3>\n<p>Vous pouvez désormais visiter les locaux d&rsquo;Automattic depuis chez vous via <a href="http://jkudish.com/2013/10/31/automattic-is-on-google-maps/">Street View sur Google Maps</a>.</p>\n<h3>Hook pour genesis</h3>\n<p>Un <a href="http://www.jeremy-allard.com/seo/petit-hook-pour-modifier-vos-balises-hn-sous-genesis">hook</a> pour modifier les balises h1-h2-h3-&#8230; du thème Genesis.</p>\n<h3>15 extensions Vimeo</h3>\n<p>Vous êtes un utilisateurs de Viméo ? <a href="http://www.wpjedi.com/wordpress-vimeo-plugins/">Ces extensions vous intéresseront peut-être (en)</a>.</p>\n<h3>Récupérer des vignettes de YouTube et Dailymotion</h3>\n<p>Si vous voulez récupérer les vignettes de vidéos YouTube ou Dailymotion, <a href="http://apis.tweetpress.fr/thumbnails-youtube-dailymotion/399">utilisez les API correspondantes</a>.</p>\n<h3>La playlist de WordSesh</h3>\n<p>Au printemps a eu lieu WordSesh, un marathon de conférences WordPress en ligne durant 24 heures. <a href="http://www.youtube.com/watch?v=h_KyXG3-5QI&amp;list=PL9bmvLB3RpG7zGrbwbd2R9a2tqT-FiYiG&amp;index=8">La playlist complète est disponible en ligne (en)</a>.</p>\n<h3>Traduire une extension et la rendre traduisible</h3>\n<p>Les <a href="http://wpmu.org/localize-a-wordpress-plugin-and-make-it-translation-ready/">explications de la traduction des extensions (en)</a> WordPress sont détaillées ici.</p>\n<h3>Un framework pour créer une extension</h3>\n<p>Voici un framework pour créer <a href="https://github.com/Darklg/WPUtilities/tree/master/wp-content/plugins/wpubaseplugin">votre première extension (en)</a>.</p>\n<h3>Ajouter un carrousel de logo</h3>\n<p>Découvrez une méthode pour réaliser un <a href="http://www.practicalwp.com/how-to-add-a-logo-carousel-to-wordpress/">carrousel de logos (en)</a>.</p>\n<h3>Testez vos thèmes et extensions</h3>\n<p><a href="http://www.wptavern.com/wp-test-unit-testing-data-for-wordpress-themes-and-plugins">WP-Test est un site qui permet de tester vos extensions et vos thèmes (en)</a> avant leur diffusion.</p>\n<h3>Augmenter la limite de chargement</h3>\n<p>Apprenez à modifier <a href="http://wpmu.org/increase-maximum-upload-limit-wordpress/">certaines limites de chargements (en).</a></p>\n<h3>15 thèmes plein écran</h3>\n<p><a href="http://wpmu.org/15-gorgeous-fullscreen-video-wordpress-themes/">15 superbes thèmes plein écran</a>.</p>\n<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=fnqmpPtvQrc:7BsSyWN79lA:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=fnqmpPtvQrc:7BsSyWN79lA:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=fnqmpPtvQrc:7BsSyWN79lA:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=fnqmpPtvQrc:7BsSyWN79lA:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=fnqmpPtvQrc:7BsSyWN79lA:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=fnqmpPtvQrc:7BsSyWN79lA:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/fnqmpPtvQrc" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:102:"http://www.wordpress-fr.net/2013/11/05/lhebdo-wordpress-n206-communautes-interview-wordpress-3-8/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:97:"http://www.wordpress-fr.net/2013/11/05/lhebdo-wordpress-n206-communautes-interview-wordpress-3-8/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"\n		\n		\n		\n		\n		\n				\n		\n\n		\n		\n				\n			\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Disponibilité de WordPress 3.7.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/hOjsg5ODTd0/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:81:"http://www.wordpress-fr.net/2013/10/30/disponibilite-de-wordpress-3-7-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 30 Oct 2013 09:43:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:4:"Blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://www.wordpress-fr.net/?p=6418";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:413:"WordPress 3.7.1 est disponible ! Cette version de maintenance corrige 11 bugs de WordPress 3.7, notamment : Les images avec sous-titre n&#8217;apparaissent plus cassées dans l&#8217;éditeur visuel Les sites installés sur des serveurs anciens ou mal configurés peuvent vérifier l&#8217;existence de mises à jour sur WordPress.org. Certaines extensions qui appelaient des fonctions de WordPress trop [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Xavier";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2973:"<p>WordPress 3.7.1 est disponible ! Cette version de maintenance corrige 11 bugs de WordPress 3.7, notamment :</p>\n<ul>\n<li>Les images avec sous-titre n&rsquo;apparaissent plus cassées dans l&rsquo;éditeur visuel</li>\n<li>Les sites installés sur des serveurs anciens ou mal configurés peuvent vérifier l&rsquo;existence de mises à jour sur WordPress.org.</li>\n<li>Certaines extensions qui appelaient des fonctions de WordPress trop tôt provoquaient des erreurs fatales.</li>\n<li>Correction du tri hiérarchique de get_pages(), des exclusions dans wp_list_categories(), et de in_category() quand elle était appelée avec des valeurs vides.</li>\n<li>Correction d&rsquo;un avertissement qui pouvait se déclencher dans certaines configurations lors d&rsquo;une recherche, et de quelques autres notifications.</li>\n</ul>\n<p>Pour une liste complète des modifications, consultez <a href="http://core.trac.wordpress.org/query?milestone=3.7.1">la liste des tickets</a> et <a href="http://core.trac.wordpress.org/log/branches/3.7?stop_rev=25914&amp;rev=25986">le changelog</a>.</p>\n<p>Si vous faites partie des <a href="http://wordpress.org/download/counter/">presque deux millions</a> d&rsquo;utilisateurs qui sont passés à WordPress 3.7, nous allons déclencher la <a href="http://wordpress.org/news/2013/10/basie/">mise à jour automatique &laquo;&nbsp;en coulisse&nbsp;&raquo;</a> de WordPress 3.7.1 dans quelques heures. Pour <a href="http://wordpress.org/plugins/background-update-tester/">les sites qui y ont accès</a>, bien sûr.</p>\n<p><a href="http://fr.wordpress.org/">Téléchargez WordPress 3.7.1</a> ou rendez-vous dans votre Tableau de bord, et cliquez sur &laquo;&nbsp;Mettre à jour maintenant&nbsp;&raquo; .</p>\n<p><em>Quelques corrections</em><br />\n<em>La mise-à-jour attitude :</em><br />\n<em>Plus rien à cliquer</em></p>\n<p><em>(cet article est une traduction de <a href="http://wordpress.org/news/2013/10/wordpress-3-7-1/">l&rsquo;annonce originale</a>)</em></p>\n<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=hOjsg5ODTd0:P2YtVwg09hU:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=hOjsg5ODTd0:P2YtVwg09hU:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=hOjsg5ODTd0:P2YtVwg09hU:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=hOjsg5ODTd0:P2YtVwg09hU:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=hOjsg5ODTd0:P2YtVwg09hU:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=hOjsg5ODTd0:P2YtVwg09hU:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/hOjsg5ODTd0" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:77:"http://www.wordpress-fr.net/2013/10/30/disponibilite-de-wordpress-3-7-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"12";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:72:"http://www.wordpress-fr.net/2013/10/30/disponibilite-de-wordpress-3-7-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:57:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n		\n		\n\n		\n		\n				\n			\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"L’Hebdo WordPress n°205 : WordCamps – Communautés françaises – WordPress 3.7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/ZU1HTgjM-is/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:117:"http://www.wordpress-fr.net/2013/10/29/lhebdo-wordpress-n205-wordcamps-communautes-francaises-wordpress-3-7/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 29 Oct 2013 06:45:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:7:"Astuces";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:11:"Evènements";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:11:"communauté";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:5:"Hebdo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:13:"WordPress 3.7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://www.wordpress-fr.net/?p=6404";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:401:"Les derniers WordCamps 2013 Le WordCamp Paris 2013 faisait partie des premiers WordCamps de l&#8217;année. Voici la liste des derniers événements WordPress (en) à travers le monde. &#8230; et pour 2014&#8230; me direz-vous ? &#8230; On prend les mêmes et on recommence&#8230; préparez-vous pour participer à l&#8217;un des tous premiers événements WordPress de l&#8217;année ! (Du [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Benoît";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:5031:"<h3>Les derniers WordCamps 2013</h3>\n<p>Le WordCamp Paris 2013 faisait partie des premiers WordCamps de l&rsquo;année. Voici <a href="http://wordpress.org/news/2013/10/upcoming-wordcamps-4/?fb_source=pubv1">la liste des derniers événements WordPress (en)</a> à travers le monde.</p>\n<p>&#8230; et pour 2014&#8230; me direz-vous ? &#8230; On prend les mêmes et on recommence&#8230; préparez-vous pour participer à l&rsquo;un des tous premiers événements WordPress de l&rsquo;année !</p>\n<p>(<em>Du teasing se cache dans ce paragraphe, sauras-tu le retrouver ? ^^</em> )</p>\n<h3>WordCamp Europe 2013</h3>\n<p><a href="http://blog.nicolas-juen.fr/2013/10/22/wceu-the-life-of-theme/">Nicolas Juen continue son récapitulatif </a>de ce WordCamp européen.</p>\n<h3>4e session de WordPress MX</h3>\n<p>WordPress MX est l&rsquo;association de la communauté WordPress du Sud Ouest. <a href="http://wpmx.org/session-4-wordpress-les-solutions-e-commerce/">Elle organisait déjà sa 4e session</a>.</p>\n<h3>WordPress Meetup à la Cantine de Nantes</h3>\n<p>La communauté nantaise n&rsquo;est pas en reste. <a href="http://cantine.atlantic2.org/evenements/word-press-meetup/">Elle organise un meetup le 7 novembre autour de BuddyPress</a> avec la participation de Mathieu Viet (iMath) et Pierre Dickinson.</p>\n<h3>WordPress 3.7</h3>\n<ul>\n<li>WordPress 3.7 apporte la mise à jour automatique du core, mais peux aussi <a href="http://www.geekpress.fr/wordpress/astuce/activer-maj-automatique-plugins-themes-1936/">le faire pour les thèmes et les extension</a>s. On peut aussi<a href="http://www.geekpress.fr/wordpress/astuce/limiter-maj-auto-plugins-themes-1938/"> limiter cette fonction aux extensions et thèmes désirés</a>.</li>\n<li>Les <a href="http://wpstartpage.com/wordpress-3-7-interesting-details/">points intéressants de WordPress 3.7 (en)</a>.</li>\n<li><a href="http://wpchannel.com/wordpress-3-7-basie-telecharger/">Présentation de WordPress 3.7</a>.</li>\n<li><a href="http://www.wptavern.com/wordpress-automatic-updates-no-options-for-you">Des explications sur les mises à jour automatique (en)</a> et <a href="http://boiteaweb.fr/wordpress-3-7-mises-jours-automatiques-7667.html">en français par Julio</a>.</li>\n</ul>\n<h3>Un livre sur le développement de thème BuddyPress</h3>\n<p>Si vous voulez vous lancer dans le <a href="http://www.wptavern.com/buddypress-theming-book-now-available-on-amazon">développement de thème pour BuddyPress (en)</a>, un livre est d&rsquo;ores et déjà disponible sur Amazon.</p>\n<h3>URL d&rsquo;un avatar</h3>\n<p>Retourner l&rsquo;URL d&rsquo;un avatar en lieu et place de l&rsquo;image est chose peu banale <a href="http://www.screenfeed.fr/blog/url-dun-avatar-avec-get_avatar_url-01496/">mais voici comment on fait</a>.</p>\n<h3>PressNomics, WordPress côté business</h3>\n<p>PressNomics se veut être la conférence sur WordPress côté économique. <a href="http://mattreport.com/pressnomics-review/">Un point de vue</a>.</p>\n<h3>10 conseils pour choisir votre extension</h3>\n<p>S&rsquo;il on devait donner 10 conseils pour bien choisir une extension, <a href="http://www.geekpress.fr/wordpress/guide/comment-choisir-plugin-1921/">il pourrait s&rsquo;agir de ceux-là</a>.</p>\n<h3>Planification manquée</h3>\n<p>En cas de planification d&rsquo;articles manquée de manière régulière, <a href="http://korben.info/planification-manquee.html">cette extension vous permettra de remédier au problème</a>.</p>\n<h3>Un guide pour personnaliser ses thèmes</h3>\n<p>Le personnalisateur de thème est une fonction méconnue de WordPress. <a href="http://wp.tutsplus.com/tutorials/theme-development/a-guide-to-the-wordpress-theme-customizer-a-methodology-for-sections-settings-and-controls-part-2/">Ce guide va vous apprendre à l&rsquo;utiliser (en)</a>.</p>\n<h3>Montrer une sélection de tweets</h3>\n<p>Dans le cas où vous voulez afficher une sélection de tweets choisis, <a href="http://www.wpbeginner.com/wp-tutorials/show-selective-tweets-wordpress/">cette astuce est faite pour vous</a>.</p>\n<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=ZU1HTgjM-is:M9qZhqmhyIs:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=ZU1HTgjM-is:M9qZhqmhyIs:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=ZU1HTgjM-is:M9qZhqmhyIs:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=ZU1HTgjM-is:M9qZhqmhyIs:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=ZU1HTgjM-is:M9qZhqmhyIs:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=ZU1HTgjM-is:M9qZhqmhyIs:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/ZU1HTgjM-is" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:113:"http://www.wordpress-fr.net/2013/10/29/lhebdo-wordpress-n205-wordcamps-communautes-francaises-wordpress-3-7/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"9";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:108:"http://www.wordpress-fr.net/2013/10/29/lhebdo-wordpress-n205-wordcamps-communautes-francaises-wordpress-3-7/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:45:"\n		\n		\n		\n		\n		\n				\n		\n\n		\n		\n				\n			\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:23:"Sortie de WordPress 3.7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/GeQeTeiCaUo/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:72:"http://www.wordpress-fr.net/2013/10/25/sortie-de-wordpress-3-7/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 25 Oct 2013 09:52:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:4:"Blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://www.wordpress-fr.net/?p=6399";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:377:"La version 3.7 de WordPress, baptisée &#171;&#160;Basie&#160;&#187; en l&#8217;honneur de Count Basie, est disponible en téléchargement ou en mise à jour dans le tableau de bord de votre installation de WordPress. Cette version intègre certaines des plus importantes mises à jour architecturales que nous ayons faites à ce jour. Voici les plus notables : Mises [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Xavier";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:5206:"<p>La version 3.7 de WordPress, baptisée &laquo;&nbsp;Basie&nbsp;&raquo; en l&rsquo;honneur de <a href="https://fr.wikipedia.org/wiki/Count_Basie">Count Basie</a>, est disponible <a href="http://fr.wordpress.org/">en téléchargement</a> ou en mise à jour dans le tableau de bord de votre installation de WordPress.</p>\n<p>Cette version intègre certaines des plus importantes mises à jour architecturales que nous ayons faites à ce jour. Voici les plus notables :</p>\n<ul>\n<li>Mises à jour en tâche de fond : avec WordPress 3.7, vous n’avez même plus à lever le petit doigt pour appliquer une mise à jour de maintenance ou de sécurité. La plupart des sites sont maintenant capables d’appliquer ces mises à jour automatiquement en coulisse. Le processus de mise à jour a été rendu encore plus sûr et sécurisé, avec des douzaines de nouvelles vérifications et de mesures de sauvegarde.</li>\n<li>Des mots de passe plus sûrs : votre mot de passe est la première ligne de défense de votre site. Il vaut mieux des mots de passe complexes, longs et uniques. Pour ce faire, notre testeur de mot de passe a été mis à jour dans WordPress 3.7 pour reconnaître les erreurs les plus courantes, celles qui peuvent affaiblir votre mot de passe : dates, noms, parcours clavier (123456789), et même les références de la culture populaire.</li>\n<li>Meilleur support global : les versions localisées de WordPress recevront des traductions plus rapides et plus complètes. WordPress 3.7 ajoute la possibilité d’installer automatiquement les bons fichiers de langue et de les garder à jour, une bénédiction pour les millions d&rsquo;utilisateurs qui ont un WordPress dans une langue autre que l&rsquo;anglais.</li>\n<li>Pour les développeurs, il y a de nombreuses options permettant de contrôler la nouvelle fonction de mise à jour, y compris lui permettre de gérer les mises à jour majeures comme mineurs, un support plus sophistiqué des requêtes de date, et des améliorations du multisite.</li>\n</ul>\n<p>Comme toujours, si vous souhaitez en savoir plus, <a href="http://codex.wordpress.org/Version_3.7">plongez-vous dans le Codex</a> ou <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=resolution&amp;milestone=3.7">parcourez les plus de 400 tickets dans Trac</a>.</p>\n<h2>Une nouvelle vague</h2>\n<p>Cette version a été chapeautée par Andrew Nacin, soutenu par Dion Hulse et Jon Cave. C&rsquo;est la première version a utiliser le nouveau processus de développement qui commence par des extensions, avec une période de développement beaucoup plus courte (la 3.6 est sortie en août). La version 3.8, attendue pour décembre, continuera ce cycle de développement basé sur les extensions car il donne beaucoup plus d&rsquo;autonomie aux gestionnaires des extensions et permet de découpler le développement de fonctionnalités du numéro de version. Vous pouvez suivre cette expérience, et les apprentissages que nous en tirons, sur le blog <a href="http://make.wordpress.org/core/">make/core</a>.</p>\n<p>Faites-vous plaisir avec ce qui sera sans doute votre dernière mise à jour manuelle. À bientôt pour la version 3.8 !</p>\n<p><em>(cet article est une traduction de <a href="http://wordpress.org/news/2013/10/basie/">l&rsquo;annonce originale</a>)</em></p>\n<p><em><strong>Mise à jour :</strong></em></p>\n<ul>\n<li>Deux petites erreurs de traduction ont été corrigées depuis le package FR initial (ce matin à 9h). Le package en ligne est désormais à jour, et WP 3.7 devrait vous proposer de mettre votre traduction à jour également, mais le cas échéant, vous pouvez <a href="http://i18n.svn.wordpress.org/fr_FR/branches/3.7/messages/admin-fr_FR.mo">télécharger le fichier fautif</a> ici et le mettre dans le dossier /wp-content/languages de votre installation.</li>\n<li>WordPress vous annonce que ne pourrez pas profiter de la mise à jour automatique en tâche de fond ? Pas de panique ! Plutôt que devoir entrer vos codes FTP à la main, <a href="http://remkusdevries.com/">Remkus</a> vous suggère de <a href="http://remkusdevries.com/help-wordpress-3-7-wont-do-automatic-updates/">les mettre dans votre fichier wp-config.php</a> !</li>\n</ul>\n<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=GeQeTeiCaUo:So-XuKzH2Wo:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=GeQeTeiCaUo:So-XuKzH2Wo:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=GeQeTeiCaUo:So-XuKzH2Wo:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=GeQeTeiCaUo:So-XuKzH2Wo:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=GeQeTeiCaUo:So-XuKzH2Wo:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=GeQeTeiCaUo:So-XuKzH2Wo:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/GeQeTeiCaUo" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:68:"http://www.wordpress-fr.net/2013/10/25/sortie-de-wordpress-3-7/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"20";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:63:"http://www.wordpress-fr.net/2013/10/25/sortie-de-wordpress-3-7/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:2:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:48:"http://feeds.feedburner.com/WordpressFrancophone";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:4:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:20:"wordpressfrancophone";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:14:"emailServiceId";a:1:{i:0;a:5:{s:4:"data";s:20:"WordpressFrancophone";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:18:"feedburnerHostname";a:1:{i:0;a:5:{s:4:"data";s:28:"http://feedburner.google.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"feedFlare";a:9:{i:0;a:5:{s:4:"data";s:24:"Subscribe with NewsGator";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:112:"http://www.newsgator.com/ngs/subscriber/subext.aspx?url=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone";s:3:"src";s:42:"http://www.newsgator.com/images/ngsub1.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:24:"Subscribe with Bloglines";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:77:"http://www.bloglines.com/sub/http://feeds.feedburner.com/WordpressFrancophone";s:3:"src";s:48:"http://www.bloglines.com/images/sub_modern11.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:23:"Subscribe with Netvibes";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:98:"http://www.netvibes.com/subscribe.php?url=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone";s:3:"src";s:44:"http://www.netvibes.com/img/add2netvibes.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:21:"Subscribe with Google";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:93:"http://fusion.google.com/add?feedurl=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone";s:3:"src";s:51:"http://buttons.googlesyndication.com/fusion/add.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:25:"Subscribe with Pageflakes";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:101:"http://www.pageflakes.com/subscribe.aspx?url=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone";s:3:"src";s:87:"http://www.pageflakes.com/ImageFile.ashx?instanceId=Static_4&fileName=ATP_blu_91x17.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:21:"Subscribe with Plusmo";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:86:"http://www.plusmo.com/add?url=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone";s:3:"src";s:43:"http://plusmo.com/res/graphics/fbplusmo.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:23:"Subscribe with Live.com";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:81:"http://www.live.com/?add=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone";s:3:"src";s:141:"http://tkfiles.storage.msn.com/x1piYkpqHC_35nIp1gLE68-wvzLZO8iXl_JMledmJQXP-XTBOLfmQv4zhj4MhcWEJh_GtoBIiAl1Mjh-ndp9k47If7hTaFno0mxW9_i3p_5qQw";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:7;a:5:{s:4:"data";s:25:"Subscribe with Mon Yahoo!";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:98:"http://add.my.yahoo.com/content?lg=fr&url=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone";s:3:"src";s:60:"http://us.i1.yimg.com/us.yimg.com/i/us/my/bn/intatm_fr_1.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:8;a:5:{s:4:"data";s:25:"Subscribe with Excite MIX";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:89:"http://mix.excite.eu/add?feedurl=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone";s:3:"src";s:42:"http://image.excite.co.uk/mix/addtomix.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:52:"http://backend.userland.com/creativeCommonsRssModule";a:1:{s:7:"license";a:1:{i:0;a:5:{s:4:"data";s:49:"http://creativecommons.org/licenses/by-nc-sa/3.0/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"etag";s:27:"+wjGKUFHIYyTODajkTZJTmBy9bg";s:13:"last-modified";s:29:"Thu, 28 Nov 2013 12:59:27 GMT";s:4:"date";s:29:"Thu, 28 Nov 2013 13:20:30 GMT";s:7:"expires";s:29:"Thu, 28 Nov 2013 13:20:30 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20131115134507";}', 'no'); 
INSERT INTO `wp_options` VALUES (473, '_transient_timeout_feed_mod_66a70e9599b658d5cc038e8074597e7c', '1385688030', 'no'); 
INSERT INTO `wp_options` VALUES (474, '_transient_feed_mod_66a70e9599b658d5cc038e8074597e7c', '1385644830', 'no'); 
INSERT INTO `wp_options` VALUES (475, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1385688030', 'no'); 
INSERT INTO `wp_options` VALUES (476, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://feedproxy.google.com/~r/WordpressFrancophone/~3/YqF0QRIza80/\' title=\'BuddyPress : Codex et traduction Le Codex de BuddyPress a été mis à jour (en), notamment avec des articles de nos amis français iMath et Chouf1. En outre, des informations concernant la traduction de l’extension sociale sont également fournies, ainsi qu’une liste de tâche pour améliorer la situation. BP Show Friends 2.0 iMath met à jour […]\'>L’Hebdo WordPress n°209 : BuddyPress – Veille – Contribution</a> <span class="rss-date">26 novembre 2013</span><div class=\'rssSummary\'>BuddyPress : Codex et traduction Le Codex de BuddyPress a été mis à jour (en), notamment avec des articles de nos amis français iMath et Chouf1. En outre, des informations concernant la traduction de l’extension sociale sont également fournies, ainsi qu’une liste de tâche pour améliorer la situation. BP Show Friends 2.0 iMath met à jour […]</div></li><li><a class=\'rsswidget\' href=\'http://feedproxy.google.com/~r/WordpressFrancophone/~3/DfxKjx6zZzs/\' title=\'La première beta de 3.8 est disponible au téléchargement. Les prochaines dates à retenir sont pour le gel du code le 5 décembre et la sortie de la version finale le 12 décembre. 3.8 rassemble plusieurs des fonctions développées comme des projets d’extensions (en) et bien que cela ne soit pas notre premier essai du […]\'>WordPress 3.8 beta 1</a> <span class="rss-date">23 novembre 2013</span><div class=\'rssSummary\'>La première beta de 3.8 est disponible au téléchargement. Les prochaines dates à retenir sont pour le gel du code le 5 décembre et la sortie de la version finale le 12 décembre. 3.8 rassemble plusieurs des fonctions développées comme des projets d’extensions (en) et bien que cela ne soit pas notre premier essai du […]</div></li></ul></div>', 'no'); 
INSERT INTO `wp_options` VALUES (477, '_transient_timeout_feed_2fb9572e3d6a42f680e36370936a57ae', '1385688032', 'no'); 
INSERT INTO `wp_options` VALUES (478, '_transient_feed_2fb9572e3d6a42f680e36370936a57ae', 'a:4:{s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"feed";a:1:{i:0;a:6:{s:4:"data";s:268:"\n    \n    \n    \n    \n    \n    \n    \n  \n            \n            \n            \n            \n            \n            \n            \n            \n            \n            \n            \n            \n            \n            \n            \n            \n            \n        ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:27:"http://www.w3.org/2005/Atom";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"WordPress Francophone : Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"subtitle";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:35:"http://www.wordpress-fr.net/planet/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:3:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:9:"alternate";s:4:"type";s:9:"text/html";s:4:"href";s:35:"http://www.wordpress-fr.net/planet/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:20:"application/atom+xml";s:4:"href";s:54:"http://feeds.feedburner.com/WordpressFrancophonePlanet";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"updated";a:1:{i:0;a:5:{s:4:"data";s:20:"2013-11-28T14:12:20Z";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:6:"Author";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:5:"entry";a:17:{i:0;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:91:"WordPress Francophone : L’Hebdo WordPress n°209 : BuddyPress – Veille – Contribution";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/YqF0QRIza80/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/YqF0QRIza80/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-11-26T07:16:17+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:4340:"<div>\n<h3>BuddyPress : Codex et traduction</h3>\n<p><a rel="nofollow" target="_blank" href="http://bpdevel.wordpress.com/2013/11/18/bp-codex-update-and-buddypress-translations/">Le Codex de BuddyPress a &eacute;t&eacute; mis &agrave; jour (en)</a>, notamment avec des articles de&nbsp;nos amis fran&ccedil;ais iMath et Chouf1. En outre, des informations concernant la traduction de l&rsquo;extension sociale sont &eacute;galement fournies, ainsi qu&rsquo;une liste de t&acirc;che pour am&eacute;liorer la situation.</p>\n<h3>BP Show Friends 2.0</h3>\n<p>iMath met &agrave; jour <a rel="nofollow" target="_blank" href="http://imathi.eu/2013/11/24/bp-show-friends-2-0/">sa premi&egrave;re extension BuddyPress</a>. C&rsquo;est forc&eacute;ment un mini &eacute;v&eacute;nement !</p>\n<h3>Flux RSS, Panda et Penguin</h3>\n<p><a rel="nofollow" target="_blank" href="http://yoast.com/rss-feeds-panda-penguin/">L&rsquo;analyse de Yoast sur ce sujet fort int&eacute;ressant (en)</a>&nbsp;qu&rsquo;est le d&eacute;clin du flux RSS et l&rsquo;arriv&eacute;e de Panda et Penguin, les mises &agrave; jour des bases de Google.</p>\n<h3>Simple Theme</h3>\n<p>ThemeSmarts propose un th&egrave;me gratuit : <a rel="nofollow" target="_blank" href="http://themesmarts.com/themes/simple-dark-wordpress-theme/">Simple Theme</a> (en).</p>\n<h3>Comment organiser son blog avec WordPress ?</h3>\n<p><a rel="nofollow" target="_blank" href="http://www.lipaonline.com/creer-blog/1149">Quelques id&eacute;es</a>&nbsp;pour mieux bloguer avec WordPress.</p>\n<h3>La s&eacute;curit&eacute; de WordPress</h3>\n<p><a rel="nofollow" target="_blank" href="http://www.wpexplorer.com/wordpress-security-tips/">La s&eacute;curit&eacute; de WordPress (en) </a>est toujours au c&oelig;ur des pr&eacute;occupations.</p>\n<h3>Contribuer &agrave; WordPress en &eacute;tant un pro</h3>\n<p>Quel int&eacute;r&ecirc;t pour un professionnel de contribuer &agrave; la communaut&eacute; WordPress ? <a rel="nofollow" target="_blank" href="http://10up.com/blog/giving-back-to-wordpress/">Voici une r&eacute;ponse</a> (en).</p>\n<h3>La veille WordPress</h3>\n<p>Un sujet qui m&rsquo;int&eacute;resse forc&eacute;ment. <a rel="nofollow" target="_blank" href="http://wpformation.com/ma-veille-wordpress/">Fabrice &eacute;voque l&rsquo;art de la veille</a>&nbsp;en prenant exemple sur ce qu&rsquo;il fait pour WordPress.</p>\n<h3>WooCommerce 2.1 Beta 1</h3>\n<p>L&rsquo;extension e-commerce bien connue pour WordPress, <a rel="nofollow" target="_blank" href="http://develop.woothemes.com/woocommerce/2013/11/woocommerce-2-1-beta-1-is-ready/">WooCommerce d&eacute;barque en bersion 2.1 beta 1</a> (en). A vos tests !</p>\n<h3>Joomla! vs WordPress</h3>\n<p>La bataille commence ! <a rel="nofollow" target="_blank" href="http://www.cree1site.com/wordpress-vs-joomla-seo/">Qui de WordPress ou de Joomla!</a> l&rsquo;emportera en combat singulier ?</p>\n<h3>Rendre visible ses activit&eacute;s &agrave; travers un blog WordPress</h3>\n<p>Stephanie Booth a fait un atelier pr&eacute;sentant les int&eacute;r&ecirc;ts de bloguer et de WordPress. <a rel="nofollow" target="_blank" href="http://www.pressmitic.ch/atelier-du-15-novembre-rendre-visible-ses-activites-a-travers-un-blog-wordpress/">La vid&eacute;o est en ligne</a> !</p>\n<div class="feedflare">\n<a rel="nofollow" target="_blank" href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=YqF0QRIza80:Uyh-h2BrDoI:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></a> <a rel="nofollow" target="_blank" href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=YqF0QRIza80:Uyh-h2BrDoI:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=YqF0QRIza80:Uyh-h2BrDoI:V_sGLiPBpWU" border="0"></a> <a rel="nofollow" target="_blank" href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=YqF0QRIza80:Uyh-h2BrDoI:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></a> <a rel="nofollow" target="_blank" href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=YqF0QRIza80:Uyh-h2BrDoI:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=YqF0QRIza80:Uyh-h2BrDoI:gIN9vFwOqvQ" border="0"></a>\n</div>\n<img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/YqF0QRIza80" height="1" width="1">\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:42:"Cree1site : WordPress Vs Joomla : Duel SEO";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:49:"http://www.cree1site.com/wordpress-vs-joomla-seo/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:49:"http://www.cree1site.com/wordpress-vs-joomla-seo/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-11-25T22:49:56+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:758:"<div>\n<p>Vu sur le site de <a rel="nofollow" target="_blank" href="http://www.cree1site.com/">l\'agence web</a> Cree1site.com<br></p>\n<p>Pour critiquer il faut savoir&hellip; &hellip;c&rsquo;est pourquoi j&rsquo;ai test&eacute; la derni&egrave;re version de Joomla pour voir o&ugrave; ils en sont avec leur CMS niveau SEO. Dans cette s&eacute;rie d&rsquo;article que je pr&eacute;vois, j&rsquo;ai fait un retour aux sources et pr&eacute;vu &agrave; cet effet deux installations totalement neutres, vierge de tout plugin, utilisant leur th&egrave;me par [&hellip;]</p>\n<p>Cet article <a rel="nofollow" target="_blank" href="http://www.cree1site.com/wordpress-vs-joomla-seo/">WordPress Vs Joomla : Duel SEO</a> est apparu en premier sur Cree1site.com</p>\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"WP Formation : Ma veille WordPress";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:43:"http://wpformation.com/ma-veille-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:43:"http://wpformation.com/ma-veille-wordpress/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-11-25T08:52:50+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:1543:"<div>\n<p><img width="300" height="195" src="http://wpformation.com/wp-content/uploads/2013/11/veille-wordpress-300x195.jpg" class="attachment-medium wp-post-image" alt="veille-wordpress" style="float:right;margin:0 0 10px 10px;">Suivre un domaine d&rsquo;int&eacute;r&ecirc;t particulier implique de s&eacute;lectionner des sources et si elles sont nombreuses il vous faudra n&eacute;cessairement des outils pour les suivre... Retrouvez ci-apr&egrave;s ma veille WordPress et quelques outils efficaces pour optimiser la v&ocirc;tre! Les sources pour ma veille WordPress Sur Twitter Mon r&eacute;seau pr&eacute;f&eacute;r&eacute; et certainement l\'un des plus r&eacute;actif. Il ...</p>\n<p></p>\n<hr>\n<a rel="nofollow" target="_blank" href="http://wpformation.com/ma-veille-wordpress/">Ma veille WordPress</a> est un article de <a rel="nofollow" title="Formation Internet WordPress Ecommerce" target="_blank" href="http://wpformation.com/">WP Formation</a><br><a rel="nofollow" target="_blank" href="http://wpformation.com/formation-wordpress/">Formation WordPress</a> &amp; <a rel="nofollow" target="_blank" href="http://wpformation.com/apprendre-creer-e-commerce/">eCommerce</a> - Retrouvez-moi sur <a rel="nofollow" title="Ajouter sur Facebook" target="_blank" href="http://www.facebook.com/Wibeweb">Facebook</a> - <a rel="nofollow" title="Suivre sur Twitter" target="_blank" href="http://twitter.com/wpformation">Twitter</a> - <a rel="nofollow" target="_blank" href="http://plus.google.com/107614015687669785725/">Google+</a>\n<br><hr>\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:86:"BoiteAWeb : WordPress SEO, la pagination, et ses hooks : Rapidité contre Flexibilité";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:88:"http://boiteaweb.fr/wordpress-seo-pagination-hooks-rapidite-contre-flexibilite-7757.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:88:"http://boiteaweb.fr/wordpress-seo-pagination-hooks-rapidite-contre-flexibilite-7757.html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-11-25T06:30:14+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:865:"<div>\n<p>Je viens vous dire quelques mots &agrave; propos du tr&egrave;s connu plugin WordPress SEO. Je ne vais pas parler SEO, d&eacute;sol&eacute;. Merci &agrave; bient&ocirc;t. Vous &ecirc;tes rest&eacute;s ? Ha vous &ecirc;tes encore l&agrave;, alors vous &ecirc;tes d&eacute;veloppeur ou au moins int&eacute;ress&eacute; par ce que je vais raconter. Attention je vais r&acirc;ler un peu ... si si parfois il le faut. Je ne pr&eacute;sente pas ce plugin, vous savez d&eacute;j&agrave; &agrave; [&hellip;]</p>\n<p>Cet article <a rel="nofollow" target="_blank" href="http://boiteaweb.fr/wordpress-seo-pagination-hooks-rapidite-contre-flexibilite-7757.html">WordPress SEO, la pagination, et ses hooks : Rapidit&eacute; contre Flexibilit&eacute;</a> est apparu en premier sur <a rel="nofollow" target="_blank" href="http://boiteaweb.fr/">BoiteAWeb.fr</a>.</p>\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"L\'écho des plugins WordPress : Private Only";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:58:"http://www.echodesplugins.li-an.fr/plugins/private-only-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:58:"http://www.echodesplugins.li-an.fr/plugins/private-only-2/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-11-22T22:19:36+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:47:"<div>Votre Wordpress en mode priv&eacute;</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:75:"WordPress Channel : Optimiser son référencement WordPress par Daniel Roch";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:67:"http://wpchannel.com/optimiser-referencement-wordpress-daniel-roch/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:67:"http://wpchannel.com/optimiser-referencement-wordpress-daniel-roch/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-11-21T13:22:49+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:1096:"<div>\n<p></p>\n<p style="float:right;margin:0 0 10px 15px;width:240px;">\n		<img src="http://wpchannel.com/images/2013/11/wordpress-livre-seo.jpg" width="240"></p>Daniel Roch de SEOMIX, un blog sp&eacute;cialis&eacute; en r&eacute;f&eacute;rencement naturel sous WordPress, vient de publier un ouvrage exclusivement d&eacute;di&eacute; &agrave; notre CMS favori et aux techniques de r&eacute;f&eacute;rencement le concernant. Revue de d&eacute;tails pour ce livre &eacute;dit&eacute; par Eyrolles. Table des mati&egrave;res Retour aux bases Rappel sur les bases du r&eacute;f&eacute;rencement naturel Comprendre WordPress L&rsquo;optimisation [&hellip;]<p><a rel="nofollow" target="_blank" href="http://wpchannel.com/author/aurelien-denis/">Aur&eacute;lien Denis</a> - <a rel="nofollow" target="_blank" href="http://wpchannel.com/">WordPress Channel - Tutoriels, th&egrave;mes &amp; plugins WordPress</a> - <a rel="nofollow" target="_blank" href="http://wpchannel.com/optimiser-referencement-wordpress-daniel-roch/">Optimiser son r&eacute;f&eacute;rencement WordPress par Daniel Roch</a></p>\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:79:"Grégoire Noyelle : Genesis :: Utiliser les Widgets Pages et Articles à la Une";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:75:"http://www.gregoirenoyelle.com/genesis-utiliser-widgets-pages-articles-une/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:75:"http://www.gregoirenoyelle.com/genesis-utiliser-widgets-pages-articles-une/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-11-20T10:15:19+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:7011:"<div>\n<p>Dans ce tutoriel, je me concentrerai sur les deux widgets majeurs de Genesis. Tous les liens sont exempts d&rsquo;affiliation.</p>\n<h3>Les th&egrave;mes enfants StudioPress ou reposant sur Genesis</h3>\n<p>La plupart des <a rel="nofollow" target="_blank" href="http://my.studiopress.com/themes/" title="Ouverture">th&egrave;mes enfants de StudioPress</a> utilisent pour leur page d&rsquo;accueil deux widgets principaux: <strong>Genesis &ndash; Page caract&eacute;ristique</strong> et <strong>Genesis &ndash; Article caract&eacute;ristique</strong>. Ces noms risquent de changer dans la nouvelle traduction. Ils deviendront <strong>Genesis &ndash; Page &agrave; la Une</strong> et <strong>Genesis &ndash; Articles &agrave; la Une</strong>. Ces widgets ne sont pas li&eacute;s au th&egrave;me enfant, mais au framework Genesis lui-m&ecirc;me.</p>\n<p>Par d&eacute;faut, pour que &ccedil;a fonctionne correctement, votre site doit avoir le r&eacute;glage par d&eacute;faut suivant. Dans votre back-office, ouvrez R&eacute;glages &gt; Lecture et choisissez <strong>La page d&rsquo;accueil affiche</strong> : <strong>Les derniers articles</strong>.</p>\n<h4>Analyse d&rsquo;un th&egrave;me</h4>\n<p>Le th&egrave;me Magazine Pro (<a rel="nofollow" target="_blank" href="http://demo.studiopress.com/magazine/" title="Ouverture">lien vers la d&eacute;monstration en ligne</a>), sorti fin octobre 2013 propose sur la page d&rsquo;accueil plusieurs zones de widget. En voici le d&eacute;tail avec la capture qui suit. </p>\n<p>Dancs ce th&egrave;me, chaque bloc avec un ent&ecirc;te noir correspond &agrave; une zone de Widget. Celles-ci s&rsquo;activent d&egrave;s que vous placez un widget dans une des zones. Pour cette d&eacute;monstration, &agrave; chaque fois que vous avez une image, c&rsquo;est le widget <strong>Genesis &ndash; Article caract&eacute;ristique</strong> qui est utilis&eacute;.</p>\n<p><img src="http://cdn.gregoirenoyelle.com/gnm/wpgen-niv1/wpgen-n1-widget-theme-magazine.jpg" title="Widget Genesis du th&egrave;me WordPress Magazine de StudioPress" alt="Capture: Widget Genesis du th&egrave;me WordPress Magazine de StudioPress" width="600" height="1103"></p>\n<p><span id="more-7541"></span></p>\n<h4>Emplacement dans le back-office</h4>\n<p>Pour installer ces widgets vous vous rendez dans votre back-office Apparence &gt; Widgets et vous avez &agrave; votre disposition les deux widgets principaux de Genesis.</p>\n<p><img src="http://cdn.gregoirenoyelle.com/gnm/wpgen-niv1/wpgen-n1-widget-articles-pages.jpg" title="Widget Genesis pour les page et articles" alt="Capture: Widget Genesis pour les page et articles" width="600" height="386"></p>\n<p>Ensuite, il s&rsquo;agit d&rsquo;identifier la zone de widget ajout&eacute;e par le th&egrave;me enfant dans laquelle vous allez glisser votre widget.</p>\n<p><img src="http://cdn.gregoirenoyelle.com/gnm/wpgen-niv1/wpgen-n1-widget-zones-theme.jpg" title="Widget Genesis et zone de widget du th&egrave;me" alt="Capture: Widget Genesis et zone de widget du th&egrave;me" width="600" height="602"></p>\n<h4>Autres th&egrave;mes enfant</h4>\n<p>Tous les th&egrave;mes enfants qui reposent sur Genesis ont des zones sp&eacute;cifiques qui peuvent varier d&rsquo;un th&egrave;me &agrave; l&rsquo;autre. Bien s&ucirc;r, ces zones sont optionnelles et nous ne sommes pas oblig&eacute;s d&rsquo;utiliser ces widgets. Nous verrons &ccedil;a dans un autre tutoriel.</p>\n<p>Le plus facile est de se reposer sur la d&eacute;monstration en ligne en testant les diff&eacute;rentes zones de widget propos&eacute;es par le th&egrave;me.</p>\n<h3>Utilisation des Widget Genesis</h3>\n<h4>Widget Page Caract&eacute;ristique</h4>\n<p>Ce Widget comme son nom l&rsquo;indique affiche une page. &Agrave; chaque fois plusieurs options sont possibles et il est possible dans une m&ecirc;me zone de widget d&rsquo;empiler plusieurs fois le m&ecirc;me widget avec des r&eacute;glages diff&eacute;rents.</p>\n<p><strong>Affichage du Widget en ligne</strong></p>\n<p>Ici, j&rsquo;ai plac&eacute; deux widgets <strong>Page caract&eacute;ristiques</strong> dans deux zones de widget diff&eacute;rentes. Dans chaque zone, le widget appelle une page diff&eacute;rente.</p>\n<p><img src="http://cdn.gregoirenoyelle.com/gnm/wpgen-niv1/wpgen-n1-widget-page-front.jpg" title="Widget Genesis Page &agrave; la Une c&ocirc;t&eacute; Front" alt="Capture: Widget Genesis Page &agrave; la Une c&ocirc;t&eacute; Front" width="600" height="444"></p>\n<p><strong>R&eacute;glage du widget</strong></p>\n<p><img src="http://cdn.gregoirenoyelle.com/gnm/wpgen-niv1/wpgen-n1-widget-page-back.jpg" title="Widget Genesis Page &agrave; la Une c&ocirc;t&eacute; Back office" alt="Capture: Widget Genesis Page &agrave; la Une c&ocirc;t&eacute; Back office" width="600" height="618"></p>\n<p>En plus de la capture d&rsquo;&eacute;cran, il faut retenir: </p>\n<ul>\n<li>le titre du Widget est optionnel</li>\n<li>une seule page peut &ecirc;tre choisie, mais il est possible d&rsquo;empiler plusieurs fois le m&ecirc;me widget</li>\n<li>les autres &eacute;l&eacute;ments, Image &agrave; la Une, titre et contenu sont optionnels et ils ont &agrave; chaque fois des options sp&eacute;cifiques</li>\n</ul>\n<h3>Widget Articles Caract&eacute;ristique</h3>\n<p>Ce widget fonctionne globalement comme le Widget Page Caract&eacute;ristique. La diff&eacute;rence r&eacute;side surtout dans le fait qui permet d&rsquo;afficher un flux d&rsquo;article avec un nombre, des classements sur mesure. Le widget qui concerne les pages ne le permet pas.</p>\n<p><strong>Affichage du Widget en ligne</strong></p>\n<p><img src="http://cdn.gregoirenoyelle.com/gnm/wpgen-niv1/wpgen-n1-widget-article-front.jpg" title="Widget Article &agrave; la Une de Genesis dans le front" alt="Capture: Widget Article &agrave; la Une de Genesis dans le front" width="601" height="646"></p>\n<p><strong>R&eacute;glage du widget</strong></p>\n<p><img src="http://cdn.gregoirenoyelle.com/gnm/wpgen-niv1/wpgen-n1-widget-article-back.jpg" title="Widget Genesis Articles &agrave; Une dans le back-office" alt="Capture: Widget Genesis Articles &agrave; Une dans le back-office" width="600" height="585"></p>\n<p>En plus de la capture d&rsquo;&eacute;cran, il faut retenir:</p>\n<ul>\n<li>le titre de la zone de widget est optionnel</li>\n<li>si le nombre d&rsquo;articles est r&eacute;gl&eacute; sur <strong>&ndash;1</strong>, cela affiche tout (oui, je sais)</li>\n<li>il est possible de passer un N nombre d&rsquo;article ou d&rsquo;omettre un article d&eacute;j&agrave; affich&eacute; (<strong>Exclude Previously Displayed Posts</strong>) pour &eacute;viter les doublons</li>\n<li>les informations de l&rsquo;article sont &eacute;ditables avec les shortcodes</li>\n<li>il est possible d&rsquo;afficher un lien direct vers une archive de la cat&eacute;gorie s&eacute;lectionn&eacute;e</li>\n</ul>\n<h3>La suite</h3>\n<p>Nous verrons ult&eacute;rieurement pour les utilisateurs un peu plus avanc&eacute;s comment cr&eacute;er ses propres zones de Widget dans Genesis.</p>\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"Lumière de Lune : Utilisateurs de Mystique, attention aux mises à jour de WordPress";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:78:"http://www.lumieredelune.com/encrelune/utilisateurs-mystique-attention,2013,11";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:78:"http://www.lumieredelune.com/encrelune/utilisateurs-mystique-attention,2013,11";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-11-14T12:00:00+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:476:"<div>Mystique est un th&egrave;me tr&egrave;s utilis&eacute;, notamment parce qu&rsquo;il est recommand&eacute; par de nombreux &laquo;&nbsp;webmarketeurs&nbsp;&raquo;. N&eacute;anmoins, un probl&egrave;me se pose pour ceux qui l&rsquo;utilisent : le th&egrave;me semble ne pas &ecirc;tre compatible avec la derni&egrave;re mise &agrave; jour de WordPress. Le probl&egrave;me est dans la gestion des options du th&egrave;me : si, apr&egrave;s avoir install&eacute; [...]</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"GeekPress : Mention comment’s Authors :  Enrichir vos fils de discussion WordPress";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:74:"http://www.geekpress.fr/wordpress/extension/mention-comments-authors-1961/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:74:"http://www.geekpress.fr/wordpress/extension/mention-comments-authors-1961/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-11-14T10:30:14+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:215:"<div>Le syst&egrave;me de r&eacute;ponse propos&eacute; par WordPress n&rsquo;est pas id&eacute;al. Le plugin Mention comment&rsquo;s Authors est une alternative pour enrichir vos fils de discussion WordPress.</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"SEOMix : Retour sur le SeoCamp de Nantes 2013";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:41:"http://www.seomix.fr/seocamp-nantes-2013/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:41:"http://www.seomix.fr/seocamp-nantes-2013/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-11-14T08:30:08+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:1420:"<div>\n<div><img width="126" height="180" src="http://www.seomix.fr/wp-content/uploads/2013/11/seocamp-day-nantes-2013-126x180.jpg" class="attachment-thumbnail wp-post-image" alt="SEOCamp Day Nantes 2013"></div>Une journ&eacute;e de conf&eacute;rence sur le SEO : retour sur le SEOCampus Day de Nantes 2013 et sur ma conf&eacute;rence "WordPress et r&eacute;f&eacute;rencement naturel"\n      <p><strong>Article original :</strong> <a rel="nofollow" target="_blank" href="http://www.seomix.fr/seocamp-nantes-2013/">Retour sur le SeoCamp de Nantes 2013</a>.</p>\n      <p><strong>Debut du contenu :</strong> Le 26 Octobre dernier a eu lieu le SeoCamp de Nantes : une journ&eacute;e compl&egrave;te de conf&eacute;rences sur le SEO et sur la visibilit&eacute; sur Internet. Les slides J\'ai eu le plaisir de pouvoir faire une conf&eacute;rence sur mon th&egrave;me de pr&eacute;dilection (pour changer) : WordPress et le r&eacute;f&eacute;rencement naturel. Puisque vous avez &eacute;t&eacute; plusieurs &agrave; me le demander, voici les slides de cette conf&eacute;rence : WordPress et SEO - SEOCampus 2013 from Daniel Roch Les r&eacute;sum&eacute;s Je ne vais pas vous r&eacute;sumer la journ&eacute;e ni ce que l\'on pouvait apprendre. D\'autres que moi le font d&eacute;j&agrave; tr&egrave;s bien ici [&hellip;]</p>\n<hr>\n<img src="http://feeds.feedburner.com/~r/seomix-wordpress/~4/cHeQHj9rkf4" height="1" width="1">\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"Lashon : WordPress 3.7 est peinard et sécurisant";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:46:"http://lashon.fr/wordpress-3-7-super-securite/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:46:"http://lashon.fr/wordpress-3-7-super-securite/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-10-28T07:15:50+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:855:"<div>\n<p>&nbsp; Juste quelques mots brefs pour dire que cette fois &ccedil;a y est, WordPress 3.7, nomm&eacute; &laquo;&nbsp;Basie&nbsp;&raquo; est une version de WordPress fort r&eacute;ussie. D&rsquo;ailleurs ce blog a saut&eacute; dedans &agrave; pieds joints et les yeux ferm&eacute;s. D&eacute;sormais vous tournerez vos blogs avec plus de s&eacute;curit&eacute; quasi en dormant. La grande nouveaut&eacute; est un processus [&hellip;]</p>\n<p>Exigez l\'original ! ;-) \nL\'original de cet article est l&agrave; <a rel="nofollow" target="_blank" href="http://lashon.fr/wordpress-3-7-super-securite/">WordPress 3.7 est peinard et s&eacute;curisant</a> - &eacute;crit par  <a rel="nofollow" target="_blank" href="http://lashon.fr/">WordPress Cr&eacute;ation Sites Internet - lashon.fr, le blog work in progress de Tikoun, cr&eacute;ateur Web</a></p>\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"GD6D : Créer une présentation et la diffuser dans son site avec… JETPACK";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:51:"http://feedproxy.google.com/~r/Gd6d/~3/Rng_PI-XPNg/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:51:"http://feedproxy.google.com/~r/Gd6d/~3/Rng_PI-XPNg/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-09-12T01:19:54+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:13524:"<div>\n<img src="http://i1.wp.com/www.gd6d.fr/wordpressfr/wp-content/uploads/2013/09/shortcodes.jpg?fit=1024%2C1024" class="attachment-large wp-post-image" alt="shortcodes"><p>L&rsquo;extension <a rel="nofollow" title="Par WordPress.com" target="_blank" href="http://jetpack.me/"><strong>Jetpack</strong></a> propose des fonctions indispensables (formulaire de contact, statistique, partage, <a rel="nofollow" title="Nouveaut&eacute; JetPack : la fonction &laquo; Widget Visibility &raquo;" target="_blank" href="http://www.gd6d.fr/wordpressfr/blog/plugin-jetpack-visibility/">visibilit&eacute; des widgets</a>&hellip;), d&rsquo;autres moins (<a rel="nofollow" title="Nouveau : cr&eacute;ez un diaporama ou une mosa&iuml;que d&rsquo;images avec Jetpack" target="_blank" href="http://www.gd6d.fr/wordpressfr/blog/diaporama-slideshow-mosaique-images-avec-plugin-jetpack/">mosa&iuml;que d&rsquo;image</a>) et enfin il y a une troisi&egrave;me cat&eacute;gorie : les fonctions &laquo;&nbsp;gadget&nbsp;&raquo;. &laquo;&nbsp;C&rsquo;est totalement <em>inutile</em> et <em>donc</em> rigoureusement <em>indispensable</em> !&nbsp;&raquo; comme dirait J&eacute;rome Bonaldi, donc voyons comment l&rsquo;utiliser !</p>\n<h2>Remplacer gratuitement Powerpoint et Slideshare !!!</h2>\n<p>La premi&egrave;re utilit&eacute; du module &laquo;&nbsp;Presentation&nbsp;&raquo; est comme son nom l&rsquo;indique de pouvoir cr&eacute;er des pages qui pourront ainsi &ecirc;tre projet&eacute;es, exactement des diapos PowerPoint ou Keynote. Ces pages seront visible sous forme d&rsquo;un diaporama interactif int&eacute;gr&eacute; dans sa page et pouvant occuper tout l&rsquo;&eacute;cran. Voil&agrave; un exemple : </p>\n<p></p>\n<p class="not-supported-msg" style="display:inherit;padding:25%;text-align:center;">Impossible de lancer ce diaporama. Raffra&icirc;chissez la page&hellip; ou essayez un autre navigateur.</p>\n<br><p></p>\n<div class="shortcode-toggle toggle-voir-le-code closed default border">\n<h4 class="toggle-trigger"><a rel="nofollow">Voir le code</a></h4>\n<div class="toggle-content">\n<br>\nCode utilis&eacute; pour la pr&eacute;sentation ci-dessus.<br><em>Attention, j&rsquo;ai rajout&eacute; un espace autour des crochets !</em>\n<p>[ slide transition="down" bgimg="http://www.gd6d.fr/wordpressfr/wp-content/uploads/2013/09/bg-gd6d.jpg" ]<br>\n&lt;h3&gt;Presentations Shortcode Plugin&lt;/h3&gt;<br>\n&lt;h4&gt;with JETPACK&lt;/h4&gt;<br>\n[ /slide ][ slide bgcolor=#CEE4EA ]<br>\nWho doesn&rsquo;t love awesome presentations?</p>\n<p>This presentations plugin provides shortcodes to let you quickly and easily put together amazing presentations!</p>\n<p>Supported features include:<br>\n&lt;ul&gt;<br>\n&lt;li&gt;Choosing slide transitions&lt;/li&gt;<br>\n&lt;li&gt;Rotating and scaling slides for extra awesomeness&lt;/li&gt;<br>\n&lt;li&gt;Setting presentation backgrounds with solid colors or images&lt;/li&gt;<br>\n&lt;li&gt;Setting transition durations and sizes&lt;/li&gt;<br>\n&lt;/ul&gt;<br>\n[ /slide ]<br>\n[ slide bgimg="http://www.gd6d.fr/wordpressfr/wp-content/uploads/2013/09/bg-arrow.jpg" ]<br>\n&lt;h3&gt;Viewing&lt;/h3&gt;<br>\n[ twocol_one ]Presentations can be navigated either using the onscreen arrows, or by using keyboard arrow keys.<br>\nTab or space will also navigate the slideshow forward.Fullscreen mode is toggled using the icon on the lower right.</p>\n<p>Hitting ESC on the keyboard will also exit fullscreen.[ /twocol_one ] [ twocol_one_last ][ /twocol_one_last ]<br>\n[ /slide ]<br>\n[ slide ]<br>\nTo begin, simply start with the presentation shortcode. Then put all your individual slide content inside slide shortcodes and you are good to go!<br>\n[ /slide ]<br>\n[ slide transition="down" ]<br>\n&lt;h2&gt;Down&lt;/h2&gt;<br>\nThe default transition!<br>\n[ /slide ]<br>\n[ slide transition="right" ]<br>\n&lt;h2&gt;Right&lt;/h2&gt;<br>\n[ /slide ]<br>\n[ slide transition="up" ]<br>\n&lt;h2&gt;Up&lt;/h2&gt;<br>\n[ /slide ]<br>\n[ slide transition="left" ]<br>\n&lt;h2&gt;Left&lt;/h2&gt;<br>\n[ /slide ]<br>\n[ slide ]<br>\n&lt;h2&gt;Or none!&lt;/h2&gt;<br>\nWhich only really works when fading is enabled.<br>\n[ /slide ]<br>\n[ slide rotate=45 ]<br>\nRotation</p>\n<p>Slides can be rotated using [ slide rotate= ] where the value is in degrees.<br>\n[ /slide ]<br>\n[ slide ]<br>\nScaling</p>\n<p>Emphasize your big ideas or explain the tiny details using [ slide scale= ].<br>\n[ /slide ]<br>\n[ slide scale=5 ]<br>\nBackgrounds</p>\n<p>Solid color backgrounds can be set using slide bgcolor= where the value can be any valid HTML color.</p>\n<p>Alternatively slide bgimg= with a valid image url will set it as the background, stretching the image to fill the slide.<br>\n[ /slide ]<br>\n[ slide fade=off ]<br>\nFading</p>\n<p>Fading between is enabled by default. It can easily be disabled via slide fade= with a value of &ldquo;off&rdquo; or &ldquo;false&rdquo;.<br>\n[ /slide ]<br>\n[ slide ]<br>\nEnjoy making your own presentations <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAAAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" alt=":)" class="wp-smiley"></p>\n<p>[ /slide ]<br>\n[ /presentation ]</p>\n<p></p>\n</div>\n<input type="hidden" name="title_open" value="Fermer"><input type="hidden" name="title_closed" value="Voir le code">\n</div>\n<br><div class="woo-sc-hr"></div>\n<h2>Pour int&eacute;grer une pr&eacute;sentation</h2>\n<p>Ce module fonctionne tout naturellement avec des shortcodes et des variables qui permettent d&rsquo;en ajuster le comportement :</p>\n<ul>\n<li>S&eacute;lectionner diff&eacute;rentes transitions</li>\n<li>Effets de rotation et zoom</li>\n<li>Image ou couleur de fond</li>\n<li>Dur&eacute;e de transition</li>\n</ul>\n<p>On est donc en pr&eacute;sence d&rsquo;un outil minimaliste, mais complet et qui peut rendre d&rsquo;autres services, comme nous allons le voir.</p>\n<h3>Les shortcodes &agrave; utiliser</h3>\n<p>Pour cr&eacute;er une pr&eacute;sentation, utilisez simplement :<br>\n[ <code>presentation</code> ]</p>\n<p>Pour cr&eacute;er une diapo, utilisez :<br>\n[ <code>slide</code> ]</p>\n<p>Tous les [ <code>slide</code> ] doivent &ecirc;tre encadr&eacute;es par le shortcode [ <code>presentation</code> ], sinon les diapositives ne seront pas affich&eacute;es.</p>\n<p>Les param&egrave;tres tels que <em>la hauteur,</em> la <em>largeur</em> et la <em>dur&eacute;e de transition</em> (en seconde) peuvent tous &ecirc;tre configur&eacute;s en utilisant les attributs respectifs dans le shortcode [ <code>presentation</code> ] .</p>\n<p>Par exemple:</p>\n<p>Pour cr&eacute;er une pr&eacute;sentation de dimension 600 &times; 375 (comme dans l&rsquo;exemple ci-dessus), utilisez:<br>\n[ <code>presentation width=600 height=375</code> ]</p>\n<p>Pour d&eacute;finir une dur&eacute;e de transition pour chaque diapositive &eacute;gale &agrave; 5 secondes, utilisez:<br>\n[ <code>presentation duration=5</code> ]</p>\n<div class="shortcode-toggle toggle-les-codes-de-transition-et-dhabillage-en-detail closed default border">\n<h4 class="toggle-trigger"><a rel="nofollow">Les codes de transition et d\'habillage en d&eacute;tail</a></h4>\n<div class="toggle-content">\n<h4 id="transitions">Quelques effets de transition</h4>\n<p>Voici une liste des effets de transition disponibles (&agrave; utiliser avec mod&eacute;ration&hellip;) :</p>\n<p>Pour cr&eacute;er une transition qui se d&eacute;place vers le bas (la transition par d&eacute;faut), utilisez:<br>\n[ <code>slide transition="down"</code> ]</p>\n<p>Pour cr&eacute;er une transition qui se d&eacute;place &agrave; droite, utilisez:<br>\n[ <code>slide transition="right"</code> ]</p>\n<p>Pour cr&eacute;er une transition qui se d&eacute;place de bas en haut, utilisez:<br>\n[ <code>slide transition="up"</code> ]</p>\n<p>Pour cr&eacute;er une transition qui se d&eacute;place &agrave; gauche, utilisez:<br>\n[ <code>slide transition="left"</code> ]</p>\n<p>Pour ne pas afficher de transition, utilisez:<br>\n[ <code>slide transition="none"</code> ]</p>\n<h4 id="rotation-and-scaling">L&rsquo;effet rotation et mise &agrave; l&rsquo;&eacute;chelle</h4>\n<p>Vous pouvez faire pivoter et modifier la taille des diapositives pour cr&eacute;er diff&eacute;rents effets. Pour faire pivoter une diapositive, utilisez:</p>\n<p>[ <code>slide rotate=</code> ]</p>\n<p>La valeur est en degr&eacute;s. Par exemple: [ <code>slide rotate=45</code> ].</p>\n<p>Pour redimensionner une diapositive, utilisez:</p>\n<p>[ <code>slide scale=</code> ]</p>\n<p>Par exemple: [ <code>slide scale=5</code> ] ou [ <code>slide scale=1.75</code> ].</p>\n<h4 id="fading">Effet de fondu enchain&eacute;</h4>\n<p>Fondu encha&icirc;n&eacute; entre les diapositives est activ&eacute;e par d&eacute;faut. Pour le d&eacute;sactiver, utilisez:</p>\n<p>[ <code>slide fade="off"</code> ] ou [ <code>slide fade="false"</code> ]</p>\n<p>Pour le r&eacute;activer, utilisez:</p>\n<p>[ <code>slide fade="on"</code> ] ou [ <code>slide fade="true"</code> ]</p>\n<h4 id="background">Fond de diapo</h4>\n<p>Vous pouvez habiller un diaporama avec un fond de couleur ou une image personnalis&eacute;e. Pour d&eacute;finir une couleur unie, utilisez:</p>\n<p>[ <code>slide bgcolor=</code> ]</p>\n<p>La valeur est une couleur HTML valide. Par exemple: [ <code>slide bgcolor=#d3e7f8</code> ].</p>\n<p>Pour d&eacute;finir une image de fond, utilisez:</p>\n<p>[ <code>slide bgimg=</code> ]</p>\n<p>La valeur est l&rsquo;adresse URL de l&rsquo;image valide. la taille de l&rsquo;image s&rsquo;ajustera automatiquement &agrave; la diapositive.</p>\n<p><em>Astuce:</em> Toutes ces options peuvent &ecirc;tre r&eacute;gl&eacute;es sur la balise [ <code>presentation</code> ] pour les d&eacute;finir comme param&egrave;tres par d&eacute;faut.</p>\n</div>\n<input type="hidden" name="title_open" value="Fermer"><input type="hidden" name="title_closed" value="Les codes de transition et d\'habillage en d&eacute;tail">\n</div>\n<br><div class="woo-sc-divider"></div> \n<h4>Lecture de la pr&eacute;sentation</h4>\n<p>Vous pouvez visionner une pr&eacute;sentation en plein &eacute;cran en cliquant sur l&rsquo;ic&ocirc;ne &agrave; quatre fl&egrave;che en bas &agrave; droite du diaporama. La touche ESC du clavier permet alors de quitter le mode plein &eacute;cran.</p>\n<p>Pour naviguer, on peut utiliser les fl&egrave;ches &agrave; l&rsquo;&eacute;cran ou les touches fl&eacute;ch&eacute;es du clavier. Vous pouvez &eacute;galement utiliser les touches tabulation ou d&rsquo;espace pour afficher la diapositive suivante.</p>\n<h4 id="viewing">Et pour les diaporamas photos, on a le droit ???</h4>\n<p>C&rsquo;est une utilisation int&eacute;ressante de cette fonctionnalit&eacute; : int&eacute;grer un diaporama photo avec fonction zoom plein &eacute;cran. C&rsquo;est tr&egrave;s simple &agrave; mettre en place et en plus on peut rajouter du texte, comme ici :</p>\n<p></p>\n<p class="not-supported-msg" style="display:inherit;padding:25%;text-align:center;">Impossible de lancer ce diaporama. Raffra&icirc;chissez la page&hellip; ou essayez un autre navigateur.</p>\n<br><div class="shortcode-toggle toggle-voir-le-code closed default border">\n<h4 class="toggle-trigger"><a rel="nofollow">Voir le code</a></h4>\n<div class="toggle-content">\n<br>\nCode utilis&eacute; pour le diaporama&hellip; pas compliqu&eacute;, non ?<br><em>Attention, j&rsquo;ai rajout&eacute; un espace autour des crochets !</em>\n<pre>[ presentation width=500 height=313 ]\n[ slide bgimg="http://www.gd6d.fr/wordpressfr/wp-content/uploads/2013/09/LangageWeb12.jpg" transition="right" ]\n&lt;h2&gt;Formation WordPress&lt;/h2&gt;\n&lt;h3&gt;pour l\'IIM&lt;/h3&gt;\n[ /slide ]\n[ slide transition="right" bgimg="http://www.gd6d.fr/wordpressfr/wp-content/uploads/2013/09/LangageWeb19.jpg" ]\n[ /slide]\n[ slide transition="right" bgimg="http://www.gd6d.fr/wordpressfr/wp-content/uploads/2013/09/LangageWeb06.jpg" ]\n[ /slide]\n[ slide transition="right" bgimg="http://www.gd6d.fr/wordpressfr/wp-content/uploads/2013/09/LangageWeb03.jpg" ]\n[ /slide ]\n[ /presentation ]</pre>\n<p></p>\n</div>\n<input type="hidden" name="title_open" value="Fermer"><input type="hidden" name="title_closed" value="Voir le code">\n</div>\n<div class="woo-sc-hr"></div>\n<h4>Conclusion</h4>\n<p>Au final, Le shortcode &laquo;&nbsp;Presentation&nbsp;&raquo; propos&eacute; avec JetPack est une fonction int&eacute;ressante &agrave; conna&icirc;tre. Elle peut rendre de nombreux services. Gageons qu&rsquo;elle sera l&rsquo;outil indispensable de tout d&eacute;veloppeur WordPress pour ses propres pr&eacute;sentations ! A voir au prochain WordCamp ?</p>\n<div class="woo-sc-divider"></div>\n<p>PS : Attention, j&rsquo;ai &eacute;t&eacute; confront&eacute; &agrave; un petit bug (avec Woothemes ??). Apr&egrave;s chaque pr&eacute;sentation, la balise &lt; <code>section</code> &gt; se referme et la mise en page explose ! J&rsquo;ai d&ucirc; rajouter dans le code html la balise correspondante pour r&eacute;-ouvrir la section&hellip;</p>\n<div class="woo-sc-box info  rounded full">Article source &laquo;&nbsp;<a rel="nofollow" title="Voir l\'article" target="_blank" href="http://en.support.wordpress.com/presentations/">Shortcode : presentation</a>&nbsp;&raquo; sur le support de WordPress.com </div>\n<p>Cet article <a rel="nofollow" target="_blank" href="http://www.gd6d.fr/wordpressfr/blog/creer-presentation-diffuser-site-jetpack/">Cr&eacute;er une pr&eacute;sentation et la diffuser dans son site avec&hellip; JETPACK</a> est apparu en premier sur <a rel="nofollow" target="_blank" href="http://www.gd6d.fr/wordpressfr">Gd6d - sp&eacute;cialiste WordPress</a>.</p>\n<img src="http://feeds.feedburner.com/~r/Gd6d/~4/Rng_PI-XPNg" height="1" width="1">\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"Here With Me : Stress test de l’extension WP Rocket";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:68:"http://www.herewithme.fr/2013/09/08/stress-test-extension-wp-rocket/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:68:"http://www.herewithme.fr/2013/09/08/stress-test-extension-wp-rocket/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-09-08T02:16:18+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:16907:"<div>\n<p><img class="alignright size-full wp-image-1394" alt="wp rocket Stress test de lextension WP Rocket" src="http://www.herewithme.fr/wp-content/uploads/2013/09/wp-rocket.png" width="231" height="198" title="Stress test de lextension WP Rocket">Difficile&nbsp;exercice que de faire le test d&rsquo;une extension WordPress,&nbsp;d&eacute;velopp&eacute;e&nbsp;par des personnalit&eacute;s &eacute;minentes de la communaut&eacute; fran&ccedil;aise. (Xavier me dirait : diplomatie, diplomatie&hellip;)</p>\n<p>Je me lance tout de m&ecirc;me dans l&rsquo;aventure&hellip;</p>\n<p>Apr&egrave;s avoir lu beaucoup d&rsquo;articles d&eacute;di&eacute;s &agrave; l&rsquo;extension (dont beaucoup s&rsquo;apparentent davantage &agrave; la de publi-information qu&rsquo;&agrave; une v&eacute;ritable analyse), j&rsquo;ai profit&eacute; d&rsquo;une promo sur Twitter pour acqu&eacute;rir une licence &laquo;&nbsp;professionnelle&nbsp;&raquo; et j&rsquo;ai test&eacute; l&rsquo;extension sur une plateforme de d&eacute;veloppement ainsi que sur 2 projets en phase de production pour me forger MON opinion.</p>\n<p>Voici le premier article de la s&eacute;rie stress test d&rsquo;un plugin WP !</p>\n<h2>La promesse cliente</h2>\n<p>WP-Rocket est une extension pour WordPress qui a comme vocation d&rsquo;am&eacute;liorer les performances de votre site internet. C&rsquo;est une extension&nbsp;&nbsp;&raquo;premium&nbsp;&raquo;, vendue sous 3 licences : personnelle, business et professionnelle.</p>\n<p>Les&nbsp;fonctionnalit&eacute;s&nbsp;propos&eacute;es sont :</p>\n<ul>\n<li>Mise en cache des pages</li>\n<li>Pr&eacute;chargement du cache</li>\n<li>Compression des fichiers statiques</li>\n<li>Chargement diff&eacute;r&eacute; des images</li>\n<li>Optimisation pour le navigateur</li>\n<li>Optimisation des images</li>\n<li>Chargement diff&eacute;r&eacute; des fichiers JavaScript</li>\n</ul>\n<p>Juste que l&agrave;, c&rsquo;est du tr&egrave;s classique on retrouve ni plus ni moins que tous les ingr&eacute;dients de la &laquo;&nbsp;performance web&nbsp;&raquo;.</p>\n<p>Mais la vraie promesse cliente du plugin &agrave; mes yeux, c&rsquo;est &laquo;&nbsp;une configuration rapide&nbsp;&raquo;.</p>\n<p>Dans l&rsquo;univers des plugins WordPress, on trouve des centaines d&rsquo;extensions ayant comme objectif d&rsquo;am&eacute;liorer la performance web d&rsquo;un site internet, et ces extensions partagent syst&eacute;matiquement le m&ecirc;me point commun : elles sont complexes et proposent des tonnes d&rsquo;options. Et le pire, c&rsquo;est que ces options ne sont utilis&eacute;es que par une minorit&eacute; de personnes.</p>\n<p>WP Rocket, &agrave; l&rsquo;image de l&rsquo;extension WYSIJA, mise sur le c&ocirc;t&eacute;&nbsp;simple, rapide et p&eacute;dagogique de leur extension. (un principe de base de la philosophie WP : <a rel="nofollow" target="_blank" href="http://wordpress.org/about/philosophy/#decisions">D&eacute;cisions, not options</a>)</p>\n<p>Et de ce c&ocirc;t&eacute;, on est tr&egrave;s bien servi ! L&rsquo;interface est&nbsp;extr&ecirc;mement&nbsp;propre, les r&eacute;glages de base permettent d&rsquo;activer facilement les fonctionnalit&eacute;s&nbsp;principales de l&rsquo;extension.</p>\n<p>A noter qu&rsquo;il ne semble pas possible de d&eacute;sactiver le cache statique, donc impossible de n&rsquo;utiliser que les fonctionnalit&eacute;s de minification ou de chargement diff&eacute;r&eacute; des images.</p>\n<h2>Analyse technique</h2>\n<p>La question que l&rsquo;on peut se poser face &agrave; une extension qui promet d&rsquo;am&eacute;liorer la performance, c&rsquo;est comment ? Quels m&eacute;canismes sont mis en place ? Les voici en d&eacute;tails</p>\n<h3>Cache statique</h3>\n<p>LA fonctionnalit&eacute; la plus r&eacute;pandue pour am&eacute;liorer la performance d&rsquo;un site WordPress, c&rsquo;est d&rsquo;installer et configurer un cache statique. Le principe est simple, le premier visiteur consulte une page de votre site, le code HTML est g&eacute;n&eacute;r&eacute; dynamiquement par WP et il est stock&eacute; dans le cache pour une dur&eacute;e d&eacute;finie, les visiteurs suivants consultent alors la copie HTML.</p>\n<p>Sur ce point, le plugin est tr&egrave;s classique, les fichiers de cache sont stock&eacute;s sur le syst&egrave;me de fichiers (dans le dossier wp-rocket-cache), ce choix exclut &laquo;&nbsp;en grande majorit&eacute;&nbsp;&raquo; les architectures multi-serveurs (rare c&rsquo;est vrai). A noter, que le cache peut &ecirc;tre diff&eacute;renci&eacute; pour les mobiles, ceci afin de permettre l&rsquo;utilisation de th&egrave;me sp&eacute;cifique. (WP-Touch notamment)</p>\n<p>Ma grande surprise concernant le cache statique et WP Rocket, c&rsquo;est la non-utilisation &nbsp;du &laquo;&nbsp;drop-in&nbsp;&raquo; <em>advanced-cache.php</em>. Ce fichier, que l&rsquo;on trouve g&eacute;n&eacute;ralement dans le dossier <em>wp-content </em>pour peu que votre installation WP utilise un plugin de cache statique &laquo;&nbsp;traditionnel&nbsp;&raquo; permet de g&eacute;rer la fonctionnalit&eacute; de cache statique assez t&ocirc;t dans l&rsquo;ex&eacute;cution de WordPress.</p>\n<p>Ici, point de dropin advanced-cache.php, le plugin utilise exclusivement les r&egrave;gles de r&eacute;&eacute;critures (automatiquement ajout&eacute; dans le fichier .htaccess) pour permettre au serveur HTTP de charger les copies HTML en cache sans solliciter WordPress, ni PHP. C&rsquo;est la technique la plus performante, mais elle requiert l&rsquo;utilisation du serveur HTTP Apache2, cela veut dire que si votre serveur web est NGINX, ou bien Microsoft IIS, le plugin ne sollicitera jamais le cache statique g&eacute;n&eacute;r&eacute;.</p>\n<p>Il faut donc pr&eacute;voir le fait que &laquo;&nbsp;WP-Rocket&nbsp;&raquo; apporte des restrictions suppl&eacute;mentaires par rapport aux pr&eacute;requis de WordPress. Ce qui est dommage, c&rsquo;est qu&rsquo;il est techniquement possible de cumuler les 2 fonctionnalit&eacute;s, c&rsquo;est notamment ce que r&eacute;alise l&rsquo;extension WP-Super-Cache, elle propose de servir les fichiers directement avec le serveur HTTP, et &agrave; d&eacute;faut elle utilise le dropin pour charger la copie en cache un peu plus tard dans le processus.</p>\n<h3>LazyLoad</h3>\n<p>La technique LazyLoad permet de diff&eacute;rer le chargement des images, pour r&eacute;sum&eacute;, seules les images affich&eacute;es r&eacute;ellement sur l&rsquo;&eacute;cran de vos internautes sont t&eacute;l&eacute;charg&eacute;es. Les images pr&eacute;sentes en base de page ne seront t&eacute;l&eacute;charg&eacute;es que si l&rsquo;utilisateur scroll dans son navigateur et affiche cette partie du site.</p>\n<p>La fonctionnalit&eacute; agit uniquement sur le contenu des articles/pages, les widgets, les images &agrave; la une et les avatars. A noter que le code JS n&eacute;cessaire pour cette fonctionnalit&eacute; est ajout&eacute; automatiquement dans le code HTML de votre page afin d&rsquo;&eacute;viter de charger une ressource suppl&eacute;mentaire.</p>\n<h3>Concat&eacute;nation &amp; Minification des JS/CSS</h3>\n<p>La concat&eacute;nation et la minification des ressources JavaScript et des feuilles de style CSS permettent de diminuer le nombre de requ&ecirc;tes HTTP n&eacute;cessaires &agrave; l&rsquo;affichage d&rsquo;une page internet. Le plugin fait appel &agrave; la librairie PHP &laquo;&nbsp;minify&nbsp;&raquo;, &eacute;galement utilis&eacute; par le plugin WP-Minify/BWP-Minify.</p>\n<p>C&rsquo;est donc une valeur s&ucirc;re en terme de technologie, par contre on ne peut &ecirc;tre que d&eacute;&ccedil;u que ce script ne g&eacute;n&egrave;re pas de vrais fichiers CSS/JS comme peut notamment le faire AssetsMinify ou W3 Total Cache.</p>\n<p>Les requ&ecirc;tes vers les ressources JS/CSS font syst&eacute;matiquement appel &agrave; une ressource PHP, moins performante et qui peut s&rsquo;av&eacute;rer probl&eacute;matique &nbsp;lors de la mise en place d&rsquo;un CDN notamment.</p>\n<h3>Compression, expiration des ressources statiques</h3>\n<p>Le plugin affine largement la configuration du serveur web HTTP Apache2 (via le fichier .htaccess) en red&eacute;finissant les propri&eacute;t&eacute;s de mise en cache, de compression des ressources statiques, etc. Cela permet notamment de sp&eacute;cifier que les ressources JS/CSS doivent &ecirc;tre mises en cache par les navigateurs pour une dur&eacute;e d&eacute;finie, et non rafraichies &agrave; chaque visite de la page.</p>\n<p>Les r&egrave;gles ajout&eacute;es sont tr&egrave;s r&eacute;pandues sur la toile, on peut notamment les retrouver dans le starter-kit de r&eacute;f&eacute;rence <a rel="nofollow" target="_blank" href="http://html5boilerplate.com/">HTML5 Boilerplate</a>.</p>\n<h3>Divers</h3>\n<p>Enfin, je passe tr&egrave;s rapidement sur les autres fonctionnalit&eacute;s de l&rsquo;extension que je consid&egrave;re comme mineure ou comme trop &laquo;&nbsp;avanc&eacute;e&nbsp;&raquo; :</p>\n<ul>\n<li>Cookie de 3 minutes pour les personnes ayant post&eacute; un commentaire</li>\n<li>JavaScript avec l&rsquo;attribut &laquo;&nbsp;deferred&nbsp;&raquo; + utilisation du script LABjs</li>\n<li>Suppression des num&eacute;ros de version dans les ressources JS/CSS, notamment s&rsquo;il s&rsquo;agit du num&eacute;ro de version de WP</li>\n<li>Sp&eacute;cification syst&eacute;matique des dimensions des images</li>\n</ul>\n<h2>La sp&eacute;cificit&eacute; du projet et de l&rsquo;extension : Le pr&eacute;chargement</h2>\n<p>Une fonctionnalit&eacute; int&eacute;ressante du projet, c&rsquo;est le pr&eacute;chargement du cache. Au lieu de laisser vos visiteurs patienter lors de la g&eacute;n&eacute;ration des copies HTML et leur mise en cache, le plugin sollicite un robot qui parcourt pour vous les pages les plus visit&eacute;es de votre site pour pr&eacute;charger le cache.</p>\n<p>Notez que ce n&rsquo;est pas une fonctionnalit&eacute; exclusive &agrave; ce projet, le plugin WP Super Cache propose d&eacute;j&agrave; la m&ecirc;me chose. (le c&ocirc;t&eacute; complexe et mystique en plus)</p>\n<p>La diff&eacute;rence, c&rsquo;est que le robot n&rsquo;est pas int&eacute;gr&eacute; au plugin, le robot fonctionne depuis les serveurs de WP-Rocket et ce choix technique est contestable &agrave; mes yeux&nbsp;pour plusieurs points :</p>\n<ul>\n<li>Confidentialit&eacute;, un robot de cette nature fournit indirectement des donn&eacute;es concernant l&rsquo;activit&eacute; d&rsquo;un site internet</li>\n<li>Confidentialit&eacute;, la pr&eacute;sence du robot indique aux auteurs l&rsquo;existence d&rsquo;un site</li>\n<li>Restriction d&rsquo;utilisation, notamment dans la cadre d&rsquo;un site intranet, sans domaine public</li>\n<li>Restriction d&rsquo;utilisation, notamment si le site est prot&eacute;g&eacute; par une authentification</li>\n</ul>\n<p>Alors effectivement, dans la cadre d&rsquo;un site personnel, d&rsquo;un site de TPE/PME, &ccedil;a peut sembler assez anodin. Mais en entreprise, ma cible pr&eacute;f&eacute;r&eacute;e pour WP, c&rsquo;est clairement un mode de fonctionnement&nbsp;r&eacute;dhibitoire.&nbsp;Par ailleurs, la fonctionnalit&eacute; n&rsquo;est pas d&eacute;sactivable&hellip;</p>\n<p>Dans le m&ecirc;me th&egrave;me, l&rsquo;obligation de d&eacute;clarer chaque site utilisant le plugin via le site officiel est quelque chose d&rsquo;assez contraignant. Sur ce point, le mode de fonctionnement de la licence GravityForms est bien plus pratique. Bien heureusement, le contr&ocirc;le de licence est facilement d&eacute;sactivable dans le code source PHP&hellip;</p>\n<h2>Benchmark : Avant/Apr&egrave;s ?</h2>\n<p>Pour &ecirc;tre tout &agrave; fait honn&ecirc;te, j&rsquo;avais initialement pr&eacute;vu d&rsquo;afficher les notes GTmetrix avant et apr&egrave;s.Mais je suis revenu sur ma d&eacute;cision car l&rsquo;impact de l&rsquo;extension sur les performances d&rsquo;un site WordPress d&eacute;pend d&rsquo;un trop grand nombre de param&egrave;tres, notamment :</p>\n<ul>\n<li>L&rsquo;h&eacute;bergement, le plugin peut tr&egrave;s bien fonctionner chez un prestataire A, et avoir un effet quasiment nul chez un prestataire B, notamment s&rsquo;il manque des modules Apache2&hellip;</li>\n<li>Le projet, le th&egrave;me et les extensions utilis&eacute;s, le plugin fonctionne parfaitement avec une installation fraiche, mais il peut g&eacute;n&eacute;rer des conflits JS important sur les th&egrave;mes premiums ou les projets &laquo;&nbsp;complexes&nbsp;&raquo;&hellip;</li>\n</ul>\n<p>Personnellement, j&rsquo;ai rencontr&eacute; des probl&egrave;mes de minification sur les 2 sites de production que j&rsquo;ai test&eacute;, et une fois les probl&egrave;mes r&eacute;solus (ou plut&ocirc;t contourn&eacute;) j&rsquo;ai constat&eacute; une baisse de la notation GTmetrix, malgr&eacute; une am&eacute;lioration de l&rsquo;impression de fluidit&eacute;&hellip;</p>\n<p>Mais tout cela n&rsquo;est gu&egrave;re &eacute;tonnant car ces projets n&rsquo;ont pas &eacute;t&eacute; b&acirc;tis autour de cette extension, il n&rsquo;est donc pas anormal de rencontrer des conflits de cette nature&hellip;</p>\n<p>En conclusion de ce chapitre, je pense que le benchmark comparatif de la performance des plugins de cache est possible, mais il ne refl&egrave;te absolument pas le niveau de performance que vous allez pouvoir obtenir sur votre installation.</p>\n<p>Par exp&eacute;rience, selon les projets et les plugins utilis&eacute;s, j&rsquo;obtiens parfois de meilleurs r&eacute;sultats avec Hyper-Cache, et parfois c&rsquo;est WP-Super-Cache qui fait des merveilles&hellip;</p>\n<h2>Faut-il passer son chemin ?</h2>\n<p>C&rsquo;est une question tr&egrave;s compliqu&eacute;e et la r&eacute;ponse varie selon moi d&rsquo;apr&egrave;s votre niveau technique et l&rsquo;environnement technique de votre projet.</p>\n<p>On peut d&eacute;j&agrave; &eacute;liminer WP-Rocket dans les situations suivantes :</p>\n<ul>\n<li>Utilisation d&rsquo;un serveur web exotique NGINX, Cherokee, Microsoft IIS</li>\n<li>Utilisation d&rsquo;un reverse-proxy avec Varnish ou autre (bien que compatible)</li>\n<li>Architecture multi-serveur, car le cache aura davantage sa place dans un cache objet (cf Batcache)</li>\n<li>Projet d&rsquo;intranet</li>\n</ul>\n<p>Dans ce type d&rsquo;environnement, vous n&rsquo;utiliserez pas 100% des fonctionnalit&eacute;s de WP-Rocket et d&rsquo;autres solutions sont &agrave; consid&eacute;rer &agrave; mon avis.</p>\n<p>Ensuite&hellip;</p>\n<h3>Si vous &ecirc;tes fauch&eacute;s/radins/amateurs des logiciels libres et que vous &ecirc;tes un bidouilleur :<br>\nou<br>\nSi vous &ecirc;tes un professionnel/d&eacute;veloppeur WP :</h3>\n<p>Passez votre chemin, et installez le jeu d&rsquo;extensions suivant</p>\n<ul>\n<li>LazyLoad</li>\n<li>WP Super Cache ou HyperCache</li>\n<li>BWP Minify</li>\n<li>+ fichier HTACCESS optimis&eacute; en s&rsquo;inspirant des r&egrave;gles de HTML5 Boilerplate</li>\n</ul>\n<p>Vous obtiendrez un p&eacute;rim&egrave;tre fonctionnel tr&egrave;s proche de WP-Rocket, des plugins interchangeables et un niveau de performances comparable.</p>\n<h3>Si vous n&rsquo;aviez rien compris &agrave; cet article, que vous n&rsquo;&ecirc;tes pas un bidouilleur ou que vous n&rsquo;avez tout simplement pas de temps &agrave; investir dans la performance web :</h3>\n<p>Vous devriez probablement ouvrir un blog sur WordPress.com ou &agrave; d&eacute;faut prendre une licence WP-Rocket car, et c&rsquo;est ma conclusion,<strong> WP-Rocket ce n&rsquo;est pas simplement une extension de plus &agrave; installer, c&rsquo;est &eacute;galement un service de support (gratuit le temps de la licence &ndash; 1 an) pour vous assister &agrave; la bonne mise en place de la solution.</strong></p>\n<p>Pour avoir fait un tour rapide dans le forum de support, on constate qu&rsquo;une extension de cette nature g&eacute;n&egrave;re beaucoup de discussion, car chaque installation est unique et les bugs rencontr&eacute;s sont &agrave; g&eacute;rer au cas par cas.</p>\n<p>Et donc m&ecirc;me si je ne partage pas l&rsquo;ensemble des choix techniques r&eacute;alis&eacute;s, et que je pr&eacute;f&egrave;re une solution compos&eacute;e de diff&eacute;rentes extensions, je tiens juste &agrave; tirer mon chapeau pour le travail de support que r&eacute;alise les auteurs de cette belle et prometteuse extension.</p>\n<h3>Ma wishlist</h3>\n<p>Assez courte :</p>\n<ul>\n<li>Support de advanced-cache.php</li>\n<li>Documentation &eacute;largie au serveur HTTP Nginx</li>\n<li>Robot de pr&eacute;chargement, en local ou &agrave; distance (au choix)</li>\n<li>Am&eacute;lioration du moteur de minification\n<ul>\n<li>Notamment le filtre d&rsquo;exclusion, qui exclut bien le JS de la minification mais qui le d&eacute;place tout de m&ecirc;me dans l&rsquo;ent&ecirc;te de la page :(</li>\n<li>Utilisation de AssetsMinify ?</li>\n</ul>\n</li>\n<li>Suppression du contr&ocirc;le de licence en mode GravityForms (utilis&eacute; pour les MAJ)</li>\n</ul>\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"Blog Tool Box : WordPress : exclure ses propres visites dans Google Analytics";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:65:"http://blogtoolbox.fr/wordpress-exclure-visites-google-analytics/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:65:"http://blogtoolbox.fr/wordpress-exclure-visites-google-analytics/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-08-19T00:05:18+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:2240:"<div>\n<p>Si vous avez un site qui fait peu de visites, il est tr&egrave;s important d&rsquo;exclure son propre trafic dans Google Analytics pour ne pas fausser les statistiques.<br>\nChaque aper&ccedil;u d&rsquo;article, chaque test sur le design, chaque recherche d&rsquo;un article lors de la r&eacute;daction, etc, entra&icirc;nent des remont&eacute;es de pages vues inutiles dans Analytics.</p>\n<h2>Exclure son propre trafic via un filtre</h2>\n<p>Solution la plus simple si vous avez une adresse IP fixe, il suffit d&rsquo;acc&eacute;der &agrave; l&rsquo;administration du compte ou du profil Analytics puis d&rsquo;acc&eacute;der aux &laquo;&nbsp;Filtres&nbsp;&raquo;. De l&agrave;, il ne reste plus qu&rsquo;&agrave; cr&eacute;er un nouveau filtre qui va exclure le trafic en provenance de votre adresse IP.</p>\n<p><img src="http://blogtoolbox.fr/wp-content/uploads/filtre-google-analytics.png" alt="Filtre Google Analytics"></p>\n<p>A noter que si vous &ecirc;tes plusieurs r&eacute;dacteurs, si vous &eacute;crivez de plusieurs endroits, etc, il sera n&eacute;cessaire de mettre en place plusieurs filtres d&rsquo;IP.</p>\n<h2>Ne pas charger le code de tracking pour les administrateurs/utilisateurs connect&eacute;s</h2>\n<p>Une autre solution est de ne pas lancer le code Google Analytics si le visiteur est un administrateur du site WordPress. Pour ce faire, il suffit d&rsquo;englober le code de tracking par la condition suivante : si le visiteur est un administrateur logg&eacute; alors le code de tracking n&rsquo;est pas actif.</p>\n<p>Exemple ci-dessous : le code Google Analytics est mis en place seulement si l&rsquo;utilisateur (current_user_can) n&rsquo;a pas la capacit&eacute; de modifier les options de WordPress (manage_options = administrateur).</p>\n<pre><code>&lt;?php if(!current_user_can(\'manage_options\')){ ?&gt;\n  &lt;script type="text/javascript"&gt;\n    [...] script Google Analytics [...]\n  &lt;/script&gt;\n&lt;?php } ?&gt;</code></pre>\n<p>Il est &eacute;galement possible d&rsquo;utiliser la fonction WordPress <a rel="nofollow" target="_blank" href="http://codex.wordpress.org/Function_Reference/is_user_logged_in"><i>is user logged in()</i></a> pour matcher tous les utilisateurs connect&eacute;s.</p>\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"Insidedaweb : Les Solutions Flipbooks pour WordPress";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:152:"http://www.insidedaweb.com/wordpress-seo/solutions-flipbooks-wordpress/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=solutions-flipbooks-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:152:"http://www.insidedaweb.com/wordpress-seo/solutions-flipbooks-wordpress/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=solutions-flipbooks-wordpress";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-06-12T11:29:47+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:652:"<div>\n<p>Aujourd&rsquo;hui, les magazines ou les brochures feuilletables en ligne sont de plus en plus pr&eacute;sents sur la toile, en effet, cela constitue une solution avantageuse pour diffuser vos documents, PDF et autres e-books. Les flipbooks sont [&hellip;]</p>\n<p>Cet article <a rel="nofollow" target="_blank" href="http://www.insidedaweb.com/wordpress-seo/solutions-flipbooks-wordpress/">Les Solutions Flipbooks pour WordPress</a> est apparu en premier sur <a rel="nofollow" target="_blank" href="http://www.insidedaweb.com/">Blog WordPress, Blog eCommerce, Blog R&eacute;f&eacute;rencement, Emailing &amp; FOSS. Le site 5 en 1</a>.</p>\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"Fran6art : Ma veille en détails: historique et outils utilisés.";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:61:"http://feedproxy.google.com/~r/Fran6artLeBlog/~3/SqxjR5rCujU/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:61:"http://feedproxy.google.com/~r/Fran6artLeBlog/~3/SqxjR5rCujU/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2012-10-16T14:35:34+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:14479:"<div>\n<p>Hier, mon ami Aur&eacute;lien d&rsquo;All For Design a publi&eacute; <a rel="nofollow" target="_blank" href="http://all-for-design.com/web-design/les-outils-de-ma-veille/">un article int&eacute;ressant</a> expliquant comment il fait sa veille. Je trouve la d&eacute;marche tr&egrave;s int&eacute;ressante parce qu&rsquo;elle permet &agrave; tous de d&eacute;couvrir de nouveaux sites et de nouveaux services. On faisait pas mal &ccedil;a il y a quelques ann&eacute;es, quand le blogging &eacute;tait &agrave; son apog&eacute;e et on a un peu perdu cette habitude. Donc j&rsquo;ai voulu, d&rsquo;une certaine mani&egrave;re, r&eacute;pondre &agrave; Aur&eacute;lien en d&eacute;taillant ici comment je fais ma veille en ligne, comment je me tiens au courant des news du web.</p>\n<p><strong>Une question de temps</strong></p>\n<p>Je crois qu&rsquo;avant de d&eacute;tailler comment je fais ma veille, il est important de parler du facteur temps. Quand j&rsquo;ai commenc&eacute; ce m&eacute;tier en 2005, je blogais beaucoup, je faisais &eacute;norm&eacute;ment de veille. Je &ldquo;veillais&rdquo; jusqu&rsquo;&agrave; 4/5 heures par jour &agrave; ce moment-l&agrave;. Puis ma fille est arriv&eacute;e en 2007, et tout &agrave; chang&eacute;. La charge de travail a aussi consid&eacute;rablement augment&eacute;, me laissant peu de temps pour me tenir au courant chaque jour.</p>\n<p>Jusqu&rsquo;&agrave; il y a peu, ma veille &eacute;tait tr&egrave;s simple. Elle se limitait &agrave; Google Reader et &agrave; <a rel="nofollow" target="_blank" href="https://twitter.com/Fran6/">Twitter</a>. Un grand classique. J&rsquo;ai fait le tri dans mes flux RSS mais sans parvenir &agrave; tout lire r&eacute;guli&egrave;rement. Je me retrouvais donc avec plus de 1000 &eacute;l&eacute;ments &agrave; lire par moment et au final des articles datant de trop longtemps, sans oublier parfois le fait que je les avais d&eacute;j&agrave; vu passer sur Twitter.</p>\n<p>J&rsquo;ai donc laiss&eacute; de c&ocirc;t&eacute; les flux RSS et ai d&eacute;cid&eacute; de concentrer ma veille <a rel="nofollow" target="_blank" href="https://twitter.com/Fran6/">sur Twitter</a>. Je suis 500 personnes environ et j&rsquo;ai d&eacute;j&agrave; l&rsquo;impression que c&rsquo;est trop. Aur&eacute;lien, dans son article, parle de veille passive et active. La veille sur Twitter est un m&eacute;lange des deux pour moi. Elle est active parce que je suis l&agrave; pour &ccedil;a mais aussi passive parce que je lis globalement ce qui se dit sans pour autant faire vraiment de la veille. J&rsquo;esp&egrave;re que je me fais bien comprendre ! <img src="http://www.fran6art.com/wp-includes/images/smilies/icon_biggrin.gif" alt=":D" class="wp-smiley"></p>\n<p>Mais l&agrave; encore, je ne suis pas toujours dispo, donc je loupe pas mal de choses int&eacute;ressantes aussi sur Twitter. L&rsquo;info y file &agrave; une vitesse grand V.</p>\n<p><strong>L&rsquo;iPad, compagnon id&eacute;al pour la veille</strong></p>\n<p>Tout a commenc&eacute; &agrave; changer quand je me suis achet&eacute; un iPad. Je lis &eacute;norm&eacute;ment de livres mais tr&egrave;s peu sur ordinateur. Du coup, la tablette &eacute;tait le bon compromis pour faire de la veille sans pour autant &ecirc;tre bloqu&eacute; derri&egrave;re mon bureau. J&rsquo;avais Twitter en poche, puis j&rsquo;ai adopt&eacute; <a rel="nofollow" target="_blank" href="http://www.instapaper.com/">Instapaper</a>. Super outil pour bookmarker des articles et les lire plus tard. <strong>A condition de les lire plus tard</strong>. J&rsquo;ai accumul&eacute;, tout comme je faisais auparavant avec mes flux RSS et je n&rsquo;arrivais pas &agrave; m&rsquo;en sortir. J&rsquo;ai donc &ldquo;ressorti&rdquo; aussi mes flux RSS en nettoyant bien la liste des sites que je suivais pour me concentrer sur le principal: A list Apart, Smashing Magazine, quelques sites d&rsquo;UX, beaucoup de typo et puis basta. J&rsquo;ai donc utilis&eacute; <a rel="nofollow" target="_blank" href="http://reederapp.com/">Reeder</a>, comme pas mal de monde sur OSX ou iOS, mais l&rsquo;exp&eacute;rience utilisateur pour moi s&rsquo;est av&eacute;r&eacute;e pas terrible. Je trouve que Reeder est tr&egrave;s chouette au niveau style mais n&rsquo;apporte pas vraiment grand chose de plus que Google Reader comme exp&eacute;rience. Ca reste un lecteur plut&ocirc;t classique de flux RSS.</p>\n<p>J&rsquo;ai donc test&eacute; <a rel="nofollow" target="_blank" href="http://flipboard.com/">Flipboard</a>. Super interface, on peut y ajouter nos flux RSS. Pr&eacute;sentation magazine, c&rsquo;&eacute;tait g&eacute;nial. J&rsquo;en ai profit&eacute; pour utiliser l&rsquo;application pour d&rsquo;autres sites que mes flux RSS. J&rsquo;y ai m&ecirc;me install&eacute; Twitter pour tout faire au m&ecirc;me endroit. Super exp&eacute;rience mais un souci. Flipboard ne marque pas tr&egrave;s bien les articles lus sur Google Reader. C&rsquo;est un peu p&eacute;nible &agrave; g&eacute;rer. Si on trouve des articles qui nous int&eacute;ressent pas, il faut quand m&ecirc;me les ouvrir pour les &ldquo;marquer comme lu&rdquo;.</p>\n<p>Puis sont apparus trois outils qui ont consid&eacute;rablement chang&eacute; ma mani&egrave;re de faire de la veille.</p>\n<p><strong>1. Zite</strong></p>\n<p><img class="aligncenter size-medium wp-image-1920" title="ipad" src="http://www.fran6art.com/wp-content/uploads/2012/10/ipad-470x396.png" alt="" width="470" height="396"></p>\n<p><a rel="nofollow" target="_blank" href="http://zite.com/">Zite</a> est une application qui vous propose toutes une s&eacute;ries d&rsquo;articles, selon ce qui vous int&eacute;resse. En gros et pour faire simple, vous commencez avec une s&eacute;rie d&rsquo;articles, propos&eacute;s un peu &agrave; la mani&egrave;re de Flipboard et &agrave; chaque fois vous avez la possibilit&eacute; de dire si vous avez aim&eacute; l&rsquo;article ou pas, et l&rsquo;application vous proposera plus d&rsquo;articles que vous aimez. Plus vous allez lire, plus les articles propos&eacute;s seront proches de ce que vous voulez lire. Et pas besoin de compte Google Reader ici, les sources sont propos&eacute;es par l&rsquo;application. Donc pas de stress inutile &agrave; devoir lire &ldquo;500 &eacute;l&eacute;ments non lus&rdquo;. Les articles sont globalement de tr&egrave;s bonne qualit&eacute; et correspondent aux nouveaut&eacute;s du jour. Tr&egrave;s int&eacute;ressant quand vous avez un moment tranquille sur votre sofa, on a un peu l&rsquo;impression de lire son journal sans trop savoir sur quoi on va tomber.</p>\n<p><strong>2. Feedly</strong></p>\n<p> \n</p>\n<p><a rel="nofollow" target="_blank" href="http://vimeo.com/49048256">The New Feedly Mobile</a> from <a rel="nofollow" target="_blank" href="http://vimeo.com/feedly">Feedly</a> on <a rel="nofollow" target="_blank" href="http://vimeo.com/">Vimeo</a>.</p>\n<p>J&rsquo;avais test&eacute; l&rsquo;application &agrave; ses d&eacute;buts mais c&rsquo;&eacute;tait trop bugg&eacute; pour moi et pas assez original par rapport &agrave; un Flipboard. Sauf que les derni&egrave;res versions se sont fortement am&eacute;lior&eacute;s et qu&rsquo;elles apportent quelques nouveaut&eacute;s qui ont chang&eacute; pas mal de choses pour moi.</p>\n<p>Pour ceux qui ne connaissent pas, Feedly est un lecteur de flux RSS, mais pas seulement, il propose maintenant des flux un peu comme Flipboard.</p>\n<p>Le souci de Feedly au d&eacute;part &eacute;tait le m&ecirc;me, justement, que pour Flipboard. Que faire quand on tombe sur une page avec des articles qu&rsquo;on n&rsquo;a pas trop envie de lire ? Il faut les ouvrir un par un pour les marquer comme lu. Relou. Avec la derni&egrave;re version de Feedly, un swipe vers le bas sur la page marque les articles comme lus. Tip top et super simple. Je lis quelques blogs Apple ou encore The Verge et chez certains la quantit&eacute; d&rsquo;articles r&eacute;dig&eacute;s par jour est &eacute;norme et seulement une partie m&rsquo;int&eacute;resse. Avec Reeder, j&rsquo;aurais vir&eacute; le flux parce que &ccedil;a aurait rapidement &eacute;t&eacute; impossible &agrave; g&eacute;rer ou j&rsquo;aurais tout marqu&eacute; comme lu. Avec Feedly, je parcoure les pages rapidement sur mon iPad, je swipe vers le bas pour marquer comme lu chaque page et je lis ce qui m&rsquo;int&eacute;resse. Ca peut para&icirc;tre con mais j&rsquo;ai retrouv&eacute; le plaisir de lire mes flux RSS de mani&egrave;re simple et intuitive gr&acirc;ce &agrave; une tr&egrave;s belle mise en page magazine. J&rsquo;en profite aussi pour bookmarker certains articles sur <a rel="nofollow" target="_blank" href="http://http://getpocket.com">Pocket</a> ( qui a remplac&eacute; Instapaper chez moi&hellip;) m&ecirc;me si comme expliqu&eacute; plus haut, je bookmarke plus que je lis.</p>\n<p>En fait, le souci de ces outils comme Pocket, Instapaper ou m&ecirc;me Google Reader, c&rsquo;est que la plupart du temps, il est publi&eacute; plus d&rsquo;articles qu&rsquo;on ne peut en lire. Donc c&rsquo;est vou&eacute; &agrave; l&rsquo;&eacute;chec d&rsquo;une certaine mani&egrave;re, sauf si on a du temps&hellip;</p>\n<p><strong>3. Pinterest</strong></p>\n<p><img class="aligncenter size-medium wp-image-1921" title="Pinterest-application-ipad-android" src="http://www.fran6art.com/wp-content/uploads/2012/10/Pinterest-application-ipad-android-470x310.jpg" alt="" width="470" height="310"></p>\n<p>Pendant un moment j&rsquo;ai utilis&eacute; <a rel="nofollow" target="_blank" href="https://gimmebar.com/">Gimme Bar</a> comme Aur&eacute;lien pour toute une veille graphique: sites web, UX, illustration, photo et typo. Mais j&rsquo;ai quelques soucis avec l&rsquo;interface et pour bookmarker des sites web, j&rsquo;utilise Little Snapper, malgr&eacute; que ce soit loin d&rsquo;&ecirc;tre parfait. Gimme Bar a pourtant sorti une application iPhone mais elle n&rsquo;est m&ecirc;me pas finalis&eacute;, certaines fonctions affichent m&ecirc;me un message &ldquo;Coming soon&rdquo;. Super.</p>\n<p>Et il y a quelques semaines, je d&eacute;cide de rouvrir <a rel="nofollow" target="_blank" href="http://pinterest.com/fran6/">mon compte Pinterest</a> et d&rsquo;aller &agrave; la p&ecirc;che aux id&eacute;es. Et l&agrave;, je suis surpris par la qualit&eacute; des &eacute;l&eacute;ments partag&eacute;s. C&rsquo;est clair que si vous y recherchez des exemples de sites web, vous allez &ecirc;tre d&eacute;&ccedil;us. Il y en a mais pas des masses. Par contre, pour toute autre inspiration, je trouve le site g&eacute;nial.</p>\n<p>D&eacute;j&agrave; il y a une communaut&eacute; impressionnante. Difficile m&ecirc;me parfois de suivre plus de 100 personnes tellement certaines proposent de nouvelles choses constamment. Les &eacute;l&eacute;ments que je pr&eacute;f&egrave;re sont bien entendu <a rel="nofollow" target="_blank" href="http://pinterest.com/fran6/typography/">la typographie</a>. Je n&rsquo;ai encore trouv&eacute; nulle part ailleurs autant de choses de qualit&eacute; et aussi diversifi&eacute;es. Vraiment sympa. Pas mal d&rsquo;inspiration au niveau d&eacute;co d&rsquo;int&eacute;rieur, print, illustration &eacute;galement. Personnellement, j&rsquo;aime aussi aller chercher parfois mon inspiration dans des domaines qui sont plus annexes &agrave; mon activit&eacute;. Et l&agrave; j&rsquo;y trouve mon compte.</p>\n<p>Un gros plus de Pinterest c&rsquo;est aussi ses applications iPhone et iPad. O&ugrave; que je sois, je peux acc&eacute;der &agrave; ce que j&rsquo;ai bookmark&eacute;. Et tout comme Zite par exemple, ici pas de chiffre d&rsquo;&eacute;l&eacute;ments non lus. On surfe sur une page, on peut naviguer aussi selon des cat&eacute;gories. Encore une super veille &agrave; faire sur son sofa en soir&eacute;e ! <img src="http://www.fran6art.com/wp-includes/images/smilies/icon_wink.gif" alt=";-)" class="wp-smiley"></p>\n<p>Enfin, c&rsquo;est aussi un r&eacute;seau social donc vous pouvez suivre vos amis ou vos designers pr&eacute;f&eacute;r&eacute;s.</p>\n<p>Donc, vous l&rsquo;aurez s&ucirc;rement compris, je fais maintenant principalement ma veille sur tablette et quasiment plus sur mon ordinateur. Je suis aussi plus disponible pour faire cette veille via la tablette. Sur l&rsquo;ordi, je ne consulte que Twitter au final, sur lequel je retweete pas mal de choses que je d&eacute;couvre. Le reste se fait le matin apr&egrave;s le petit dej ou le soir apr&egrave;s le travail. Je consulte rapidement Zite, puis Pinterest et d&eacute;roule mes flux RSS. Et si j&rsquo;ai le temps je lis quelques articles bookmark&eacute;s sur Pocket. C&rsquo;est tout, mais c&rsquo;est d&eacute;j&agrave; pas mal, vu le temps qui m&rsquo;est donn&eacute;. Je dois avouer que l&rsquo;iPad joue un r&ocirc;le important ici. Sans lui je ne ferai probablement plus beaucoup de veille. A noter aussi que toujours gr&acirc;ce &agrave; ma tablette, je suis plus productif dans la journ&eacute;e car je ne fais pas vraiment de veille, hormis un peu Twitter.</p>\n<p>Voici donc ma m&eacute;thode pour suivre l&rsquo;actu web. Largement moins d&rsquo;outils et de services qu&rsquo;Aur&eacute;lien mais plut&ocirc;t un retour d&rsquo;exp&eacute;rience comme j&rsquo;aime les faire. Je ne dis pas non plus que c&rsquo;est la mani&egrave;re id&eacute;ale de faire de la veille mais c&rsquo;est celle qui me correspond le mieux, avec le temps qui m&rsquo;est donn&eacute; <img src="http://www.fran6art.com/wp-includes/images/smilies/icon_smile.gif" alt=":)" class="wp-smiley"></p>\n<p>N&rsquo;h&eacute;sitez pas &agrave; partager vos m&eacute;thodes pour faire de la veille, que ce soit en commentaire ou, comme j&rsquo;ai pu le faire apr&egrave;s la lecture de l&rsquo;article d&rsquo;Aur&eacute;lien, sur votre blog, si vous en avez un ! <img src="http://www.fran6art.com/wp-includes/images/smilies/icon_smile.gif" alt=":)" class="wp-smiley"></p>\n<div class="feedflare">\n<a rel="nofollow" target="_blank" href="http://feeds.feedburner.com/~ff/Fran6artLeBlog?a=SqxjR5rCujU:k3kXTXqFDpU:D7DqB2pKExk"><img src="http://feeds.feedburner.com/~ff/Fran6artLeBlog?i=SqxjR5rCujU:k3kXTXqFDpU:D7DqB2pKExk" border="0"></a> <a rel="nofollow" target="_blank" href="http://feeds.feedburner.com/~ff/Fran6artLeBlog?a=SqxjR5rCujU:k3kXTXqFDpU:guobEISWfyQ"><img src="http://feeds.feedburner.com/~ff/Fran6artLeBlog?i=SqxjR5rCujU:k3kXTXqFDpU:guobEISWfyQ" border="0"></a>\n</div>\n<img src="http://feeds.feedburner.com/~r/Fran6artLeBlog/~4/SqxjR5rCujU" height="1" width="1">\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"Webinventif : [Wordpress] iTypo: thème WordPress gratuit";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.webinventif.com/itypo/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:33:"http://www.webinventif.com/itypo/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2011-01-01T15:36:24+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:5703:"<div>\n<p>Apr&egrave;s 1 an sans rien avoir &eacute;crit sur ce blog (bouhhhh), je fais mon retour en vous proposant un joli <strong>th&egrave;me WordPress</strong>, le 1er que je distribue publiquement et <em>gratuitement</em> &eacute;videment. D\'ailleurs si les retours sont bons, &ccedil;a sera peut-&ecirc;tre le d&eacute;but d\'une s&eacute;rie plus ou moins longue.</p>\n<p><strong>iTypo</strong> est donc un th&egrave;me WordPress simple et l&eacute;ger. A la base, je cherchais un th&egrave;me pour un petit projet personnel qui soit assez &eacute;pur&eacute; et l&eacute;ger pour mettre le contenu du blog en avant. Apr&egrave;s de nombreuses recherches dans la jungle des th&egrave;mes WordPress, rien ne me convenait, et comme j\'avais une id&eacute;e tr&egrave;s pr&eacute;cise de ce que je voulais, j\'ai fini par le faire moi-m&ecirc;me ... l\'histoire classique de la naissance d\'un th&egrave;me en somme <img src="http://www.webinventif.com/wp-includes/images/smilies/icon_wink.gif" alt=";)" class="wp-smiley" title="Icon Wink"></p>\n<p>Il est &eacute;videment "Widgets ready", compatible WordPress 3.0+, disponible en 4 coloris et 6 langues, convient parfaitement pour un blog perso ou un mini blog "&agrave; la Tumblr" et est absolument gratuit. <img src="http://www.webinventif.com/wp-includes/images/smilies/icon_wink.gif" alt=";)" class="wp-smiley" title="Icon Wink"></p>\n<p><img src="http://www.webinventif.com/wp-content/uploads/2011/01/pres1.png" alt="pres1" title="pres" class="aligncenter wp-image-621"></p>\n<h3>Telecharger le th&egrave;me gratuitement</h3>\n<p> iTypo est sous license GPL, vous pouvez l\'utiliser gratuitement pour vos projets sans restrictions</p>\n<p><a rel="nofollow" target="_blank" href="http://www.webinventif.com/wp-content/uploads/2011/01/capture-complete.png"><img src="http://www.webinventif.com/wp-content/uploads/2011/01/capture-complete-300x740.png" alt="capture-complete-300x740" title="capture-complete" class="alignnone size-medium wp-image-610"></a></p>\n<ul>\n<li><a rel="nofollow" target="_blank" href="http://themes.webinventif.fr/">Live demo</a></li>\n<li><a rel="nofollow" target="_blank" href="http://www.webinventif.com/wp-content/uploads/2011/01/capture-complete.png">Large preview (.png, 310 Kb)</a></li>\n<li><a rel="nofollow" target="_blank" href="http://www.webinventif.com/itypo/2/">Guide d\'installation et documentation</a></li>\n<li><a rel="nofollow" target="_blank" href="http://goo.gl/H7i2c">Telecharger le .zip, v1.0.2 (zip, 353 kb)</a></li>\n</ul>\n<h3>Features</h3>\n<ul>\n<li>Widget ready (footer et sidebar)</li>\n<li>Disponible par d&eacute;faut en 6 langues (et plus si n&eacute;cessaire)</li>\n<li>4 coloris diff&eacute;rents</li>\n<li>Facile &agrave; personnaliser avec sa page d\'options</li>\n<li>Choix de miniatures carr&eacute; ou large sur la page d\'accueil</li>\n<li>Choix d\'afficher un extrait ou le post complet sur la home</li>\n<li>WordPress Post Thumbnail activ&eacute;</li>\n<li>Shortcode pour miniature</li>\n<li>JQuery Colorbox Lightbox (d&eacute;sactivable via la page d\'options)</li>\n<li>"Sticky post" skinn&eacute;</li>\n<li>Commentaires en "thread" (discussion)</li>\n<li>Mise en avant de l\'auteur</li>\n<li>Logo personnalisable (upload d\'image)</li>\n<li>Compatible Feedburner</li>\n<li>WP-pagenavi ready</li>\n<li>Et encore plein de petites choses ...</li>\n</ul>\n<h3>Captures</h3>\n<p><a rel="nofollow" target="_blank" href="http://www.webinventif.com/wp-content/uploads/2011/01/commentaires.png"><img src="http://www.webinventif.com/wp-content/uploads/2011/01/commentaires-300x894.png" alt="commentaires-300x894" title="commentaires" class="alignnone size-medium wp-image-615"></a><br>\n(Commentaires)</p>\n<p><a rel="nofollow" target="_blank" href="http://www.webinventif.com/wp-content/uploads/2011/01/avec-thumb-wide.png"><img src="http://www.webinventif.com/wp-content/uploads/2011/01/avec-thumb-wide-300x823.png" alt="avec-thumb-wide-300x823" title="avec-thumb-wide" class="alignnone size-medium wp-image-609"></a><br>\n(Avec miniatures larges)</p>\n<p><a rel="nofollow" target="_blank" href="http://www.webinventif.com/wp-content/uploads/2011/01/capture-complet-fullpost.png"><img src="http://www.webinventif.com/wp-content/uploads/2011/01/capture-complet-fullpost-300x1932.png" alt="capture-complet-fullpost-300x1932" title="capture-complet-fullpost" class="alignnone size-medium wp-image-614"></a><br>\n(Accueil avec les billets complets)</p>\n<p><a rel="nofollow" target="_blank" href="http://www.webinventif.com/wp-content/uploads/2011/01/options-page.png"><img src="http://www.webinventif.com/wp-content/uploads/2011/01/options-page-300x192.png" alt="options-page-300x192" title="options-page" class="alignnone size-medium wp-image-618"></a><br>\n(Page d\'options)</p>\n<p><a rel="nofollow" target="_blank" href="http://www.webinventif.com/wp-content/uploads/2011/01/upload-logo.png"><img src="http://www.webinventif.com/wp-content/uploads/2011/01/upload-logo-300x202.png" alt="upload-logo-300x202" title="upload-logo" class="alignnone size-medium wp-image-619"></a><br>\n(Page d\'upload de logo)</p>\n<p>A noter que m&ecirc;me si il fonctionne sous IE6 et sup&eacute;rieur, certains effets CSS3 ne seront pas pris en charge (typographie personnalis&eacute;e, ombres, inclinaisons, ...)</p>\n<p>Voil&agrave;, en esp&eacute;rant qu\'il plaira &agrave; certains d\'entre vous ! Comme je le distribue gratuitement, il serait fairplay de laisser les cr&eacute;dits du footer <img src="http://www.webinventif.com/wp-includes/images/smilies/icon_wink.gif" alt=";)" class="wp-smiley" title="Icon Wink"></p>\n<img src="http://www.webinventif.com/wp-content/plugins/mycompteur/compte.php?idpage=608" width="0" height="0" alt="" title="">\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:26:"wordpressfrancophoneplanet";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}s:4:"type";i:512;s:7:"headers";a:10:{s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"etag";s:27:"mkSr56MBGY+jrjObzna3Q24diOk";s:13:"last-modified";s:29:"Thu, 28 Nov 2013 13:12:20 GMT";s:4:"date";s:29:"Thu, 28 Nov 2013 13:20:32 GMT";s:7:"expires";s:29:"Thu, 28 Nov 2013 13:20:32 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20131115134507";}', 'no'); 
INSERT INTO `wp_options` VALUES (479, '_transient_timeout_feed_mod_2fb9572e3d6a42f680e36370936a57ae', '1385688032', 'no'); 
INSERT INTO `wp_options` VALUES (480, '_transient_feed_mod_2fb9572e3d6a42f680e36370936a57ae', '1385644832', 'no'); 
INSERT INTO `wp_options` VALUES (481, '_transient_timeout_dash_aa95765b5cc111c56d5993d476b1c2f0', '1385688032', 'no'); 
INSERT INTO `wp_options` VALUES (482, '_transient_dash_aa95765b5cc111c56d5993d476b1c2f0', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://feedproxy.google.com/~r/WordpressFrancophone/~3/YqF0QRIza80/\' title=\' BuddyPress : Codex et traduction Le Codex de BuddyPress a été mis à jour (en), notamment avec des articles de nos amis français iMath et Chouf1. En outre, des informations concernant la traduction de l’extension sociale sont également fournies, ainsi qu’une liste de tâche pour améliorer la situation. BP Show Friends 2.0 iMath met à jour sa première extension BuddyPress. C’est forcément un mini événement ! Flux RSS, Panda et Penguin L’analyse de Yoast sur ce sujet fort intéressant (en) qu’est le déclin du flux RSS et l’arrivée de Panda et Penguin, les mises à jour des bases de Google. Simple Theme ThemeSmarts propose un thème gratuit : Simple Theme (en). Comment organiser son blog avec WordPress ? Quelques idées pour mieux bloguer avec WordPress. La sécurité de WordPress La sécurité de WordPress (en) est toujours au cœur des préoccupations. Contribuer à WordPress en étant un pro Quel intérêt pour un professionnel de contribuer à la communauté WordPress ? Voici une réponse (en). La veille WordPress Un sujet qui m’intéresse forcément. Fabrice évoque l’art de la veille en prenant exemple sur ce qu’il fait pour WordPress. WooCommerce 2.1 Beta 1 L’extension e-commerce bien connue pour WordPress, WooCommerce débarque en bersion 2.1 beta 1 (en). A vos tests ! Joomla! vs WordPress La bataille commence ! Qui de WordPress ou de Joomla! l’emportera en combat singulier ? Rendre visible ses activités à travers un blog WordPress Stephanie Booth a fait un atelier présentant les intérêts de bloguer et de WordPress. La vidéo est en ligne !        \'>WordPress Francophone : L’Hebdo WordPress n°209 : BuddyPress – Veille – Contribution</a></li><li><a class=\'rsswidget\' href=\'http://www.cree1site.com/wordpress-vs-joomla-seo/\' title=\' Vu sur le site de l&#039;agence web Cree1site.com Pour critiquer il faut savoir… …c’est pourquoi j’ai testé la dernière version de Joomla pour voir où ils en sont avec leur CMS niveau SEO. Dans cette série d’article que je prévois, j’ai fait un retour aux sources et prévu à cet effet deux installations totalement neutres, vierge de tout plugin, utilisant leur thème par […] Cet article WordPress Vs Joomla : Duel SEO est apparu en premier sur Cree1site.com \'>Cree1site : WordPress Vs Joomla : Duel SEO</a></li><li><a class=\'rsswidget\' href=\'http://wpformation.com/ma-veille-wordpress/\' title=\' Suivre un domaine d’intérêt particulier implique de sélectionner des sources et si elles sont nombreuses il vous faudra nécessairement des outils pour les suivre... Retrouvez ci-après ma veille WordPress et quelques outils efficaces pour optimiser la vôtre! Les sources pour ma veille WordPress Sur Twitter Mon réseau préféré et certainement l&#039;un des plus réactif. Il ...   Ma veille WordPress est un article de WP FormationFormation WordPress &amp; eCommerce - Retrouvez-moi sur Facebook - Twitter - Google+  \'>WP Formation : Ma veille WordPress</a></li><li><a class=\'rsswidget\' href=\'http://boiteaweb.fr/wordpress-seo-pagination-hooks-rapidite-contre-flexibilite-7757.html\' title=\' Je viens vous dire quelques mots à propos du très connu plugin WordPress SEO. Je ne vais pas parler SEO, désolé. Merci à bientôt. Vous êtes restés ? Ha vous êtes encore là, alors vous êtes développeur ou au moins intéressé par ce que je vais raconter. Attention je vais râler un peu ... si si parfois il le faut. Je ne présente pas ce plugin, vous savez déjà à […] Cet article WordPress SEO, la pagination, et ses hooks : Rapidité contre Flexibilité est apparu en premier sur BoiteAWeb.fr. \'>BoiteAWeb : WordPress SEO, la pagination, et ses hooks : Rapidité contre Flexibilité</a></li><li><a class=\'rsswidget\' href=\'http://www.echodesplugins.li-an.fr/plugins/private-only-2/\' title=\'Votre Wordpress en mode privé\'>L&#039;écho des plugins WordPress : Private Only</a></li></ul></div>', 'no'); 
INSERT INTO `wp_options` VALUES (483, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1385688036', 'no'); 
INSERT INTO `wp_options` VALUES (484, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"\n	\n";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"\n		\n		\n		\n		\n		\n		\n				\n\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n\n	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 28 Nov 2013 12:54:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2141@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"753@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your Wordpress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"132@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"23862@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8321@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"15@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29860@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"18101@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"1169@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:122:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 7.5 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Captcha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/captcha/#post-26129";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Apr 2011 05:53:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"26129@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:79:"This plugin allows you to implement super security captcha form into web forms.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"bestwebsoft";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Advanced Custom Fields";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/advanced-custom-fields/#post-25254";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Mar 2011 04:07:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"25254@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"Fully customise WordPress edit screens with powerful fields. Boasting a professional interface and a powerfull API, it’s a must have for any web dev";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"elliotcondon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WP Super Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/wp-super-cache/#post-2572";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Nov 2007 11:40:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2572@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:73:"A very fast caching engine for WordPress that produces static html files.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Donncha O Caoimh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Fast Secure Contact Form";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/plugins/si-contact-form/#post-12636";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 27 Aug 2009 01:20:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"12636@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"An easy and powerful form builder that lets your visitors send you email. Blocks all automated spammers. No templates to mess with.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Mike Challis";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"Contact Form";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/plugins/contact-form-plugin/#post-26890";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 26 May 2011 07:34:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"26890@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:43:"Add Contact Form to your WordPress website.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"bestwebsoft";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"WP-Optimize";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://wordpress.org/plugins/wp-optimize/#post-8691";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 21 Jan 2009 04:28:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8691@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:115:"This simple but effective plugin allows you to clean up your WordPress database and optimize it without phpMyAdmin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"ruhanirabin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:45:"http://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Thu, 28 Nov 2013 13:20:36 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:7:"expires";s:29:"Thu, 28 Nov 2013 13:29:27 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Thu, 28 Nov 2013 12:54:27 +0000";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20131115134507";}', 'no'); 
INSERT INTO `wp_options` VALUES (485, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1385688036', 'no'); 
INSERT INTO `wp_options` VALUES (486, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1385644836', 'no'); 
INSERT INTO `wp_options` VALUES (487, '_transient_timeout_feed_77fa140e07ce53fe8c87136636f83d72', '1385688037', 'no'); 
INSERT INTO `wp_options` VALUES (488, '_transient_feed_77fa140e07ce53fe8c87136636f83d72', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"\n	\n";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"\n		\n		\n		\n		\n		\n		\n				\n\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n\n	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress Plugins » View: Newest";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/plugins/browse/new/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress Plugins » View: Newest";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 28 Nov 2013 12:54:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"BP Searchable Activity";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/bp-searchable-activity/#post-61072";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 26 Nov 2013 07:49:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"61072@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:73:"BuddyPress Searchable Activity allows users to search BuddyPress Activity";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Anu Sharma";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"BB Edition Control";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/bb-edition-control/#post-61070";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 26 Nov 2013 02:58:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"61070@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Plugin para categorizar todo conteúdo em edições, como em um jornal.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"brunobarros";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"FW Mini-Termin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/mini-termin/#post-60957";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Nov 2013 15:15:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60957@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:64:"Mini Terminkalender, jeder Beitrag kann zum Terminbeitrag werden";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Tikolan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:23:"Youtube Playlist Player";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/plugins/youtube-playlist-player/#post-61097";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 26 Nov 2013 21:04:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"61097@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"Display a Youtube player with jQuery/HTML5 playlist on any post or page using a simple shortcode.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Ciprian Popescu";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"Comments On";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/comments-on/#post-49279";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Feb 2013 05:04:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"49279@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:132:"Comments On adds a column to the &#34;All Posts&#34;/&#34;All Pages&#34; view in the Admin dashboard showing the status of comments.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"seanchayes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:9:"Move Post";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/plugins/move-post/#post-61083";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 26 Nov 2013 17:40:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"61083@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:40:"Move posts from one category to another.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"nitinmaurya12";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Cloudup oEmbed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/cloudup-oembed/#post-61119";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Nov 2013 14:35:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"61119@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:51:"This itsy bitsy plugin adds Cloudup oEmbed support.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"hanni";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Re-slug";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/re-slug/#post-61071";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 26 Nov 2013 06:40:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"61071@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:80:"This plugin allows you to generate a new permalink when you change a post title.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"jcexygy";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Responsive Flickr Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/plugins/responsive-flickr-gallery/#post-60878";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 21 Nov 2013 02:49:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60878@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:80:"Responsive galleries from your Flickr photos for your WordPress enabled website.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Lars Schenk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"WP Excel CMS";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wp-excel-cms/#post-61104";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 26 Nov 2013 22:16:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"61104@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:113:"Simple Plugin to import Excel files to Wordpress and use the Data in your theme.\nNo Database entries are created.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"webteilchen";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"InfoBar Top Notification";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/infobar/#post-61076";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 26 Nov 2013 10:48:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"61076@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"A easy and quick way to add top notification bar and call to action for your site. Easy way to grab visitors attention. Tell them about specific page.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"PankajAgarwal";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"Contact Form 7 Style";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:61:"http://wordpress.org/plugins/contact-form-7-style/#post-61075";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 26 Nov 2013 10:32:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"61075@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:76:"Simple contact form 7 style addon that has templates that can be customized.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Johnny";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Masonry Widget";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://wordpress.org/plugins/so-masonry/#post-61036";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 25 Nov 2013 09:47:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"61036@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:53:"Gives you a stunning masonry layout for your website.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Greg Priday";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"Contentlook - the Content Marketing Audit";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/contentlook/#post-61105";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 26 Nov 2013 22:17:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"61105@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"ContentLook helps you take a look at your whole Content Marketing strategy, including your 6 main areas.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Squirrly UK";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"Pit Login Welcome";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/pit-login-welcome/#post-61000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 24 Nov 2013 15:15:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"61000@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:140:"This is a simple plugin. Pit Login Welcome is a Plugin which can give a Random Welcome message to your blog/Website&#039;s users when login.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Pantho Bihosh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:41:"http://wordpress.org/plugins/rss/view/new";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Thu, 28 Nov 2013 13:20:37 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:7:"expires";s:29:"Thu, 28 Nov 2013 13:29:20 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Thu, 28 Nov 2013 12:54:20 +0000";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20131115134507";}', 'no'); 
INSERT INTO `wp_options` VALUES (489, '_transient_timeout_feed_mod_77fa140e07ce53fe8c87136636f83d72', '1385688037', 'no'); 
INSERT INTO `wp_options` VALUES (490, '_transient_feed_mod_77fa140e07ce53fe8c87136636f83d72', '1385644837', 'no'); 
INSERT INTO `wp_options` VALUES (491, '_transient_timeout_plugin_slugs', '1385731244', 'no'); 
INSERT INTO `wp_options` VALUES (492, '_transient_plugin_slugs', 'a:8:{i:0;s:19:"akismet/akismet.php";i:1;s:36:"contact-form-7/wp-contact-form-7.php";i:2;s:43:"google-analyticator/google-analyticator.php";i:3;s:9:"hello.php";i:4;s:41:"responsive-add-ons/responsive-add-ons.php";i:5;s:33:"seo-automatic-links/seo-links.php";i:6;s:29:"wp-db-backup/wp-db-backup.php";i:7;s:24:"wordpress-seo/wp-seo.php";}', 'no'); 
INSERT INTO `wp_options` VALUES (493, '_transient_timeout_dash_de3249c4736ad3bd2cd29147c4a0d43e', '1385688038', 'no'); 
INSERT INTO `wp_options` VALUES (494, '_transient_dash_de3249c4736ad3bd2cd29147c4a0d43e', '<h4>Plus populaire</h4>\n<h5><a href=\'http://wordpress.org/plugins/contact-form-plugin/\'>Contact Form</a></h5>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=contact-form-plugin&amp;_wpnonce=9b0a8840f7&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Contact Form\'>Installer</a>)</span>\n<p>Add Contact Form to your WordPress website.</p>\n<h4>Nouvelles extensions</h4>\n<h5><a href=\'http://wordpress.org/plugins/youtube-playlist-player/\'>Youtube Playlist Player</a></h5>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=youtube-playlist-player&amp;_wpnonce=a0d8c297a9&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Youtube Playlist Player\'>Installer</a>)</span>\n<p>Display a Youtube player with jQuery/HTML5 playlist on any post or page using a simple shortcode.</p>\n', 'no'); 
INSERT INTO `wp_options` VALUES (495, 'wp_db_backup_excs', 'a:2:{s:9:"revisions";a:0:{}s:4:"spam";a:0:{}}', 'yes'); 
INSERT INTO `wp_options` VALUES (496, 'wpdb_backup_recip', 'contact@ab-agency.fr', 'yes');
#
# End of data contents of table `wp_options`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=284 DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_postmeta`
#
 
INSERT INTO `wp_postmeta` VALUES (53, 18, '_wp_attached_file', '2013/11/logo.png'); 
INSERT INTO `wp_postmeta` VALUES (54, 18, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:233;s:6:"height";i:107;s:4:"file";s:16:"2013/11/logo.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"logo-150x107.png";s:5:"width";i:150;s:6:"height";i:107;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `wp_postmeta` VALUES (55, 19, '_wp_attached_file', '2013/11/logo1.png'); 
INSERT INTO `wp_postmeta` VALUES (56, 19, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:233;s:6:"height";i:107;s:4:"file";s:17:"2013/11/logo1.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"logo1-150x107.png";s:5:"width";i:150;s:6:"height";i:107;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `wp_postmeta` VALUES (57, 20, '_wp_attached_file', '2013/11/logo2.png'); 
INSERT INTO `wp_postmeta` VALUES (58, 20, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:233;s:6:"height";i:107;s:4:"file";s:17:"2013/11/logo2.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"logo2-150x107.png";s:5:"width";i:150;s:6:"height";i:107;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `wp_postmeta` VALUES (59, 21, '_wp_attached_file', '2013/11/logo3.png'); 
INSERT INTO `wp_postmeta` VALUES (60, 21, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:233;s:6:"height";i:107;s:4:"file";s:17:"2013/11/logo3.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"logo3-150x107.png";s:5:"width";i:150;s:6:"height";i:107;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `wp_postmeta` VALUES (61, 22, '_wp_attached_file', '2013/11/logo21.png'); 
INSERT INTO `wp_postmeta` VALUES (62, 22, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:174;s:6:"height";i:80;s:4:"file";s:18:"2013/11/logo21.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"logo21-150x80.png";s:5:"width";i:150;s:6:"height";i:80;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `wp_postmeta` VALUES (63, 23, '_wp_attached_file', '2013/11/logo22.png'); 
INSERT INTO `wp_postmeta` VALUES (64, 23, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:150;s:6:"height";i:69;s:4:"file";s:18:"2013/11/logo22.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `wp_postmeta` VALUES (73, 26, '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES (74, 26, '_edit_lock', '1385395827:1'); 
INSERT INTO `wp_postmeta` VALUES (75, 26, '_wp_page_template', 'template-propos.php'); 
INSERT INTO `wp_postmeta` VALUES (76, 28, '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES (77, 28, '_edit_lock', '1385385558:1'); 
INSERT INTO `wp_postmeta` VALUES (78, 28, '_wp_page_template', 'reparations.php'); 
INSERT INTO `wp_postmeta` VALUES (79, 30, '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES (80, 30, '_edit_lock', '1385393609:1'); 
INSERT INTO `wp_postmeta` VALUES (81, 30, '_wp_page_template', 'template-team.php'); 
INSERT INTO `wp_postmeta` VALUES (82, 33, '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES (83, 33, '_edit_lock', '1385471082:1'); 
INSERT INTO `wp_postmeta` VALUES (84, 33, '_wp_page_template', 'template-medias.php'); 
INSERT INTO `wp_postmeta` VALUES (85, 35, '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES (86, 35, '_edit_lock', '1385474576:1'); 
INSERT INTO `wp_postmeta` VALUES (87, 35, '_wp_page_template', 'template-contact.php'); 
INSERT INTO `wp_postmeta` VALUES (88, 37, '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES (89, 37, '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES (90, 37, '_menu_item_object_id', '35'); 
INSERT INTO `wp_postmeta` VALUES (91, 37, '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES (92, 37, '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES (93, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES (94, 37, '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES (95, 37, '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES (96, 37, '_menu_item_orphaned', '1385118453'); 
INSERT INTO `wp_postmeta` VALUES (97, 38, '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES (98, 38, '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES (99, 38, '_menu_item_object_id', '33'); 
INSERT INTO `wp_postmeta` VALUES (100, 38, '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES (101, 38, '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES (102, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES (103, 38, '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES (104, 38, '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES (105, 38, '_menu_item_orphaned', '1385118454'); 
INSERT INTO `wp_postmeta` VALUES (106, 39, '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES (107, 39, '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES (108, 39, '_menu_item_object_id', '30'); 
INSERT INTO `wp_postmeta` VALUES (109, 39, '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES (110, 39, '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES (111, 39, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES (112, 39, '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES (113, 39, '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES (114, 39, '_menu_item_orphaned', '1385118454'); 
INSERT INTO `wp_postmeta` VALUES (115, 40, '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES (116, 40, '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES (117, 40, '_menu_item_object_id', '28'); 
INSERT INTO `wp_postmeta` VALUES (118, 40, '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES (119, 40, '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES (120, 40, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES (121, 40, '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES (122, 40, '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES (123, 40, '_menu_item_orphaned', '1385118455'); 
INSERT INTO `wp_postmeta` VALUES (124, 41, '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES (125, 41, '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES (126, 41, '_menu_item_object_id', '26'); 
INSERT INTO `wp_postmeta` VALUES (127, 41, '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES (128, 41, '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES (129, 41, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES (130, 41, '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES (131, 41, '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES (132, 41, '_menu_item_orphaned', '1385118455'); 
INSERT INTO `wp_postmeta` VALUES (133, 42, '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES (134, 42, '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES (135, 42, '_menu_item_object_id', '35'); 
INSERT INTO `wp_postmeta` VALUES (136, 42, '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES (137, 42, '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES (138, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES (139, 42, '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES (140, 42, '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES (142, 43, '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES (143, 43, '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES (144, 43, '_menu_item_object_id', '33'); 
INSERT INTO `wp_postmeta` VALUES (145, 43, '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES (146, 43, '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES (147, 43, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES (148, 43, '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES (149, 43, '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES (151, 44, '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES (152, 44, '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES (153, 44, '_menu_item_object_id', '30'); 
INSERT INTO `wp_postmeta` VALUES (154, 44, '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES (155, 44, '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES (156, 44, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES (157, 44, '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES (158, 44, '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES (160, 45, '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES (161, 45, '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES (162, 45, '_menu_item_object_id', '28'); 
INSERT INTO `wp_postmeta` VALUES (163, 45, '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES (164, 45, '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES (165, 45, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES (166, 45, '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES (167, 45, '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES (169, 46, '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES (170, 46, '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES (171, 46, '_menu_item_object_id', '26'); 
INSERT INTO `wp_postmeta` VALUES (172, 46, '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES (173, 46, '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES (174, 46, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES (175, 46, '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES (176, 46, '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES (177, 47, '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES (178, 47, '_edit_lock', '1385119893:1'); 
INSERT INTO `wp_postmeta` VALUES (179, 47, '_wp_trash_meta_status', 'publish'); 
INSERT INTO `wp_postmeta` VALUES (180, 47, '_wp_trash_meta_time', '1385119904'); 
INSERT INTO `wp_postmeta` VALUES (181, 54, '_edit_lock', '1385385472:1'); 
INSERT INTO `wp_postmeta` VALUES (182, 54, '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES (183, 54, '_wp_page_template', 'models.php'); 
INSERT INTO `wp_postmeta` VALUES (184, 56, '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES (185, 56, '_wp_page_template', 'services.php'); 
INSERT INTO `wp_postmeta` VALUES (186, 56, '_edit_lock', '1385388171:1'); 
INSERT INTO `wp_postmeta` VALUES (187, 58, '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES (188, 58, '_edit_lock', '1385388312:1'); 
INSERT INTO `wp_postmeta` VALUES (189, 58, '_wp_page_template', 'service_type.php'); 
INSERT INTO `wp_postmeta` VALUES (190, 71, '_form', '<ul id="contact">\n<li><span class="text">Votre nom</span><span class="required">(*)</span> [text* your-name]</li>\n \n<li><span class="text">Votre Mail</span><span class="required">(*)</span>[email* your-email] </li>\n \n<li><span class="text">Sujet</span>[text your-subject] </li>\n \n<li id="message"><span class="text">Votre message</span>[textarea your-message] </li>\n \n<li id="submit">[submit "Envoyer"]</li>\n</ul>'); 
INSERT INTO `wp_postmeta` VALUES (191, 71, '_mail', 'a:7:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:199:"De : [your-name] <[your-email]>\nSujet : [your-subject]\n\nCorps du message :\n[your-message]\n\n--\nCet email a été envoyé via le formulaire de contact le Save My Smartphone (http://localhost/wordpress)";s:9:"recipient";s:17:"antoninab@free.fr";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}'); 
INSERT INTO `wp_postmeta` VALUES (192, 71, '_mail_2', 'a:8:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:143:"Corps du message :\n[your-message]\n\n--\nCet email a été envoyé via le formulaire de contact le Save My Smartphone (http://localhost/wordpress)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}'); 
INSERT INTO `wp_postmeta` VALUES (193, 71, '_messages', 'a:21:{s:12:"mail_sent_ok";s:42:"Votre message a bien été envoyé. Merci.";s:12:"mail_sent_ng";s:116:"Erreur lors de l\'envoi du message. Veuillez réessayer plus tard ou contacter l\'administrateur d\'une autre manière.";s:16:"validation_error";s:76:"Erreur de validation. Veuillez vérifier les champs et soumettre à nouveau.";s:4:"spam";s:116:"Erreur lors de l\'envoi du message. Veuillez réessayer plus tard ou contacter l\'administrateur d\'une autre manière.";s:12:"accept_terms";s:61:"Merci de bien vouloir accepter les conditions pour continuer.";s:16:"invalid_required";s:38:"Veuillez remplir le champ obligatoire.";s:17:"captcha_not_match";s:28:"Le code entre est incorrect.";s:12:"invalid_date";s:34:"Le format de date semble invalide.";s:14:"date_too_early";s:25:"Cette date est trop tôt.";s:13:"date_too_late";s:25:"Cette date est trop tard.";s:13:"upload_failed";s:39:"Impossible de télécharger le fichier.";s:24:"upload_file_type_invalid";s:39:"Ce type de fichier n\'est pas autorisé.";s:21:"upload_file_too_large";s:31:"Ce fichier est trop volumineux.";s:23:"upload_failed_php_error";s:64:"Impossible de télécharger le fichier. Une erreur est survenue.";s:14:"invalid_number";s:37:"Le format numérique semble invalide.";s:16:"number_too_small";s:25:"Ce nombre est trop petit.";s:16:"number_too_large";s:25:"Ce nombre est trop grand.";s:23:"quiz_answer_not_correct";s:30:"Votre réponse est incorrecte.";s:13:"invalid_email";s:32:"L\'adresse email semble invalide.";s:11:"invalid_url";s:22:"L\'URL semble invalide.";s:11:"invalid_tel";s:42:"Le numéro de téléphone semble invalide.";}'); 
INSERT INTO `wp_postmeta` VALUES (194, 71, '_additional_settings', ''); 
INSERT INTO `wp_postmeta` VALUES (195, 71, '_locale', 'fr_FR'); 
INSERT INTO `wp_postmeta` VALUES (196, 74, '_yoast_wpseo_linkdex', '0'); 
INSERT INTO `wp_postmeta` VALUES (197, 74, '_edit_lock', '1385482404:1'); 
INSERT INTO `wp_postmeta` VALUES (198, 74, '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES (199, 74, '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES (200, 74, '_yoast_wpseo_focuskw', ''); 
INSERT INTO `wp_postmeta` VALUES (201, 74, '_yoast_wpseo_title', ''); 
INSERT INTO `wp_postmeta` VALUES (202, 74, '_yoast_wpseo_metadesc', ''); 
INSERT INTO `wp_postmeta` VALUES (203, 74, '_yoast_wpseo_meta-robots-noindex', '0'); 
INSERT INTO `wp_postmeta` VALUES (204, 74, '_yoast_wpseo_meta-robots-nofollow', '0'); 
INSERT INTO `wp_postmeta` VALUES (205, 74, '_yoast_wpseo_meta-robots-adv', 'none'); 
INSERT INTO `wp_postmeta` VALUES (206, 74, '_yoast_wpseo_sitemap-include', '-'); 
INSERT INTO `wp_postmeta` VALUES (207, 74, '_yoast_wpseo_sitemap-prio', '-'); 
INSERT INTO `wp_postmeta` VALUES (208, 74, '_yoast_wpseo_sitemap-html-include', '-'); 
INSERT INTO `wp_postmeta` VALUES (209, 74, '_yoast_wpseo_canonical', ''); 
INSERT INTO `wp_postmeta` VALUES (210, 74, '_yoast_wpseo_redirect', ''); 
INSERT INTO `wp_postmeta` VALUES (211, 74, '_yoast_wpseo_opengraph-description', ''); 
INSERT INTO `wp_postmeta` VALUES (212, 74, '_yoast_wpseo_opengraph-image', ''); 
INSERT INTO `wp_postmeta` VALUES (213, 74, '_yoast_wpseo_google-plus-description', ''); 
INSERT INTO `wp_postmeta` VALUES (214, 80, '_yoast_wpseo_linkdex', '0'); 
INSERT INTO `wp_postmeta` VALUES (215, 80, '_edit_lock', '1385482638:1'); 
INSERT INTO `wp_postmeta` VALUES (216, 80, '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES (217, 80, '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES (218, 80, '_yoast_wpseo_focuskw', ''); 
INSERT INTO `wp_postmeta` VALUES (219, 80, '_yoast_wpseo_title', ''); 
INSERT INTO `wp_postmeta` VALUES (220, 80, '_yoast_wpseo_metadesc', ''); 
INSERT INTO `wp_postmeta` VALUES (221, 80, '_yoast_wpseo_meta-robots-noindex', '0'); 
INSERT INTO `wp_postmeta` VALUES (222, 80, '_yoast_wpseo_meta-robots-nofollow', '0'); 
INSERT INTO `wp_postmeta` VALUES (223, 80, '_yoast_wpseo_meta-robots-adv', 'none'); 
INSERT INTO `wp_postmeta` VALUES (224, 80, '_yoast_wpseo_sitemap-include', '-'); 
INSERT INTO `wp_postmeta` VALUES (225, 80, '_yoast_wpseo_sitemap-prio', '-'); 
INSERT INTO `wp_postmeta` VALUES (226, 80, '_yoast_wpseo_sitemap-html-include', '-'); 
INSERT INTO `wp_postmeta` VALUES (227, 80, '_yoast_wpseo_canonical', ''); 
INSERT INTO `wp_postmeta` VALUES (228, 80, '_yoast_wpseo_redirect', ''); 
INSERT INTO `wp_postmeta` VALUES (229, 80, '_yoast_wpseo_opengraph-description', ''); 
INSERT INTO `wp_postmeta` VALUES (230, 80, '_yoast_wpseo_opengraph-image', ''); 
INSERT INTO `wp_postmeta` VALUES (231, 80, '_yoast_wpseo_google-plus-description', ''); 
INSERT INTO `wp_postmeta` VALUES (232, 82, '_yoast_wpseo_linkdex', '0'); 
INSERT INTO `wp_postmeta` VALUES (233, 82, '_edit_lock', '1385482722:1'); 
INSERT INTO `wp_postmeta` VALUES (234, 82, '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES (235, 82, '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES (236, 82, '_yoast_wpseo_focuskw', ''); 
INSERT INTO `wp_postmeta` VALUES (237, 82, '_yoast_wpseo_title', ''); 
INSERT INTO `wp_postmeta` VALUES (238, 82, '_yoast_wpseo_metadesc', ''); 
INSERT INTO `wp_postmeta` VALUES (239, 82, '_yoast_wpseo_meta-robots-noindex', '0'); 
INSERT INTO `wp_postmeta` VALUES (240, 82, '_yoast_wpseo_meta-robots-nofollow', '0'); 
INSERT INTO `wp_postmeta` VALUES (241, 82, '_yoast_wpseo_meta-robots-adv', 'none'); 
INSERT INTO `wp_postmeta` VALUES (242, 82, '_yoast_wpseo_sitemap-include', '-'); 
INSERT INTO `wp_postmeta` VALUES (243, 82, '_yoast_wpseo_sitemap-prio', '-'); 
INSERT INTO `wp_postmeta` VALUES (244, 82, '_yoast_wpseo_sitemap-html-include', '-'); 
INSERT INTO `wp_postmeta` VALUES (245, 82, '_yoast_wpseo_canonical', ''); 
INSERT INTO `wp_postmeta` VALUES (246, 82, '_yoast_wpseo_redirect', ''); 
INSERT INTO `wp_postmeta` VALUES (247, 82, '_yoast_wpseo_opengraph-description', ''); 
INSERT INTO `wp_postmeta` VALUES (248, 82, '_yoast_wpseo_opengraph-image', ''); 
INSERT INTO `wp_postmeta` VALUES (249, 82, '_yoast_wpseo_google-plus-description', ''); 
INSERT INTO `wp_postmeta` VALUES (250, 85, '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES (251, 85, '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES (252, 85, '_menu_item_object_id', '82'); 
INSERT INTO `wp_postmeta` VALUES (253, 85, '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES (254, 85, '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES (255, 85, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES (256, 85, '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES (257, 85, '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES (259, 86, '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES (260, 86, '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES (261, 86, '_menu_item_object_id', '80'); 
INSERT INTO `wp_postmeta` VALUES (262, 86, '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES (263, 86, '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES (264, 86, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES (265, 86, '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES (266, 86, '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES (268, 87, '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES (269, 87, '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES (270, 87, '_menu_item_object_id', '74'); 
INSERT INTO `wp_postmeta` VALUES (271, 87, '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES (272, 87, '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES (273, 87, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES (274, 87, '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES (275, 87, '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES (276, 88, '_menu_item_type', 'custom'); 
INSERT INTO `wp_postmeta` VALUES (277, 88, '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES (278, 88, '_menu_item_object_id', '88'); 
INSERT INTO `wp_postmeta` VALUES (279, 88, '_menu_item_object', 'custom'); 
INSERT INTO `wp_postmeta` VALUES (280, 88, '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES (281, 88, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES (282, 88, '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES (283, 88, '_menu_item_url', 'http://www.savemysmartphone.fr/presse.pdf');
#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_posts`
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2013-11-15 13:54:16', '2013-11-15 13:54:16', 'Bienvenue dans WordPress. Ceci est votre premier article. Modifiez-le ou supprimez-le, puis lancez-vous&nbsp;!', 'Bonjour tout le monde&nbsp;!', '', 'publish', 'open', 'open', '', 'bonjour-tout-le-monde', '', '', '2013-11-15 13:54:16', '2013-11-15 13:54:16', '', 0, 'http://localhost/wordpress/?p=1', 0, 'post', '', 0); 
INSERT INTO `wp_posts` VALUES (4, 1, '2013-11-19 12:37:40', '0000-00-00 00:00:00', '', 'Logo Upload', '', 'draft', 'closed', 'closed', '', 'of-logo_upload', '', '', '2013-11-19 12:37:40', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/?post_type=optionsframework&p=4', 0, 'optionsframework', '', 0); 
INSERT INTO `wp_posts` VALUES (18, 1, '2013-11-19 12:46:05', '2013-11-19 11:46:05', '', 'logo', '', 'inherit', 'open', 'open', '', 'logo', '', '', '2013-11-19 12:46:05', '2013-11-19 11:46:05', '', 4, 'http://localhost/wordpress/wp-content/uploads/2013/11/logo.png', 0, 'attachment', 'image/png', 0); 
INSERT INTO `wp_posts` VALUES (19, 1, '2013-11-19 12:46:28', '2013-11-19 11:46:28', '', 'logo', '', 'inherit', 'open', 'open', '', 'logo-2', '', '', '2013-11-19 12:46:28', '2013-11-19 11:46:28', '', 4, 'http://localhost/wordpress/wp-content/uploads/2013/11/logo1.png', 0, 'attachment', 'image/png', 0); 
INSERT INTO `wp_posts` VALUES (20, 1, '2013-11-19 12:47:21', '2013-11-19 11:47:21', '', 'logo', '', 'inherit', 'open', 'open', '', 'logo-3', '', '', '2013-11-19 12:47:21', '2013-11-19 11:47:21', '', 4, 'http://localhost/wordpress/wp-content/uploads/2013/11/logo2.png', 0, 'attachment', 'image/png', 0); 
INSERT INTO `wp_posts` VALUES (21, 1, '2013-11-19 12:47:48', '2013-11-19 11:47:48', '', 'logo', '', 'inherit', 'open', 'open', '', 'logo-4', '', '', '2013-11-19 12:47:48', '2013-11-19 11:47:48', '', 4, 'http://localhost/wordpress/wp-content/uploads/2013/11/logo3.png', 0, 'attachment', 'image/png', 0); 
INSERT INTO `wp_posts` VALUES (22, 1, '2013-11-19 12:49:39', '2013-11-19 11:49:39', '', 'logo2', '', 'inherit', 'open', 'open', '', 'logo2', '', '', '2013-11-19 12:49:39', '2013-11-19 11:49:39', '', 4, 'http://localhost/wordpress/wp-content/uploads/2013/11/logo21.png', 0, 'attachment', 'image/png', 0); 
INSERT INTO `wp_posts` VALUES (23, 1, '2013-11-19 12:51:18', '2013-11-19 11:51:18', '', 'logo2', '', 'inherit', 'open', 'open', '', 'logo2-2', '', '', '2013-11-19 12:51:18', '2013-11-19 11:51:18', '', 4, 'http://localhost/wordpress/wp-content/uploads/2013/11/logo22.png', 0, 'attachment', 'image/png', 0); 
INSERT INTO `wp_posts` VALUES (26, 1, '2013-11-22 12:04:10', '2013-11-22 11:04:10', 'Les engagements de Save my Smartphone\r\n\r\nRapides\r\nNous réparons vos appareils rapidement. La majorité des réparations ne prennent que 30 minutes. Vous pouvez patienter en point de vente pendant que l’on s’occupe de vos joujoux\r\n\r\n&nbsp;\r\n\r\nMoins chers\r\nRéparer votre smartphone chez Save my Smartphone vous coutera en moyenne 2 fois moins cher que chez votre constructeur. Nous vous garantissons des prix attractifs\r\nGarantie\r\nNous garantissons nos réparations pendant 1 an. Même si votre smartphone n’est plus garanti par le constructeur, nous garantissions les pièces changées et la main d’œuvre pendant 1 an. Pas besoin de revenir avec le ticket, vous êtes dans le fichier client.\r\n\r\n&nbsp;\r\n\r\nDisponibles\r\nVous pouvez vous rendre dans notre boutique sans rendez vous. Nous sommes joignables par téléphone ou par e-mail pour vous donner des conseils ou répondre à toutes vos questions.\r\n\r\n&nbsp;\r\n\r\nResponsables\r\nLes sauveteurs sont soucieux de l’environnement. Nous nous engageons à recycler les pièces défectueuses et les batteries pour la protection de notre planète. Vous pouvez également déposer vos appareils HS dans nos points de vente on s’occupera du recyclage !\r\n\r\n&nbsp;\r\n\r\nComment nous faire parvenir vos appareils ?\r\n3 choix s’offrent a vous :\r\n\r\n&nbsp;', 'A propos', '', 'publish', 'open', 'open', '', 'a-propos', '', '', '2013-11-25 17:02:42', '2013-11-25 16:02:42', '', 0, 'http://localhost/wordpress/?page_id=26', 0, 'page', '', 0); 
INSERT INTO `wp_posts` VALUES (27, 1, '2013-11-22 12:04:10', '2013-11-22 11:04:10', 'page à propos', 'A propos', '', 'inherit', 'open', 'open', '', '26-revision-v1', '', '', '2013-11-22 12:04:10', '2013-11-22 11:04:10', '', 26, 'http://localhost/wordpress/26-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (28, 1, '2013-11-22 12:04:44', '2013-11-22 11:04:44', '', 'Tarifs', '', 'publish', 'open', 'open', '', 'tarifs', '', '', '2013-11-25 14:14:37', '2013-11-25 13:14:37', '', 0, 'http://localhost/wordpress/?page_id=28', 0, 'page', '', 0); 
INSERT INTO `wp_posts` VALUES (29, 1, '2013-11-22 12:04:44', '2013-11-22 11:04:44', 'page tarifs', 'Tarifs', '', 'inherit', 'open', 'open', '', '28-revision-v1', '', '', '2013-11-22 12:04:44', '2013-11-22 11:04:44', '', 28, 'http://localhost/wordpress/28-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (30, 1, '2013-11-22 12:05:11', '2013-11-22 11:05:11', '<p style="text-align: center;"><h2>Une équipe jeune et dynamique à votre écoute.</h2></p>\r\n&nbsp;\r\n\r\n&nbsp;', 'L\'équipe', '', 'publish', 'open', 'open', '', 'lequipe', '', '', '2013-11-25 15:56:02', '2013-11-25 14:56:02', '', 0, 'http://localhost/wordpress/?page_id=30', 0, 'page', '', 0); 
INSERT INTO `wp_posts` VALUES (31, 1, '2013-11-22 12:05:11', '2013-11-22 11:05:11', 'page l\'équipe', 'L\'équipe', '', 'inherit', 'open', 'open', '', '30-revision-v1', '', '', '2013-11-22 12:05:11', '2013-11-22 11:05:11', '', 30, 'http://localhost/wordpress/30-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (32, 1, '2013-11-22 12:05:18', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2013-11-22 12:05:18', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/?page_id=32', 0, 'page', '', 0); 
INSERT INTO `wp_posts` VALUES (33, 1, '2013-11-22 12:05:31', '2013-11-22 11:05:31', '', 'Médias', '', 'publish', 'open', 'open', '', 'medias-2', '', '', '2013-11-26 14:03:34', '2013-11-26 13:03:34', '', 0, 'http://localhost/wordpress/?page_id=33', 0, 'page', '', 0); 
INSERT INTO `wp_posts` VALUES (34, 1, '2013-11-22 12:05:31', '2013-11-22 11:05:31', 'page médias', 'Médias', '', 'inherit', 'open', 'open', '', '33-revision-v1', '', '', '2013-11-22 12:05:31', '2013-11-22 11:05:31', '', 33, 'http://localhost/wordpress/33-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (35, 1, '2013-11-22 12:06:49', '2013-11-22 11:06:49', '[contact-form-7 id="71" title="Formulaire de contact 1"]', 'Contact', '', 'publish', 'open', 'open', '', 'contact', '', '', '2013-11-26 14:52:43', '2013-11-26 13:52:43', '', 0, 'http://localhost/wordpress/?page_id=35', 0, 'page', '', 0); 
INSERT INTO `wp_posts` VALUES (36, 1, '2013-11-22 12:06:49', '2013-11-22 11:06:49', 'page contact', 'Contact', '', 'inherit', 'open', 'open', '', '35-revision-v1', '', '', '2013-11-22 12:06:49', '2013-11-22 11:06:49', '', 35, 'http://localhost/wordpress/35-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (37, 1, '2013-11-22 12:07:32', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-22 12:07:32', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/?p=37', 1, 'nav_menu_item', '', 0); 
INSERT INTO `wp_posts` VALUES (38, 1, '2013-11-22 12:07:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-22 12:07:33', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/?p=38', 1, 'nav_menu_item', '', 0); 
INSERT INTO `wp_posts` VALUES (39, 1, '2013-11-22 12:07:34', '0000-00-00 00:00:00', '', 'L\'équipe', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-22 12:07:34', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/?p=39', 1, 'nav_menu_item', '', 0); 
INSERT INTO `wp_posts` VALUES (40, 1, '2013-11-22 12:07:34', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-22 12:07:34', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/?p=40', 1, 'nav_menu_item', '', 0); 
INSERT INTO `wp_posts` VALUES (41, 1, '2013-11-22 12:07:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-22 12:07:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/?p=41', 1, 'nav_menu_item', '', 0); 
INSERT INTO `wp_posts` VALUES (42, 1, '2013-11-22 12:09:19', '2013-11-22 11:09:19', ' ', '', '', 'publish', 'open', 'open', '', '42', '', '', '2013-11-26 17:20:03', '2013-11-26 16:20:03', '', 0, 'http://localhost/wordpress/?p=42', 5, 'nav_menu_item', '', 0); 
INSERT INTO `wp_posts` VALUES (43, 1, '2013-11-22 12:09:19', '2013-11-22 11:09:19', ' ', '', '', 'publish', 'open', 'open', '', '43', '', '', '2013-11-26 17:20:03', '2013-11-26 16:20:03', '', 0, 'http://localhost/wordpress/?p=43', 4, 'nav_menu_item', '', 0); 
INSERT INTO `wp_posts` VALUES (44, 1, '2013-11-22 12:09:19', '2013-11-22 11:09:19', '', 'L\'équipe', '', 'publish', 'open', 'open', '', 'lequipe', '', '', '2013-11-26 17:20:03', '2013-11-26 16:20:03', '', 0, 'http://localhost/wordpress/?p=44', 3, 'nav_menu_item', '', 0); 
INSERT INTO `wp_posts` VALUES (45, 1, '2013-11-22 12:09:18', '2013-11-22 11:09:18', ' ', '', '', 'publish', 'open', 'open', '', '45', '', '', '2013-11-26 17:20:02', '2013-11-26 16:20:02', '', 0, 'http://localhost/wordpress/?p=45', 2, 'nav_menu_item', '', 0); 
INSERT INTO `wp_posts` VALUES (46, 1, '2013-11-22 12:09:18', '2013-11-22 11:09:18', ' ', '', '', 'publish', 'open', 'open', '', '46', '', '', '2013-11-26 17:20:02', '2013-11-26 16:20:02', '', 0, 'http://localhost/wordpress/?p=46', 1, 'nav_menu_item', '', 0); 
INSERT INTO `wp_posts` VALUES (47, 1, '2013-11-22 12:31:12', '2013-11-22 11:31:12', 'test projet', 'test projet', 'test extrait', 'trash', 'open', 'open', '', 'test-projet', '', '', '2013-11-22 12:31:44', '2013-11-22 11:31:44', '', 0, 'http://localhost/wordpress/?post_type=project&#038;p=47', 0, 'project', '', 0); 
INSERT INTO `wp_posts` VALUES (48, 1, '2013-11-22 12:32:22', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2013-11-22 12:32:22', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/?p=48', 0, 'post', '', 0); 
INSERT INTO `wp_posts` VALUES (49, 1, '2013-11-22 12:32:38', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2013-11-22 12:32:38', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/?p=49', 0, 'post', '', 0); 
INSERT INTO `wp_posts` VALUES (52, 1, '2013-11-22 15:21:47', '2013-11-22 14:21:47', '', 'Tarifs', '', 'inherit', 'open', 'open', '', '28-revision-v1', '', '', '2013-11-22 15:21:47', '2013-11-22 14:21:47', '', 28, 'http://localhost/wordpress/28-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (53, 1, '2013-11-25 11:24:26', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2013-11-25 11:24:26', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/?p=53', 0, 'post', '', 0); 
INSERT INTO `wp_posts` VALUES (54, 1, '2013-11-25 11:27:31', '2013-11-25 10:27:31', '', 'Models', '', 'publish', 'open', 'open', '', 'models', '', '', '2013-11-25 12:44:08', '2013-11-25 11:44:08', '', 0, 'http://localhost/wordpress/?page_id=54', 0, 'page', '', 0); 
INSERT INTO `wp_posts` VALUES (55, 1, '2013-11-25 11:27:31', '2013-11-25 10:27:31', '', 'Models', '', 'inherit', 'open', 'open', '', '54-revision-v1', '', '', '2013-11-25 11:27:31', '2013-11-25 10:27:31', '', 54, 'http://localhost/wordpress/54-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (56, 1, '2013-11-25 11:28:28', '2013-11-25 10:28:28', '', 'Services', '', 'publish', 'open', 'open', '', 'services', '', '', '2013-11-25 15:04:43', '2013-11-25 14:04:43', '', 0, 'http://localhost/wordpress/?page_id=56', 0, 'page', '', 0); 
INSERT INTO `wp_posts` VALUES (57, 1, '2013-11-25 11:28:28', '2013-11-25 10:28:28', '', 'Services', '', 'inherit', 'open', 'open', '', '56-revision-v1', '', '', '2013-11-25 11:28:28', '2013-11-25 10:28:28', '', 56, 'http://localhost/wordpress/56-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (58, 1, '2013-11-25 11:29:03', '2013-11-25 10:29:03', '', 'Service_type', '', 'publish', 'open', 'open', '', 'service_type', '', '', '2013-11-25 15:04:56', '2013-11-25 14:04:56', '', 0, 'http://localhost/wordpress/?page_id=58', 0, 'page', '', 0); 
INSERT INTO `wp_posts` VALUES (59, 1, '2013-11-25 11:29:03', '2013-11-25 10:29:03', '', 'Service_type', '', 'inherit', 'open', 'open', '', '58-revision-v1', '', '', '2013-11-25 11:29:03', '2013-11-25 10:29:03', '', 58, 'http://localhost/wordpress/58-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (60, 1, '2013-11-25 15:13:30', '2013-11-25 14:13:30', '', 'L\'équipe', '', 'inherit', 'open', 'open', '', '30-revision-v1', '', '', '2013-11-25 15:13:30', '2013-11-25 14:13:30', '', 30, 'http://localhost/wordpress/30-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (61, 1, '2013-11-25 15:44:17', '2013-11-25 14:44:17', 'jfhdkfhdfkjqhsdlkjqhsdfkjsqhfqkjdhfjklqshfdfqsdf', 'L\'équipe', '', 'inherit', 'open', 'open', '', '30-revision-v1', '', '', '2013-11-25 15:44:17', '2013-11-25 14:44:17', '', 30, 'http://localhost/wordpress/30-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (62, 1, '2013-11-25 15:54:29', '2013-11-25 14:54:29', 'Une équ', 'L\'équipe', '', 'inherit', 'open', 'open', '', '30-autosave-v1', '', '', '2013-11-25 15:54:29', '2013-11-25 14:54:29', '', 30, 'http://localhost/wordpress/30-autosave-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (63, 1, '2013-11-25 15:55:03', '2013-11-25 14:55:03', '<p style="text-align: center;">Une équipe jeune et dynamique à votre écoute.</p>\r\n&nbsp;\r\n\r\n&nbsp;', 'L\'équipe', '', 'inherit', 'open', 'open', '', '30-revision-v1', '', '', '2013-11-25 15:55:03', '2013-11-25 14:55:03', '', 30, 'http://localhost/wordpress/30-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (64, 1, '2013-11-25 15:56:02', '2013-11-25 14:56:02', '<p style="text-align: center;"><h2>Une équipe jeune et dynamique à votre écoute.</h2></p>\r\n&nbsp;\r\n\r\n&nbsp;', 'L\'équipe', '', 'inherit', 'open', 'open', '', '30-revision-v1', '', '', '2013-11-25 15:56:02', '2013-11-25 14:56:02', '', 30, 'http://localhost/wordpress/30-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (65, 1, '2013-11-25 16:34:00', '2013-11-25 15:34:00', 'Les engagements de Save my Smartphone\r\n\r\nRapides\r\nNous réparons vos appareils rapidement. La majorité des réparations ne prennent que 30 minutes. Vous pouvez patienter en point de vente pendant que l’on s’occupe de vos joujoux\r\n\r\nMoins chers \r\nRéparer votre smartphone chez Save my Smartphone vous coutera en moyenne 2 fois moins cher que chez votre constructeur. Nous vous garantissons des prix attractifs\r\nGarantie\r\nNous garantissons nos réparations pendant 1 an. Même si votre smartphone n’est plus garanti par le constructeur, nous garantissions les pièces changées et la main d’œuvre pendant 1 an. Pas besoin de revenir avec le ticket, vous êtes dans le fichier client.\r\n\r\nDisponibles\r\nVous pouvez vous rendre dans notre boutique sans rendez vous. Nous sommes joignables par téléphone ou par e-mail pour vous donner des conseils ou répondre à toutes vos questions.\r\n\r\nResponsables\r\nLes sauveteurs sont soucieux de l’environnement. Nous nous engageons à recycler les pièces défectueuses et les batteries pour la protection de notre planète. Vous pouvez également déposer vos appareils  HS dans nos points de vente on s’occupera du recyclage !\r\n\r\nComment nous faire parvenir vos appareils ?\r\n3 choix s’offrent a vous :\r\n\r\nEn Boutique\r\n\r\nPar Courrier\r\n\r\nA Domicile\r\n', 'A propos', '', 'inherit', 'open', 'open', '', '26-revision-v1', '', '', '2013-11-25 16:34:00', '2013-11-25 15:34:00', '', 26, 'http://localhost/wordpress/26-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (66, 1, '2013-11-25 16:40:08', '2013-11-25 15:40:08', 'Les engagements de Save my Smartphone\n\nRapides\nNous réparons vos appareils rapidement. La majorité des réparations ne prennent que 30 minutes. Vous pouvez patienter en point de vente pendant que l’on s’occupe de vos joujoux\n\nMoins chers\nRéparer votre smartphone chez Save my Smartphone vous coutera en moyenne 2 fois moins cher que chez votre constructeur. Nous vous garantissons des prix attractifs\nGarantie\nNous garantissons nos réparations pendant 1 an. Même si votre smartphone n’est plus garanti par le constructeur, nous garantissions les pièces changées et la main d’œuvre pendant 1 an. Pas besoin de revenir avec le ticket, vous êtes dans le fichier client.\n\nDisponibles\nVous pouvez vous rendre dans notre boutique sans rendez vous. Nous sommes joignables par téléphone ou par e-mail pour vous donner des conseils ou répondre à toutes vos questions.\n\nResponsables\nLes sauveteurs sont soucieux de l’environnement. Nous nous engageons à recycler les pièces défectueuses et les batteries pour la protection de notre planète. Vous pouvez également déposer vos appareils HS dans nos points de vente on s’occupera du recyclage !\n\nComment nous faire parvenir vos appareils ?\n3 choix s’offrent a vous :\n\nEn Boutique\n\nPar Courrier\n\nA Domicile', 'A propos', '', 'inherit', 'open', 'open', '', '26-autosave-v1', '', '', '2013-11-25 16:40:08', '2013-11-25 15:40:08', '', 26, 'http://localhost/wordpress/26-autosave-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (67, 1, '2013-11-25 16:40:17', '2013-11-25 15:40:17', 'Les engagements de Save my Smartphone\r\n\r\nRapides\r\nNous réparons vos appareils rapidement. La majorité des réparations ne prennent que 30 minutes. Vous pouvez patienter en point de vente pendant que l’on s’occupe de vos joujoux\r\n\r\n&nbsp;\r\n\r\nMoins chers\r\nRéparer votre smartphone chez Save my Smartphone vous coutera en moyenne 2 fois moins cher que chez votre constructeur. Nous vous garantissons des prix attractifs\r\nGarantie\r\nNous garantissons nos réparations pendant 1 an. Même si votre smartphone n’est plus garanti par le constructeur, nous garantissions les pièces changées et la main d’œuvre pendant 1 an. Pas besoin de revenir avec le ticket, vous êtes dans le fichier client.\r\n\r\n&nbsp;\r\n\r\nDisponibles\r\nVous pouvez vous rendre dans notre boutique sans rendez vous. Nous sommes joignables par téléphone ou par e-mail pour vous donner des conseils ou répondre à toutes vos questions.\r\n\r\n&nbsp;\r\n\r\nResponsables\r\nLes sauveteurs sont soucieux de l’environnement. Nous nous engageons à recycler les pièces défectueuses et les batteries pour la protection de notre planète. Vous pouvez également déposer vos appareils HS dans nos points de vente on s’occupera du recyclage !\r\n\r\n&nbsp;\r\n\r\nComment nous faire parvenir vos appareils ?\r\n3 choix s’offrent a vous :\r\n\r\n&nbsp;\r\n\r\nEn Boutique\r\n\r\nPar Courrier\r\n\r\nA Domicile', 'A propos', '', 'inherit', 'open', 'open', '', '26-revision-v1', '', '', '2013-11-25 16:40:17', '2013-11-25 15:40:17', '', 26, 'http://localhost/wordpress/26-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (68, 1, '2013-11-25 16:54:00', '2013-11-25 15:54:00', 'Les engagements de Save my Smartphone\r\n\r\nRapides\r\nNous réparons vos appareils rapidement. La majorité des réparations ne prennent que 30 minutes. Vous pouvez patienter en point de vente pendant que l’on s’occupe de vos joujoux\r\n\r\n&nbsp;\r\n\r\nMoins chers\r\nRéparer votre smartphone chez Save my Smartphone vous coutera en moyenne 2 fois moins cher que chez votre constructeur. Nous vous garantissons des prix attractifs\r\nGarantie\r\nNous garantissons nos réparations pendant 1 an. Même si votre smartphone n’est plus garanti par le constructeur, nous garantissions les pièces changées et la main d’œuvre pendant 1 an. Pas besoin de revenir avec le ticket, vous êtes dans le fichier client.\r\n\r\n&nbsp;\r\n\r\nDisponibles\r\nVous pouvez vous rendre dans notre boutique sans rendez vous. Nous sommes joignables par téléphone ou par e-mail pour vous donner des conseils ou répondre à toutes vos questions.\r\n\r\n&nbsp;\r\n\r\nResponsables\r\nLes sauveteurs sont soucieux de l’environnement. Nous nous engageons à recycler les pièces défectueuses et les batteries pour la protection de notre planète. Vous pouvez également déposer vos appareils HS dans nos points de vente on s’occupera du recyclage !\r\n\r\n&nbsp;\r\n\r\nComment nous faire parvenir vos appareils ?\r\n3 choix s’offrent a vous :\r\n\r\n&nbsp;', 'A propos', '', 'inherit', 'open', 'open', '', '26-revision-v1', '', '', '2013-11-25 16:54:00', '2013-11-25 15:54:00', '', 26, 'http://localhost/wordpress/26-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (69, 1, '2013-11-25 17:10:49', '2013-11-25 16:10:49', '', 'Contact', '', 'inherit', 'open', 'open', '', '35-revision-v1', '', '', '2013-11-25 17:10:49', '2013-11-25 16:10:49', '', 35, 'http://localhost/wordpress/35-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (70, 1, '2013-11-26 14:03:34', '2013-11-26 13:03:34', '', 'Médias', '', 'inherit', 'open', 'open', '', '33-revision-v1', '', '', '2013-11-26 14:03:34', '2013-11-26 13:03:34', '', 33, 'http://localhost/wordpress/33-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (71, 1, '2013-11-26 14:48:01', '2013-11-26 13:48:01', '<ul id="contact">\r\n<li><span class="text">Votre nom</span><span class="required">(*)</span> [text* your-name]</li>\r\n \r\n<li><span class="text">Votre Mail</span><span class="required">(*)</span>[email* your-email] </li>\r\n \r\n<li><span class="text">Sujet</span>[text your-subject] </li>\r\n \r\n<li id="message"><span class="text">Votre message</span>[textarea your-message] </li>\r\n \r\n<li id="submit">[submit "Envoyer"]</li>\r\n</ul>\n[your-subject]\n[your-name] <[your-email]>\nDe : [your-name] <[your-email]>\r\nSujet : [your-subject]\r\n\r\nCorps du message :\r\n[your-message]\r\n\r\n--\r\nCet email a été envoyé via le formulaire de contact le Save My Smartphone (http://localhost/wordpress)\nantoninab@free.fr\n\n\n\n\n[your-subject]\n[your-name] <[your-email]>\nCorps du message :\r\n[your-message]\r\n\r\n--\r\nCet email a été envoyé via le formulaire de contact le Save My Smartphone (http://localhost/wordpress)\n[your-email]\n\n\n\nVotre message a bien été envoyé. Merci.\nErreur lors de l\'envoi du message. Veuillez réessayer plus tard ou contacter l\'administrateur d\'une autre manière.\nErreur de validation. Veuillez vérifier les champs et soumettre à nouveau.\nErreur lors de l\'envoi du message. Veuillez réessayer plus tard ou contacter l\'administrateur d\'une autre manière.\nMerci de bien vouloir accepter les conditions pour continuer.\nVeuillez remplir le champ obligatoire.\nLe code entre est incorrect.\nLe format de date semble invalide.\nCette date est trop tôt.\nCette date est trop tard.\nImpossible de télécharger le fichier.\nCe type de fichier n\'est pas autorisé.\nCe fichier est trop volumineux.\nImpossible de télécharger le fichier. Une erreur est survenue.\nLe format numérique semble invalide.\nCe nombre est trop petit.\nCe nombre est trop grand.\nVotre réponse est incorrecte.\nL\'adresse email semble invalide.\nL\'URL semble invalide.\nLe numéro de téléphone semble invalide.', 'Formulaire de contact 1', '', 'publish', 'open', 'open', '', 'formulaire-de-contact-1', '', '', '2013-11-26 15:04:59', '2013-11-26 14:04:59', '', 0, 'http://localhost/wordpress/?post_type=wpcf7_contact_form&#038;p=71', 0, 'wpcf7_contact_form', '', 0); 
INSERT INTO `wp_posts` VALUES (72, 1, '2013-11-26 14:52:43', '2013-11-26 13:52:43', '[contact-form-7 id="71" title="Formulaire de contact 1"]', 'Contact', '', 'inherit', 'open', 'open', '', '35-revision-v1', '', '', '2013-11-26 14:52:43', '2013-11-26 13:52:43', '', 35, 'http://localhost/wordpress/35-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (73, 2, '2013-11-26 16:41:49', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2013-11-26 16:41:49', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/?p=73', 0, 'post', '', 0); 
INSERT INTO `wp_posts` VALUES (74, 1, '2013-11-26 17:02:26', '2013-11-26 16:02:26', '<strong>Préambule </strong>\r\n\r\n&nbsp;\r\n\r\nLes présentes conditions générales de ventes sont conclues d\'une part par la société Save my Smartphone dont le siège social se trouve au 23 rue Duret, 75116 Paris immatriculée au registre du commerce et des sociétés sous le numéro 791 070 907 et d\'autre part, par toute personnes physique ou morale souhaitant procéder à l\'achat de nos prestations dénommée ci-après " l\'acheteur ", "le consommateur".\r\n\r\n&nbsp;\r\n\r\n<strong>Article 1</strong>\r\n\r\n&nbsp;\r\n\r\nLes conditions générales contenues dans ce document régissent les relations contractuelles entre Save my Smartphone et son client dans le cadre d\'un service de réparation. Les deux parties les acceptent sans réserve. Ces conditions prévaudront sur toutes autres conditions. Ce contrat est soumis au droit français.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 2</strong>\r\n\r\n&nbsp;\r\n\r\nLors du dépôt de votre matériel la sauvegarde de vos données doit avoir été faite. Save my Smartphone ne saurait être tenue responsable de la perte éventuelle ou de la destruction des données stockées dans votre appareil. L\'Acheteur reconnaît être informé que l\'intervention de Save my Smartphone sur son matériel, peut entraîner une rupture de garantie du constructeur et/ou du distributeur.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 3</strong>\r\n\r\n&nbsp;\r\n\r\nNos réparations sont garanties 1 an. La garantie contractuelle commerciale couvre la ou les pièces détachées changées lors de la réparation. Il n\'y aura aucune garantie de la part du Vendeur en cas de modification du matériel, accident ou choc, détérioration volontaire, dégâts causés par l\'eau, le feu, l\'humidité, la foudre. Aucune garantie ne sera applicable en cas d\'utilisation anormale.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 4</strong>\r\n\r\n&nbsp;\r\n\r\nLe délai des réparations est établi à titre indicatif par le technicien lors de l\'analyse de l\'appareil. Chaque machine est traitée par ordre d\'arrivée. De ce fait, aucune réclamation ne pourra être effectuée en cas de retard du service technique. Si Save my Smartphone n\'a pas effectué la réparation dans un délai de 15 jours maximum et que l\'Acheteur souhaite récupérer son appareil, aucun frais de devis ne sera facturé.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 5</strong>\r\n\r\n&nbsp;\r\n\r\nSave my Smartphone indique à sa clientèle qu\'un droit de garde sera appliqué pour tout téléphone réparé ou diagnostiqué de 19 euros par mois\r\n\r\n&nbsp;\r\n\r\n<strong>Article 6</strong>\r\n\r\n&nbsp;\r\n\r\nLes prix fourni par l\'entreprise sont des prix TTC en euro. Save my Smartphone se réserve de modifier ses prix à tout moment. Certains appareils pris en charge ne sont pas réparables. Ils nécessitent cependant un temps de travail pour établir un diagnostic et statuer sur l\'état du téléphone. Un forfait de 19 euros, sera donc facturé pour diagnostiquer le téléphone. Forfait que le client ne paiera que dans 2 cas. Si le client n\'accepte pas le devis qui lui a été proposé par Save my Smartphone ou si le téléphone est jugé irréparable.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 7</strong>\r\n\r\n&nbsp;\r\n\r\nEn cas de retour sous garantie, pour une réparation effectuée par nos soins, la main d\'œuvre sera prise en charge par Save my Smartphone pendant une durée d\'un an à compter de la date de sortie de notre boutique, la facture faisant office de justifi¬catif de sortie. Passé ce délai, la main d\'œuvre sera à la charge de l\'Acheteur. En ce qui concerne la pièce utilisée pour la réparation, la durée de la garantie d\'une pièce d\'occasion est de un an, à compter de la date de facturation.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 8</strong>\r\n\r\n&nbsp;\r\n\r\nDans le cadre des prestations de service effectuées, l\'Acheteur reste responsable des données présentes sur son appareil. La responsabilité de Save my Smartphone ne peut en aucun cas être engagée. Par ailleurs, en cas de perte de données, l\'Acheteur ne pourra réclamer des dommages et intérêts relatifs à une quelconque valeur des données enregistrées. Save my Smartphone ne sera pas tenu responsable des éventuels dommages occasionnés sur les données, qu\'ils soient directs ou indirects, suite à l\'intervention des techniciens.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 9</strong>\r\n\r\n&nbsp;\r\n\r\nDans certains cas, les chocs importants ayant entrainés la casse de l\'appareil sont tels que la seule ouverture du téléphone peut générer une panne qui peut être différente de la raison de prise en charge initiale. Save my Smartphone ne peut en cas être tenu pour responsable d\'avoir causé la panne. L\'ouverture d\'un appareil est à la responsabilité du client.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 10</strong>\r\n\r\n&nbsp;\r\n\r\nLa Loi française est applicable à tout litige avec l\'Acheteur.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 11</strong>\r\n\r\n&nbsp;\r\n\r\nLe tribunal de Paris est seul compétent à tout litige avec l\'Acheteur.', 'Conditions générales', '', 'publish', 'open', 'open', '', 'conditions-generales', '', '', '2013-11-26 17:12:31', '2013-11-26 16:12:31', '', 0, 'http://localhost/wordpress/?page_id=74', 0, 'page', '', 0); 
INSERT INTO `wp_posts` VALUES (75, 1, '2013-11-26 17:02:26', '2013-11-26 16:02:26', '<ul id="improved">\r\n	<li> <a href="http://savemysmartphone.fr/conditions-generales#">Préambule</a>\r\n<div>\r\n\r\nLes présentes conditions générales de ventes sont conclues d\'une part par la société Save my Smartphone dont le siège social se trouve au 23 rue Duret, 75116 Paris immatriculée au registre du commerce et des sociétés sous le numéro 791 070 907 et d\'autre part, par toute personnes physique ou morale souhaitant procéder à l\'achat de nos prestations dénommée ci-après " l\'acheteur ", "le consommateur".\r\n\r\n</div></li>\r\n	<li> <a href="http://savemysmartphone.fr/conditions-generales#">Article 1 : Objet</a>\r\n<div>\r\n\r\nLes conditions générales contenues dans ce document régissent les relations contractuelles entre Save my Smartphone et son client dans le cadre d\'un service de réparation. Les deux parties les acceptent sans réserve. Ces conditions prévaudront sur toutes autres conditions. Ce contrat est soumis au droit français.\r\n\r\n</div></li>\r\n	<li> <a href="http://savemysmartphone.fr/conditions-generales#">Article 2 : Obligations du client</a>\r\n<div>\r\n\r\nLors du dépôt de votre matériel la sauvegarde de vos données doit avoir été faite. Save my Smartphone ne saurait être tenue responsable de la perte éventuelle ou de la destruction des données stockées dans votre appareil. L\'Acheteur reconnaît être informé que l\'intervention de Save my Smartphone sur son matériel, peut entraîner une rupture de garantie du constructeur et/ou du distributeur.\r\n\r\n</div></li>\r\n	<li> <a href="http://savemysmartphone.fr/conditions-generales#">Article 3 : Garantie de réparation</a>\r\n<div>\r\n\r\nNos réparations sont garanties 1 an. La garantie contractuelle commerciale couvre la ou les pièces détachées changées lors de la réparation. Il n\'y aura aucune garantie de la part du Vendeur en cas de modification du matériel, accident ou choc, détérioration volontaire, dégâts causés par l\'eau, le feu, l\'humidité, la foudre. Aucune garantie ne sera applicable en cas d\'utilisation anormale.\r\n\r\n</div></li>\r\n	<li> <a href="http://savemysmartphone.fr/conditions-generales#">Article 4 : Délai</a>\r\n<div>\r\n\r\nLe délai des réparations est établi à titre indicatif par le technicien lors de l\'analyse de l\'appareil. Chaque machine est traitée par ordre d\'arrivée. De ce fait, aucune réclamation ne pourra être effectuée en cas de retard du service technique. Si Save my Smartphone n\'a pas effectué la réparation dans un délai de 15 jours maximum et que l\'Acheteur souhaite récupérer son appareil, aucun frais de devis ne sera facturé.\r\n\r\n</div></li>\r\n	<li> <a href="http://savemysmartphone.fr/conditions-generales#">Article 5 : Droit de garde</a>\r\n<div>\r\n\r\nSave my Smartphone indique à sa clientèle qu\'un droit de garde sera appliqué pour tout téléphone réparé ou diagnostiqué de 19 euros par mois\r\n\r\n</div></li>\r\n	<li> <a href="http://savemysmartphone.fr/conditions-generales#">Article 6 : Tarifs</a>\r\n<div>\r\n\r\nLes prix fourni par l\'entreprise sont des prix TTC en euro. Save my Smartphone se réserve de modifier ses prix à tout moment. Certains appareils pris en charge ne sont pas réparables. Ils nécessitent cependant un temps de travail pour établir un diagnostic et statuer sur l\'état du téléphone. Un forfait de 19 euros, sera donc facturé pour diagnostiquer le téléphone. Forfait que le client ne paiera que dans 2 cas. Si le client n\'accepte pas le devis qui lui a été proposé par Save my Smartphone ou si le téléphone est jugé irréparable.\r\n\r\n</div></li>\r\n	<li> <a href="http://savemysmartphone.fr/conditions-generales#">Article 7 : Retour</a>\r\n<div>\r\n\r\nEn cas de retour sous garantie, pour une réparation effectuée par nos soins, la main d\'œuvre sera prise en charge par Save my Smartphone pendant une durée d\'un an à compter de la date de sortie de notre boutique, la facture faisant office de justifi¬catif de sortie. Passé ce délai, la main d\'œuvre sera à la charge de l\'Acheteur. En ce qui concerne la pièce utilisée pour la réparation, la durée de la garantie d\'une pièce d\'occasion est de un an, à compter de la date de facturation.\r\n\r\n</div></li>\r\n	<li> <a href="http://savemysmartphone.fr/conditions-generales#">Article 8 : Perte de données</a>\r\n<div>\r\n\r\nDans le cadre des prestations de service effectuées, l\'Acheteur reste responsable des données présentes sur son appareil. La responsabilité de Save my Smartphone ne peut en aucun cas être engagée. Par ailleurs, en cas de perte de données, l\'Acheteur ne pourra réclamer des dommages et intérêts relatifs à une quelconque valeur des données enregistrées. Save my Smartphone ne sera pas tenu responsable des éventuels dommages occasionnés sur les données, qu\'ils soient directs ou indirects, suite à l\'intervention des techniciens.\r\n\r\n</div></li>\r\n	<li> <a href="http://savemysmartphone.fr/conditions-generales#">Article 9 : Responsabilités</a>\r\n<div>\r\n\r\nDans certains cas, les chocs importants ayant entrainés la casse de l\'appareil sont tels que la seule ouverture du téléphone peut générer une panne qui peut être différente de la raison de prise en charge initiale. Save my Smartphone ne peut en cas être tenu pour responsable d\'avoir causé la panne. L\'ouverture d\'un appareil est à la responsabilité du client.\r\n\r\n</div></li>\r\n</ul>', 'Conditions générales', '', 'inherit', 'open', 'open', '', '74-revision-v1', '', '', '2013-11-26 17:02:26', '2013-11-26 16:02:26', '', 74, 'http://localhost/wordpress/74-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (76, 1, '2013-11-26 17:12:17', '2013-11-26 16:12:17', '<strong>Préambule </strong>\n\n&nbsp;\n\nLes présentes conditions générales de ventes sont conclues d\'une part par la société Save my Smartphone dont le siège social se trouve au 23 rue Duret, 75116 Paris immatriculée au registre du commerce et des sociétés sous le numéro 791 070 907 et d\'autre part, par toute personnes physique ou morale souhaitant procéder à l\'achat de nos prestations dénommée ci-après " l\'acheteur ", "le consommateur".\n\n&nbsp;\n\n<strong>Article 1</strong>\n\n&nbsp;\n\nLes conditions générales contenues dans ce document régissent les relations contractuelles entre Save my Smartphone et son client dans le cadre d\'un service de réparation. Les deux parties les acceptent sans réserve. Ces conditions prévaudront sur toutes autres conditions. Ce contrat est soumis au droit français.\n\n&nbsp;\n\n<strong>Article 2</strong>\n\n&nbsp;\n\nLors du dépôt de votre matériel la sauvegarde de vos données doit avoir été faite. Save my Smartphone ne saurait être tenue responsable de la perte éventuelle ou de la destruction des données stockées dans votre appareil. L\'Acheteur reconnaît être informé que l\'intervention de Save my Smartphone sur son matériel, peut entraîner une rupture de garantie du constructeur et/ou du distributeur.\n\n&nbsp;\n\n<strong>Article 3</strong>\n\n&nbsp;\n\nNos réparations sont garanties 1 an. La garantie contractuelle commerciale couvre la ou les pièces détachées changées lors de la réparation. Il n\'y aura aucune garantie de la part du Vendeur en cas de modification du matériel, accident ou choc, détérioration volontaire, dégâts causés par l\'eau, le feu, l\'humidité, la foudre. Aucune garantie ne sera applicable en cas d\'utilisation anormale.\n\n&nbsp;\n\n<strong>Article 4</strong>\n\n&nbsp;\n\nLe délai des réparations est établi à titre indicatif par le technicien lors de l\'analyse de l\'appareil. Chaque machine est traitée par ordre d\'arrivée. De ce fait, aucune réclamation ne pourra être effectuée en cas de retard du service technique. Si Save my Smartphone n\'a pas effectué la réparation dans un délai de 15 jours maximum et que l\'Acheteur souhaite récupérer son appareil, aucun frais de devis ne sera facturé.\n\n&nbsp;\n\n<strong>Article 5</strong>\n\n&nbsp;\n\nSave my Smartphone indique à sa clientèle qu\'un droit de garde sera appliqué pour tout téléphone réparé ou diagnostiqué de 19 euros par mois\n\n&nbsp;\n\n<strong>Article 6</strong>\n\n&nbsp;\n\nLes prix fourni par l\'entreprise sont des prix TTC en euro. Save my Smartphone se réserve de modifier ses prix à tout moment. Certains appareils pris en charge ne sont pas réparables. Ils nécessitent cependant un temps de travail pour établir un diagnostic et statuer sur l\'état du téléphone. Un forfait de 19 euros, sera donc facturé pour diagnostiquer le téléphone. Forfait que le client ne paiera que dans 2 cas. Si le client n\'accepte pas le devis qui lui a été proposé par Save my Smartphone ou si le téléphone est jugé irréparable.\n\n&nbsp;\n\n<strong>Article 7</strong>\n\n&nbsp;\n\nEn cas de retour sous garantie, pour une réparation effectuée par nos soins, la main d\'œuvre sera prise en charge par Save my Smartphone pendant une durée d\'un an à compter de la date de sortie de notre boutique, la facture faisant office de justifi¬catif de sortie. Passé ce délai, la main d\'œuvre sera à la charge de l\'Acheteur. En ce qui concerne la pièce utilisée pour la réparation, la durée de la garantie d\'une pièce d\'occasion est de un an, à compter de la date de facturation.\n\n&nbsp;\n\n<strong>Article 8</strong>\n\n&nbsp;\n\nDans le cadre des prestations de service effectuées, l\'Acheteur reste responsable des données présentes sur son appareil. La responsabilité de Save my Smartphone ne peut en aucun cas être engagée. Par ailleurs, en cas de perte de données, l\'Acheteur ne pourra réclamer des dommages et intérêts relatifs à une quelconque valeur des données enregistrées. Save my Smartphone ne sera pas tenu responsable des éventuels dommages occasionnés sur les données, qu\'ils soient directs ou indirects, suite à l\'intervention des techniciens.\n\n&nbsp;\n\n<strong>Article 9</strong>\n\n&nbsp;\n\nDans certains cas, les chocs importants ayant entrainés la casse de l\'appareil sont tels que la seule ouverture du téléphone peut générer une panne qui peut être différente de la raison de prise en charge initiale. Save my Smartphone ne peut en cas être tenu pour responsable d\'avoir causé la panne. L\'ouverture d\'un appareil est à la responsabilité du client.\n\n&nbsp;\n\n<strong>Article 10</strong>\n\n&nbsp;\n\nLa Loi française est applicable à tout litige avec l\'Acheteur.\n\n&nbsp;\n\n<strong>Article 11</strong>\n\n&nbsp;\n\n&nbsp;', 'Conditions générales', '', 'inherit', 'open', 'open', '', '74-autosave-v1', '', '', '2013-11-26 17:12:17', '2013-11-26 16:12:17', '', 74, 'http://localhost/wordpress/74-autosave-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (77, 1, '2013-11-26 17:05:42', '2013-11-26 16:05:42', '<strong>Article 1</strong>\r\n\r\nLes présentes conditions générales de ventes sont conclues d\'une part par la société Save my Smartphone dont le siège social se trouve au 23 rue Duret, 75116 Paris immatriculée au registre du commerce et des sociétés sous le numéro 791 070 907 et d\'autre part, par toute personnes physique ou morale souhaitant procéder à l\'achat de nos prestations dénommée ci-après " l\'acheteur ", "le consommateur".\r\n\r\n<strong>Article 2</strong>\r\n\r\n<strong>Article 3</strong>\r\n\r\n<strong>Article 4</strong>\r\n\r\n<strong>Article 5</strong>\r\n\r\n<strong>Article 6</strong>\r\n\r\n<strong>Article 7</strong>\r\n\r\n<strong>Article 8</strong>\r\n\r\n<strong>Article 9</strong>\r\n\r\n<strong>Article 10</strong>\r\n\r\n<strong>Article 11</strong>', 'Conditions générales', '', 'inherit', 'open', 'open', '', '74-revision-v1', '', '', '2013-11-26 17:05:42', '2013-11-26 16:05:42', '', 74, 'http://localhost/wordpress/74-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (78, 1, '2013-11-26 17:07:02', '2013-11-26 16:07:02', '<strong>Article 1</strong>\r\n\r\n&nbsp;\r\n\r\nLes présentes conditions générales de ventes sont conclues d\'une part par la société Save my Smartphone dont le siège social se trouve au 23 rue Duret, 75116 Paris immatriculée au registre du commerce et des sociétés sous le numéro 791 070 907 et d\'autre part, par toute personnes physique ou morale souhaitant procéder à l\'achat de nos prestations dénommée ci-après " l\'acheteur ", "le consommateur".\r\n\r\n&nbsp;\r\n\r\n<strong>Article 2</strong>\r\n\r\n&nbsp;\r\n\r\nLes conditions générales contenues dans ce document régissent les relations contractuelles entre Save my Smartphone et son client dans le cadre d\'un service de réparation. Les deux parties les acceptent sans réserve. Ces conditions prévaudront sur toutes autres conditions. Ce contrat est soumis au droit français.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 3</strong>\r\n\r\n&nbsp;\r\n\r\nLors du dépôt de votre matériel la sauvegarde de vos données doit avoir été faite. Save my Smartphone ne saurait être tenue responsable de la perte éventuelle ou de la destruction des données stockées dans votre appareil. L\'Acheteur reconnaît être informé que l\'intervention de Save my Smartphone sur son matériel, peut entraîner une rupture de garantie du constructeur et/ou du distributeur.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 4</strong>\r\n\r\n<strong>Article 5</strong>\r\n\r\n<strong>Article 6</strong>\r\n\r\n<strong>Article 7</strong>\r\n\r\n<strong>Article 8</strong>\r\n\r\n<strong>Article 9</strong>\r\n\r\n<strong>Article 10</strong>\r\n\r\n<strong>Article 11</strong>', 'Conditions générales', '', 'inherit', 'open', 'open', '', '74-revision-v1', '', '', '2013-11-26 17:07:02', '2013-11-26 16:07:02', '', 74, 'http://localhost/wordpress/74-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (79, 1, '2013-11-26 17:12:31', '2013-11-26 16:12:31', '<strong>Préambule </strong>\r\n\r\n&nbsp;\r\n\r\nLes présentes conditions générales de ventes sont conclues d\'une part par la société Save my Smartphone dont le siège social se trouve au 23 rue Duret, 75116 Paris immatriculée au registre du commerce et des sociétés sous le numéro 791 070 907 et d\'autre part, par toute personnes physique ou morale souhaitant procéder à l\'achat de nos prestations dénommée ci-après " l\'acheteur ", "le consommateur".\r\n\r\n&nbsp;\r\n\r\n<strong>Article 1</strong>\r\n\r\n&nbsp;\r\n\r\nLes conditions générales contenues dans ce document régissent les relations contractuelles entre Save my Smartphone et son client dans le cadre d\'un service de réparation. Les deux parties les acceptent sans réserve. Ces conditions prévaudront sur toutes autres conditions. Ce contrat est soumis au droit français.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 2</strong>\r\n\r\n&nbsp;\r\n\r\nLors du dépôt de votre matériel la sauvegarde de vos données doit avoir été faite. Save my Smartphone ne saurait être tenue responsable de la perte éventuelle ou de la destruction des données stockées dans votre appareil. L\'Acheteur reconnaît être informé que l\'intervention de Save my Smartphone sur son matériel, peut entraîner une rupture de garantie du constructeur et/ou du distributeur.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 3</strong>\r\n\r\n&nbsp;\r\n\r\nNos réparations sont garanties 1 an. La garantie contractuelle commerciale couvre la ou les pièces détachées changées lors de la réparation. Il n\'y aura aucune garantie de la part du Vendeur en cas de modification du matériel, accident ou choc, détérioration volontaire, dégâts causés par l\'eau, le feu, l\'humidité, la foudre. Aucune garantie ne sera applicable en cas d\'utilisation anormale.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 4</strong>\r\n\r\n&nbsp;\r\n\r\nLe délai des réparations est établi à titre indicatif par le technicien lors de l\'analyse de l\'appareil. Chaque machine est traitée par ordre d\'arrivée. De ce fait, aucune réclamation ne pourra être effectuée en cas de retard du service technique. Si Save my Smartphone n\'a pas effectué la réparation dans un délai de 15 jours maximum et que l\'Acheteur souhaite récupérer son appareil, aucun frais de devis ne sera facturé.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 5</strong>\r\n\r\n&nbsp;\r\n\r\nSave my Smartphone indique à sa clientèle qu\'un droit de garde sera appliqué pour tout téléphone réparé ou diagnostiqué de 19 euros par mois\r\n\r\n&nbsp;\r\n\r\n<strong>Article 6</strong>\r\n\r\n&nbsp;\r\n\r\nLes prix fourni par l\'entreprise sont des prix TTC en euro. Save my Smartphone se réserve de modifier ses prix à tout moment. Certains appareils pris en charge ne sont pas réparables. Ils nécessitent cependant un temps de travail pour établir un diagnostic et statuer sur l\'état du téléphone. Un forfait de 19 euros, sera donc facturé pour diagnostiquer le téléphone. Forfait que le client ne paiera que dans 2 cas. Si le client n\'accepte pas le devis qui lui a été proposé par Save my Smartphone ou si le téléphone est jugé irréparable.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 7</strong>\r\n\r\n&nbsp;\r\n\r\nEn cas de retour sous garantie, pour une réparation effectuée par nos soins, la main d\'œuvre sera prise en charge par Save my Smartphone pendant une durée d\'un an à compter de la date de sortie de notre boutique, la facture faisant office de justifi¬catif de sortie. Passé ce délai, la main d\'œuvre sera à la charge de l\'Acheteur. En ce qui concerne la pièce utilisée pour la réparation, la durée de la garantie d\'une pièce d\'occasion est de un an, à compter de la date de facturation.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 8</strong>\r\n\r\n&nbsp;\r\n\r\nDans le cadre des prestations de service effectuées, l\'Acheteur reste responsable des données présentes sur son appareil. La responsabilité de Save my Smartphone ne peut en aucun cas être engagée. Par ailleurs, en cas de perte de données, l\'Acheteur ne pourra réclamer des dommages et intérêts relatifs à une quelconque valeur des données enregistrées. Save my Smartphone ne sera pas tenu responsable des éventuels dommages occasionnés sur les données, qu\'ils soient directs ou indirects, suite à l\'intervention des techniciens.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 9</strong>\r\n\r\n&nbsp;\r\n\r\nDans certains cas, les chocs importants ayant entrainés la casse de l\'appareil sont tels que la seule ouverture du téléphone peut générer une panne qui peut être différente de la raison de prise en charge initiale. Save my Smartphone ne peut en cas être tenu pour responsable d\'avoir causé la panne. L\'ouverture d\'un appareil est à la responsabilité du client.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 10</strong>\r\n\r\n&nbsp;\r\n\r\nLa Loi française est applicable à tout litige avec l\'Acheteur.\r\n\r\n&nbsp;\r\n\r\n<strong>Article 11</strong>\r\n\r\n&nbsp;\r\n\r\nLe tribunal de Paris est seul compétent à tout litige avec l\'Acheteur.', 'Conditions générales', '', 'inherit', 'open', 'open', '', '74-revision-v1', '', '', '2013-11-26 17:12:31', '2013-11-26 16:12:31', '', 74, 'http://localhost/wordpress/74-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (80, 1, '2013-11-26 17:16:54', '2013-11-26 16:16:54', '<strong>Rapidité</strong>\r\n\r\n&nbsp;\r\n\r\nNous vous garantissons une rapidité intervention. La majorité des interventions ne prennent que 30 minutes.\r\n\r\n&nbsp;\r\n\r\n<strong>Fiabilité</strong>\r\n\r\n&nbsp;\r\n\r\nNous vous assurons la qualité des pièces et matériaux que nous utilisons.\r\n\r\n&nbsp;\r\n\r\n<strong>Qualité</strong>\r\n\r\n&nbsp;\r\n\r\nNous vous proposons un service de qualité grâce l\'expérience de nos techniciens dans la réparation de smartphone et tablettes.\r\n\r\n&nbsp;\r\n\r\n<strong>Disponibilité</strong>\r\n\r\n&nbsp;\r\n\r\nVous pouvez vous rendre dans notre boutique sans prendre de rendez vous.\r\n\r\n&nbsp;\r\n\r\n<strong>Engagements environnementaux</strong>\r\n\r\n&nbsp;\r\n\r\nNous nousengageons à recycler les pièces défectueuses et les batteries pour la protection de notre environnement.\r\n\r\n&nbsp;\r\n\r\n<strong>Transparence</strong>\r\n\r\n&nbsp;\r\n\r\nDès la prise en charge de votre appareil, nous vous informons du prix et du délai de réparation pour une transparence optimale.', 'Charte Qualité', '', 'publish', 'open', 'open', '', 'charte-qualite', '', '', '2013-11-26 17:16:54', '2013-11-26 16:16:54', '', 0, 'http://localhost/wordpress/?page_id=80', 0, 'page', '', 0); 
INSERT INTO `wp_posts` VALUES (81, 1, '2013-11-26 17:16:54', '2013-11-26 16:16:54', '<strong>Rapidité</strong>\r\n\r\n&nbsp;\r\n\r\nNous vous garantissons une rapidité intervention. La majorité des interventions ne prennent que 30 minutes.\r\n\r\n&nbsp;\r\n\r\n<strong>Fiabilité</strong>\r\n\r\n&nbsp;\r\n\r\nNous vous assurons la qualité des pièces et matériaux que nous utilisons.\r\n\r\n&nbsp;\r\n\r\n<strong>Qualité</strong>\r\n\r\n&nbsp;\r\n\r\nNous vous proposons un service de qualité grâce l\'expérience de nos techniciens dans la réparation de smartphone et tablettes.\r\n\r\n&nbsp;\r\n\r\n<strong>Disponibilité</strong>\r\n\r\n&nbsp;\r\n\r\nVous pouvez vous rendre dans notre boutique sans prendre de rendez vous.\r\n\r\n&nbsp;\r\n\r\n<strong>Engagements environnementaux</strong>\r\n\r\n&nbsp;\r\n\r\nNous nousengageons à recycler les pièces défectueuses et les batteries pour la protection de notre environnement.\r\n\r\n&nbsp;\r\n\r\n<strong>Transparence</strong>\r\n\r\n&nbsp;\r\n\r\nDès la prise en charge de votre appareil, nous vous informons du prix et du délai de réparation pour une transparence optimale.', 'Charte Qualité', '', 'inherit', 'open', 'open', '', '80-revision-v1', '', '', '2013-11-26 17:16:54', '2013-11-26 16:16:54', '', 80, 'http://localhost/wordpress/80-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (82, 1, '2013-11-26 17:18:08', '2013-11-26 16:18:08', 'Le site <a href="http://savemysmartphone.fr/www.savemysmartphone.fr">www.savemysmartphone.fr</a> est édité par :\r\n\r\nSave my Smartphone\r\nSAS au capital de 20 000 EUR\r\nSiège social : 23 rue Duret 75116 Paris\r\nTéléphone : 01 77 32 88 46\r\nMail : <a href="mailto:contact@savemysmartphone.fr">contact@savemysmartphone.fr</a>\r\n\r\n&nbsp;\r\n\r\nImmatriculé au Registre du Commerce et des Sociétés sous le numéro Paris B 791 070 907\r\nLe directeur de la publication est Damien Morin\r\nLe site internet est hébergé par :\r\n\r\n1&amp;1 Internet SARL\r\nSARL au capital de 100 000 EUR\r\n7, place de la Gare , BP 70109 , 57201 Sarreguemines Cedex\r\nRCS Sarreguemines B 431 303 775\r\nSIRET 431 303 775 000 16\r\nAPE 642 B\r\n\r\n&nbsp;\r\n\r\n<strong>Liens hypertexte :</strong>\r\n\r\nPoint Service Mobiles ne contrôle pas les sites en connexion avec le sien, et ne saurait donc être responsable de leur contenu. Les risques liés à l\'utilisation de ces sites incombent pleinement à l\'utilisateur. Il se conformera à leurs conditions d\'utilisation.\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n\r\n<strong>Droit d\'auteur et propriété intellectuelle :</strong>\r\n\r\nLa conception générale, ainsi que les textes, images animées ou non, sons, savoir faire et tout autres éléments composants le site sont la propriété exclusive de Save my Smartphone et/ou de ses fournisseurs.\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n\r\n<strong>Contrefaçon :</strong>\r\n\r\nToute reproduction ou représentation de ce service (contenus, pages, scripts, etc.), en tout ou partie, sur un quelconque support, présent ou futur, est strictement interdite. Le non-respect de cette interdiction constitue une contrefaçon pouvant engager la responsabilité civile et pénale du contrefacteur. Les informations contenues dans ce service sont non contractuelles et sujettes à modification sans préavis.', 'Mentions légales', '', 'publish', 'open', 'open', '', 'mentions-legales', '', '', '2013-11-26 17:18:39', '2013-11-26 16:18:39', '', 0, 'http://localhost/wordpress/?page_id=82', 0, 'page', '', 0); 
INSERT INTO `wp_posts` VALUES (83, 1, '2013-11-26 17:18:08', '2013-11-26 16:18:08', 'Le site <a href="http://savemysmartphone.fr/www.savemysmartphone.fr">www.savemysmartphone.fr</a> est édité par :\r\n\r\nSave my Smartphone\r\nSAS au capital de 20 000 EUR\r\nSiège social : 23 rue Duret 75116 Paris\r\nTéléphone : 01 77 32 88 46\r\nMail : <a href="mailto:contact@savemysmartphone.fr">contact@savemysmartphone.fr</a>\r\n\r\n&nbsp;\r\n\r\nImmatriculé au Registre du Commerce et des Sociétés sous le numéro Paris B 791 070 907\r\nLe directeur de la publication est Damien Morin\r\nLe site internet est hébergé par :\r\n\r\n1&amp;1 Internet SARL\r\nSARL au capital de 100 000 EUR\r\n7, place de la Gare , BP 70109 , 57201 Sarreguemines Cedex\r\nRCS Sarreguemines B 431 303 775\r\nSIRET 431 303 775 000 16\r\nAPE 642 B\r\n\r\n&nbsp;\r\n\r\n<strong>Liens hypertexte :</strong>\r\n\r\nPoint Service Mobiles ne contrôle pas les sites en connexion avec le sien, et ne saurait donc être responsable de leur contenu. Les risques liés à l\'utilisation de ces sites incombent pleinement à l\'utilisateur. Il se conformera à leurs conditions d\'utilisation.\r\n\r\n&nbsp;\r\n\r\n<strong>Droit d\'auteur et propriété intellectuelle :</strong>\r\n\r\nLa conception générale, ainsi que les textes, images animées ou non, sons, savoir faire et tout autres éléments composants le site sont la propriété exclusive de Save my Smartphone et/ou de ses fournisseurs.\r\n\r\n&nbsp;\r\n\r\n<strong>Contrefaçon :</strong>\r\n\r\nToute reproduction ou représentation de ce service (contenus, pages, scripts, etc.), en tout ou partie, sur un quelconque support, présent ou futur, est strictement interdite. Le non-respect de cette interdiction constitue une contrefaçon pouvant engager la responsabilité civile et pénale du contrefacteur. Les informations contenues dans ce service sont non contractuelles et sujettes à modification sans préavis.', 'Mentions légales', '', 'inherit', 'open', 'open', '', '82-revision-v1', '', '', '2013-11-26 17:18:08', '2013-11-26 16:18:08', '', 82, 'http://localhost/wordpress/82-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (84, 1, '2013-11-26 17:18:39', '2013-11-26 16:18:39', 'Le site <a href="http://savemysmartphone.fr/www.savemysmartphone.fr">www.savemysmartphone.fr</a> est édité par :\r\n\r\nSave my Smartphone\r\nSAS au capital de 20 000 EUR\r\nSiège social : 23 rue Duret 75116 Paris\r\nTéléphone : 01 77 32 88 46\r\nMail : <a href="mailto:contact@savemysmartphone.fr">contact@savemysmartphone.fr</a>\r\n\r\n&nbsp;\r\n\r\nImmatriculé au Registre du Commerce et des Sociétés sous le numéro Paris B 791 070 907\r\nLe directeur de la publication est Damien Morin\r\nLe site internet est hébergé par :\r\n\r\n1&amp;1 Internet SARL\r\nSARL au capital de 100 000 EUR\r\n7, place de la Gare , BP 70109 , 57201 Sarreguemines Cedex\r\nRCS Sarreguemines B 431 303 775\r\nSIRET 431 303 775 000 16\r\nAPE 642 B\r\n\r\n&nbsp;\r\n\r\n<strong>Liens hypertexte :</strong>\r\n\r\nPoint Service Mobiles ne contrôle pas les sites en connexion avec le sien, et ne saurait donc être responsable de leur contenu. Les risques liés à l\'utilisation de ces sites incombent pleinement à l\'utilisateur. Il se conformera à leurs conditions d\'utilisation.\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n\r\n<strong>Droit d\'auteur et propriété intellectuelle :</strong>\r\n\r\nLa conception générale, ainsi que les textes, images animées ou non, sons, savoir faire et tout autres éléments composants le site sont la propriété exclusive de Save my Smartphone et/ou de ses fournisseurs.\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n\r\n<strong>Contrefaçon :</strong>\r\n\r\nToute reproduction ou représentation de ce service (contenus, pages, scripts, etc.), en tout ou partie, sur un quelconque support, présent ou futur, est strictement interdite. Le non-respect de cette interdiction constitue une contrefaçon pouvant engager la responsabilité civile et pénale du contrefacteur. Les informations contenues dans ce service sont non contractuelles et sujettes à modification sans préavis.', 'Mentions légales', '', 'inherit', 'open', 'open', '', '82-revision-v1', '', '', '2013-11-26 17:18:39', '2013-11-26 16:18:39', '', 82, 'http://localhost/wordpress/82-revision-v1/', 0, 'revision', '', 0); 
INSERT INTO `wp_posts` VALUES (85, 1, '2013-11-26 17:20:51', '2013-11-26 16:20:51', ' ', '', '', 'publish', 'open', 'open', '', '85', '', '', '2013-11-27 18:56:46', '2013-11-27 17:56:46', '', 0, 'http://localhost/wordpress/?p=85', 1, 'nav_menu_item', '', 0); 
INSERT INTO `wp_posts` VALUES (86, 1, '2013-11-26 17:20:51', '2013-11-26 16:20:51', ' ', '', '', 'publish', 'open', 'open', '', '86', '', '', '2013-11-27 18:56:46', '2013-11-27 17:56:46', '', 0, 'http://localhost/wordpress/?p=86', 2, 'nav_menu_item', '', 0); 
INSERT INTO `wp_posts` VALUES (87, 1, '2013-11-26 17:20:52', '2013-11-26 16:20:52', ' ', '', '', 'publish', 'open', 'open', '', '87', '', '', '2013-11-27 18:56:46', '2013-11-27 17:56:46', '', 0, 'http://localhost/wordpress/?p=87', 3, 'nav_menu_item', '', 0); 
INSERT INTO `wp_posts` VALUES (88, 1, '2013-11-27 18:56:46', '2013-11-27 17:56:46', '', 'Dossier Presse', '', 'publish', 'open', 'open', '', 'dossier-presse', '', '', '2013-11-27 18:56:46', '2013-11-27 17:56:46', '', 0, 'http://localhost/wordpress/?p=88', 4, 'nav_menu_item', '', 0);
#
# End of data contents of table `wp_posts`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_term_relationships`
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 1, 0); 
INSERT INTO `wp_term_relationships` VALUES (42, 3, 0); 
INSERT INTO `wp_term_relationships` VALUES (43, 3, 0); 
INSERT INTO `wp_term_relationships` VALUES (44, 3, 0); 
INSERT INTO `wp_term_relationships` VALUES (45, 3, 0); 
INSERT INTO `wp_term_relationships` VALUES (46, 3, 0); 
INSERT INTO `wp_term_relationships` VALUES (85, 4, 0); 
INSERT INTO `wp_term_relationships` VALUES (86, 4, 0); 
INSERT INTO `wp_term_relationships` VALUES (87, 4, 0); 
INSERT INTO `wp_term_relationships` VALUES (88, 4, 0);
#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_term_taxonomy`
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 1); 
INSERT INTO `wp_term_taxonomy` VALUES (3, 3, 'nav_menu', '', 0, 5); 
INSERT INTO `wp_term_taxonomy` VALUES (4, 4, 'nav_menu', '', 0, 4);
#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_terms`
#
 
INSERT INTO `wp_terms` VALUES (1, 'Non classé', 'non-classe', 0); 
INSERT INTO `wp_terms` VALUES (3, 'menu header', 'menu-header', 0); 
INSERT INTO `wp_terms` VALUES (4, 'menu footer', 'menu-footer', 0);
#
# End of data contents of table `wp_terms`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_usermeta`
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', ''); 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', ''); 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'admin'); 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', ''); 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'wp_user_level', '10'); 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks'); 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'show_welcome_panel', '1'); 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_dashboard_quick_press_last_post_id', '53'); 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'); 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";}'); 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'wp_user-settings', 'imgsize=full&editor=tinymce'); 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'wp_user-settings-time', '1385394015'); 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'nav_menu_recently_edited', '4'); 
INSERT INTO `wp_usermeta` VALUES (20, 2, 'first_name', 'Damien'); 
INSERT INTO `wp_usermeta` VALUES (21, 2, 'last_name', 'Morin'); 
INSERT INTO `wp_usermeta` VALUES (22, 2, 'nickname', 'damien'); 
INSERT INTO `wp_usermeta` VALUES (23, 2, 'description', ''); 
INSERT INTO `wp_usermeta` VALUES (24, 2, 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES (25, 2, 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES (26, 2, 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES (27, 2, 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES (28, 2, 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES (29, 2, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES (30, 2, 'wp_user_level', '10'); 
INSERT INTO `wp_usermeta` VALUES (31, 2, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks'); 
INSERT INTO `wp_usermeta` VALUES (32, 2, 'wp_dashboard_quick_press_last_post_id', '73'); 
INSERT INTO `wp_usermeta` VALUES (33, 2, 'wpseo_title', ''); 
INSERT INTO `wp_usermeta` VALUES (34, 2, 'wpseo_metadesc', ''); 
INSERT INTO `wp_usermeta` VALUES (35, 2, 'wpseo_metakey', ''); 
INSERT INTO `wp_usermeta` VALUES (36, 2, '_yoast_wpseo_profile_updated', '1385480582'); 
INSERT INTO `wp_usermeta` VALUES (37, 2, 'googleplus', ''); 
INSERT INTO `wp_usermeta` VALUES (38, 2, 'twitter', ''); 
INSERT INTO `wp_usermeta` VALUES (39, 2, 'facebook', '');
#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_users`
#
 
INSERT INTO `wp_users` VALUES (1, 'admin', '$P$Bw47UdkilArVH/Vc9j8mpZN12NiMZV.', 'admin', 'contact@ab-agency.fr', '', '2013-11-15 13:54:15', '', 0, 'admin'); 
INSERT INTO `wp_users` VALUES (2, 'damien', '$P$B3.r7Sj31vllUYQmGhyAHJtDuPQDkw/', 'damien', 'damien@savemysmartphone.fr', 'http://www.savemysmartphone.fr', '2013-11-22 11:27:44', '', 0, 'Damien Morin');
#
# End of data contents of table `wp_users`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_admin`
# --------------------------------------------------------


#
# Delete any existing table `wp_admin`
#

DROP TABLE IF EXISTS `wp_admin`;


#
# Table structure of table `wp_admin`
#

CREATE TABLE `wp_admin` (
  `a_id` int(2) NOT NULL,
  `username` varchar(30) COLLATE latin1_general_ci DEFAULT NULL,
  `password` varchar(30) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`a_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ;

#
# Data contents of table `wp_admin`
#
 
INSERT INTO `wp_admin` VALUES (1, 'admin', 'smsp_2013');
#
# End of data contents of table `wp_admin`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_model_service`
# --------------------------------------------------------


#
# Delete any existing table `wp_model_service`
#

DROP TABLE IF EXISTS `wp_model_service`;


#
# Table structure of table `wp_model_service`
#

CREATE TABLE `wp_model_service` (
  `ms_id` int(2) NOT NULL,
  `pm_id` varchar(30) COLLATE latin1_general_ci DEFAULT NULL,
  `service_name` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `service_price` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`ms_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ;

#
# Data contents of table `wp_model_service`
#
 
INSERT INTO `wp_model_service` VALUES (1, '103', 'écran cassé', '159,00'); 
INSERT INTO `wp_model_service` VALUES (3, '103', 'Bouton Home', '59,00'); 
INSERT INTO `wp_model_service` VALUES (5, '103', 'Dock de Charge', '79,00'); 
INSERT INTO `wp_model_service` VALUES (6, '103', 'Nappe Jack', '79,00'); 
INSERT INTO `wp_model_service` VALUES (7, '103', 'Nappe Power', '79,00	'); 
INSERT INTO `wp_model_service` VALUES (9, '103', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (10, '104', 'écran cassé', '89,00'); 
INSERT INTO `wp_model_service` VALUES (11, '103', 'Batterie', '49,00'); 
INSERT INTO `wp_model_service` VALUES (12, '104', 'Dock de Charge', '59,00'); 
INSERT INTO `wp_model_service` VALUES (13, '104', 'Bouton Home', '49,00'); 
INSERT INTO `wp_model_service` VALUES (15, '104', 'Nappe Power', '55,00'); 
INSERT INTO `wp_model_service` VALUES (16, '104', 'Appareil Photo', '79,00'); 
INSERT INTO `wp_model_service` VALUES (17, '104', 'Caméra Facetime', '49,00'); 
INSERT INTO `wp_model_service` VALUES (18, '104', 'Batterie', '49,00'); 
INSERT INTO `wp_model_service` VALUES (19, '104', 'Face arrière', '29,00'); 
INSERT INTO `wp_model_service` VALUES (21, '104', 'Vibreur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (22, '104', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (23, '104', 'Chassis', '99,00'); 
INSERT INTO `wp_model_service` VALUES (24, '104', 'Ecouteur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (25, '104', 'Haut-Parleur', '59,00'); 
INSERT INTO `wp_model_service` VALUES (26, '104', 'Nappe Jack', '59,00'); 
INSERT INTO `wp_model_service` VALUES (27, '105', 'écran cassé', '79,00'); 
INSERT INTO `wp_model_service` VALUES (30, '105', 'Bouton Home', '49,00'); 
INSERT INTO `wp_model_service` VALUES (31, '105', 'Nappe Power', '55,00'); 
INSERT INTO `wp_model_service` VALUES (32, '105', 'Dock de Charge', '59,00'); 
INSERT INTO `wp_model_service` VALUES (33, '105', 'Appareil Photo', '49,00'); 
INSERT INTO `wp_model_service` VALUES (34, '105', 'Caméra Facetime', '49,00'); 
INSERT INTO `wp_model_service` VALUES (35, '105', 'Batterie', '39,00'); 
INSERT INTO `wp_model_service` VALUES (36, '105', 'Face arrière', '29,00'); 
INSERT INTO `wp_model_service` VALUES (38, '105', 'Vibreur', '39,00'); 
INSERT INTO `wp_model_service` VALUES (39, '105', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (40, '105', 'Chassis', '99,00'); 
INSERT INTO `wp_model_service` VALUES (41, '105', 'Ecouteur', '39,00'); 
INSERT INTO `wp_model_service` VALUES (42, '105', 'Haut Parleur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (43, '105', 'Nappe Jack', '49,00'); 
INSERT INTO `wp_model_service` VALUES (44, '106', 'Vitre cassée', '39,00'); 
INSERT INTO `wp_model_service` VALUES (45, '106', 'écran LCD', '49,00'); 
INSERT INTO `wp_model_service` VALUES (46, '106', 'Bloc écran', '59,00'); 
INSERT INTO `wp_model_service` VALUES (48, '106', 'Bouton Home', '35,00'); 
INSERT INTO `wp_model_service` VALUES (49, '106', 'Batterie', '39,00'); 
INSERT INTO `wp_model_service` VALUES (50, '106', 'Dock de Charge', '49,00'); 
INSERT INTO `wp_model_service` VALUES (51, '106', 'Appareil Photo', '39,00'); 
INSERT INTO `wp_model_service` VALUES (52, '106', 'Vibreur', '25,00'); 
INSERT INTO `wp_model_service` VALUES (53, '106', 'Coque arrière', '69,00'); 
INSERT INTO `wp_model_service` VALUES (54, '106', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (55, '106', 'Ecouteur', '39,00'); 
INSERT INTO `wp_model_service` VALUES (56, '106', 'Nappe Jack', '49,00'); 
INSERT INTO `wp_model_service` VALUES (57, '106', 'Nappe Proximité', '39,00'); 
INSERT INTO `wp_model_service` VALUES (58, '106', 'Antenne Wifi', '39,00'); 
INSERT INTO `wp_model_service` VALUES (59, '106', 'Lecteur SIM', '49,00'); 
INSERT INTO `wp_model_service` VALUES (60, '107', 'Vitre cassée', '39,00'); 
INSERT INTO `wp_model_service` VALUES (61, '107', 'écran LCD', '49,00'); 
INSERT INTO `wp_model_service` VALUES (62, '107', 'Bloc écran', '59,00'); 
INSERT INTO `wp_model_service` VALUES (64, '107', 'Bouton Home', '35,00'); 
INSERT INTO `wp_model_service` VALUES (65, '107', 'Batterie', '39,00'); 
INSERT INTO `wp_model_service` VALUES (66, '107', 'Dock de Charge', '49,00'); 
INSERT INTO `wp_model_service` VALUES (67, '107', 'Appareil Photo', '39,00'); 
INSERT INTO `wp_model_service` VALUES (68, '107', 'Vibreur', '25,00'); 
INSERT INTO `wp_model_service` VALUES (69, '107', 'Coque arrière', '69,00'); 
INSERT INTO `wp_model_service` VALUES (70, '107', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (71, '107', 'Ecouteur', '39,00'); 
INSERT INTO `wp_model_service` VALUES (72, '107', 'Nappe Jack', '49,00'); 
INSERT INTO `wp_model_service` VALUES (73, '107', 'Nappe Proximité', '39,00'); 
INSERT INTO `wp_model_service` VALUES (74, '107', 'Antenne Wifi', '39,00'); 
INSERT INTO `wp_model_service` VALUES (75, '107', 'Lecteur SIM', '49,00'); 
INSERT INTO `wp_model_service` VALUES (76, '202', 'écran cassé (i9300)', '189,00'); 
INSERT INTO `wp_model_service` VALUES (77, '109', 'Vitre cassée', '129,00'); 
INSERT INTO `wp_model_service` VALUES (78, '202', 'écran cassé (i9305)', '209,00'); 
INSERT INTO `wp_model_service` VALUES (79, '202', 'Vitre cassée', '119,00'); 
INSERT INTO `wp_model_service` VALUES (80, '109', 'écran LCD', '159,00'); 
INSERT INTO `wp_model_service` VALUES (81, '202', 'Désoxydation', '59,00	'); 
INSERT INTO `wp_model_service` VALUES (84, '202', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (85, '109', 'Batterie', '129,00'); 
INSERT INTO `wp_model_service` VALUES (86, '109', 'Dock de Charge', '79,00'); 
INSERT INTO `wp_model_service` VALUES (87, '202', 'Haut	Parleur', '69,00'); 
INSERT INTO `wp_model_service` VALUES (88, '109', 'Antenne Wifi', '69,00'); 
INSERT INTO `wp_model_service` VALUES (89, '109', 'Nappe Jack', '79,00'); 
INSERT INTO `wp_model_service` VALUES (90, '109', 'Lecteur SIM', '69,00'); 
INSERT INTO `wp_model_service` VALUES (91, '202', 'Ecouteur', '69,00'); 
INSERT INTO `wp_model_service` VALUES (92, '109', 'Supplément 3G', '10,00'); 
INSERT INTO `wp_model_service` VALUES (93, '109', 'Remise en état d\'un coin', '10,00'); 
INSERT INTO `wp_model_service` VALUES (94, '202', 'Nappe	Power', '69,00'); 
INSERT INTO `wp_model_service` VALUES (95, '203', 'écran cassé', '149,00'); 
INSERT INTO `wp_model_service` VALUES (97, '203', 'Connecteur	de	charge', '59,00	'); 
INSERT INTO `wp_model_service` VALUES (99, '203', 'Camera	Avant', '79,00'); 
INSERT INTO `wp_model_service` VALUES (100, '203', 'Lecteur	SIM', '69,00	'); 
INSERT INTO `wp_model_service` VALUES (101, '203', 'Camera	arrière', '89,00	'); 
INSERT INTO `wp_model_service` VALUES (102, '203', 'Haut	Parleur', '79,00	'); 
INSERT INTO `wp_model_service` VALUES (103, '203', 'Désoxydation', '59,00	'); 
INSERT INTO `wp_model_service` VALUES (104, '108', 'Vitre cassée', '149,00'); 
INSERT INTO `wp_model_service` VALUES (105, '204', 'écran cassé', '129,00'); 
INSERT INTO `wp_model_service` VALUES (106, '204', 'Microphone', '59,00'); 
INSERT INTO `wp_model_service` VALUES (107, '204', 'Connecteur	de	charge', '59,00	'); 
INSERT INTO `wp_model_service` VALUES (109, '204', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (110, '108', 'écran LCD', '159,00'); 
INSERT INTO `wp_model_service` VALUES (112, '204', 'Appareil	Photo', '59,00'); 
INSERT INTO `wp_model_service` VALUES (114, '204', 'Batterie', '20,00'); 
INSERT INTO `wp_model_service` VALUES (115, '108', 'Batterie', '149,00'); 
INSERT INTO `wp_model_service` VALUES (117, '108', 'Dock de Charge', '79,00'); 
INSERT INTO `wp_model_service` VALUES (119, '108', 'Antenne Wifi', '69,00'); 
INSERT INTO `wp_model_service` VALUES (120, '108', 'Nappe Jack', '79,00'); 
INSERT INTO `wp_model_service` VALUES (121, '108', 'Lecteur SIM', '69,00'); 
INSERT INTO `wp_model_service` VALUES (122, '108', 'Supplément 3G', '10,00'); 
INSERT INTO `wp_model_service` VALUES (123, '108', 'Remise en état d\'un coin', '10,00'); 
INSERT INTO `wp_model_service` VALUES (124, '204', 'Désoxydation', '59,00	'); 
INSERT INTO `wp_model_service` VALUES (125, '111', 'Vitre cassée', '69,00'); 
INSERT INTO `wp_model_service` VALUES (126, '111', 'écran LCD', '79,00'); 
INSERT INTO `wp_model_service` VALUES (127, '206', 'écran cassé', '229,00'); 
INSERT INTO `wp_model_service` VALUES (128, '206', 'Vitre cassée', '129,00'); 
INSERT INTO `wp_model_service` VALUES (129, '206', 'Connecteur	de	Charge', '59,00'); 
INSERT INTO `wp_model_service` VALUES (130, '206', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (131, '206', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (132, '206', 'Nappe	Power', '59,00'); 
INSERT INTO `wp_model_service` VALUES (133, '206', 'Haut	parleur', '69,00'); 
INSERT INTO `wp_model_service` VALUES (134, '60', 'Vitre cassée', '79,00'); 
INSERT INTO `wp_model_service` VALUES (135, '60', 'écran LCD', '59,00'); 
INSERT INTO `wp_model_service` VALUES (136, '207', 'écran cassé', '199,00'); 
INSERT INTO `wp_model_service` VALUES (139, '60', 'Batterie', '20,00'); 
INSERT INTO `wp_model_service` VALUES (140, '60', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (141, '60', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (142, '61', 'Vitre cassée', '79,00'); 
INSERT INTO `wp_model_service` VALUES (144, '111', 'Batterie', '59,00'); 
INSERT INTO `wp_model_service` VALUES (145, '61', 'Batterie', '25,00'); 
INSERT INTO `wp_model_service` VALUES (146, '61', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (147, '61', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (148, '207', 'Connecteur	de	Charge', '59,00'); 
INSERT INTO `wp_model_service` VALUES (149, '207', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (150, '207', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (151, '111', 'Bouton Home', '59,00'); 
INSERT INTO `wp_model_service` VALUES (152, '111', 'Nappe Power', '79,00'); 
INSERT INTO `wp_model_service` VALUES (153, '111', 'Dock de Charge', '79,00'); 
INSERT INTO `wp_model_service` VALUES (154, '208', 'écran cassé', '219,00'); 
INSERT INTO `wp_model_service` VALUES (155, '111', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (157, '110', 'écran cassé', '79,00'); 
INSERT INTO `wp_model_service` VALUES (158, '208', 'Antenne', '59,00'); 
INSERT INTO `wp_model_service` VALUES (159, '110', 'Batterie', '59,00'); 
INSERT INTO `wp_model_service` VALUES (160, '208', 'Connecteur	de	Charge', '59,00'); 
INSERT INTO `wp_model_service` VALUES (161, '110', 'Bouton Home', '59,00'); 
INSERT INTO `wp_model_service` VALUES (162, '208', 'Haut	Parleur', '59,00'); 
INSERT INTO `wp_model_service` VALUES (163, '110', 'Nappe Power', '79,00'); 
INSERT INTO `wp_model_service` VALUES (164, '208', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (165, '110', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (166, '208', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (167, '209', 'écran cassé', '159,00'); 
INSERT INTO `wp_model_service` VALUES (168, '62', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (169, '62', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (170, '63', 'Vitre cassée', '99,00'); 
INSERT INTO `wp_model_service` VALUES (171, '63', 'écran LCD', '89,00'); 
INSERT INTO `wp_model_service` VALUES (173, '63', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (174, '63', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (175, '209', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (176, '209', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (177, '64', 'écran cassé', '169,00'); 
INSERT INTO `wp_model_service` VALUES (178, '209', 'Haut	Parleur', '59,00'); 
INSERT INTO `wp_model_service` VALUES (179, '209', 'Ecouteur', '59,00'); 
INSERT INTO `wp_model_service` VALUES (180, '64', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (181, '209', 'Nappe	Power', '59,00'); 
INSERT INTO `wp_model_service` VALUES (182, '64', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (183, '65', 'Vitre cassée', '99,00'); 
INSERT INTO `wp_model_service` VALUES (184, '65', 'écran LCD', '119,00'); 
INSERT INTO `wp_model_service` VALUES (186, '65', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (187, '65', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (188, '66', 'écran cassé', '109,00'); 
INSERT INTO `wp_model_service` VALUES (189, '66', 'Batterie', '20,00'); 
INSERT INTO `wp_model_service` VALUES (190, '66', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (191, '66', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (192, '67', 'écran cassé', '89,00'); 
INSERT INTO `wp_model_service` VALUES (193, '67', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (194, '67', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (195, '68', 'Vitre cassée', '79,00'); 
INSERT INTO `wp_model_service` VALUES (197, '210', 'Vitre	cassée', '69,00'); 
INSERT INTO `wp_model_service` VALUES (198, '68', 'écran LCD', '79,00'); 
INSERT INTO `wp_model_service` VALUES (201, '210', 'écran LCD', '89,00'); 
INSERT INTO `wp_model_service` VALUES (204, '68', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (205, '68', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (207, '210', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (208, '210', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (209, '211', 'Vitre	cassée', '149,00'); 
INSERT INTO `wp_model_service` VALUES (210, '26', 'écran cassé', '299,00'); 
INSERT INTO `wp_model_service` VALUES (212, '211', 'écran LCD', '299,00'); 
INSERT INTO `wp_model_service` VALUES (213, '26', 'Batterie', '99,00'); 
INSERT INTO `wp_model_service` VALUES (215, '211', 'Batterie', '89,00'); 
INSERT INTO `wp_model_service` VALUES (216, '27', 'Vitre cassée', '129,00'); 
INSERT INTO `wp_model_service` VALUES (217, '212', 'Vitre	cassée', '129,00'); 
INSERT INTO `wp_model_service` VALUES (218, '27', 'écran LCD', '139,00'); 
INSERT INTO `wp_model_service` VALUES (220, '212', 'écran LCD', '199,00	'); 
INSERT INTO `wp_model_service` VALUES (223, '27', 'Batterie', '99,00'); 
INSERT INTO `wp_model_service` VALUES (224, '212', 'Batterie', '89,00'); 
INSERT INTO `wp_model_service` VALUES (225, '22', 'écran cassé', '239,00'); 
INSERT INTO `wp_model_service` VALUES (226, '22', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (227, '22', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (228, '23', 'Vitre cassée', '109,00'); 
INSERT INTO `wp_model_service` VALUES (229, '23', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (230, '23', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (232, '24', 'écran cassé', '109,00'); 
INSERT INTO `wp_model_service` VALUES (233, '213', 'Vitre cassée', '129,00'); 
INSERT INTO `wp_model_service` VALUES (234, '24', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (235, '213', 'écran LCD', '299,00'); 
INSERT INTO `wp_model_service` VALUES (236, '24', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (238, '213', 'Batterie', '89,00'); 
INSERT INTO `wp_model_service` VALUES (239, '214', 'Vitre	Cassé', '119,00'); 
INSERT INTO `wp_model_service` VALUES (241, '214', 'écran LCD', '159,00	'); 
INSERT INTO `wp_model_service` VALUES (243, '214', 'Batterie', '89,00	'); 
INSERT INTO `wp_model_service` VALUES (245, '25', 'Vitre cassée', '79,00'); 
INSERT INTO `wp_model_service` VALUES (246, '25', 'écran LCD', '89,00'); 
INSERT INTO `wp_model_service` VALUES (248, '25', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (249, '25', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (250, '54', 'Vitre	cassée', '99,00'); 
INSERT INTO `wp_model_service` VALUES (252, '54', 'écran LCD', '99,00'); 
INSERT INTO `wp_model_service` VALUES (255, '54', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (256, '55', 'Vitre	Cassée', '69,00'); 
INSERT INTO `wp_model_service` VALUES (258, '55', 'écran LCD', '79,00'); 
INSERT INTO `wp_model_service` VALUES (261, '55', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (262, '55', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (263, '56', 'Vitre	cassée', '69,00'); 
INSERT INTO `wp_model_service` VALUES (265, '56', 'écran LCD', '69,00'); 
INSERT INTO `wp_model_service` VALUES (268, '56', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (269, '56', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (270, '57', 'Vitre cassée', '79,00'); 
INSERT INTO `wp_model_service` VALUES (271, '57', 'écran LCD', '79,00'); 
INSERT INTO `wp_model_service` VALUES (273, '57', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (274, '57', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (275, '58', 'Vitre Cassée', '69,00'); 
INSERT INTO `wp_model_service` VALUES (276, '58', 'écran LCD', '69,00'); 
INSERT INTO `wp_model_service` VALUES (278, '58', 'Lecteur	SIM', '59,00	'); 
INSERT INTO `wp_model_service` VALUES (279, '58', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (280, '59', 'écran cassé', '229,00'); 
INSERT INTO `wp_model_service` VALUES (281, '59', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (282, '59', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (284, '43', 'Vitre cassée', '89,00'); 
INSERT INTO `wp_model_service` VALUES (285, '43', 'écran LCD', '89,00'); 
INSERT INTO `wp_model_service` VALUES (287, '43', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (288, '43', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (289, '42', 'Vitre cassée', '79,00	'); 
INSERT INTO `wp_model_service` VALUES (290, '42', 'écran LCD', '79,00	'); 
INSERT INTO `wp_model_service` VALUES (292, '42', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (293, '42', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (294, '41', 'écran cassé', '179,00'); 
INSERT INTO `wp_model_service` VALUES (295, '41', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (296, '41', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (297, '40', 'Vitre Cassée', '109,00'); 
INSERT INTO `wp_model_service` VALUES (298, '40', 'écran LCD', '99,00'); 
INSERT INTO `wp_model_service` VALUES (300, '40', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (301, '40', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (302, '39', 'Vitre cassée', '79,00'); 
INSERT INTO `wp_model_service` VALUES (303, '39', 'écran LCD', '149,00'); 
INSERT INTO `wp_model_service` VALUES (305, '39', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (306, '39', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (307, '38', 'Vitre cassée', '89,00'); 
INSERT INTO `wp_model_service` VALUES (308, '38', 'écran LCD', '109,00'); 
INSERT INTO `wp_model_service` VALUES (310, '38', 'Nappe	Power', '59,00'); 
INSERT INTO `wp_model_service` VALUES (311, '38', 'Haut	Parleur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (312, '38', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (313, '38', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (314, '37', 'Vitre cassée', '79,00'); 
INSERT INTO `wp_model_service` VALUES (315, '37', 'écran LCD', '119,00'); 
INSERT INTO `wp_model_service` VALUES (317, '37', 'Haut	Parleur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (318, '37', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (319, '37', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (320, '36', 'Vitre cassée', '89,00'); 
INSERT INTO `wp_model_service` VALUES (321, '36', 'écran LCD', '109,00'); 
INSERT INTO `wp_model_service` VALUES (323, '36', 'Haut	Parleur', '49,00	'); 
INSERT INTO `wp_model_service` VALUES (324, '36', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (325, '36', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (326, '35', 'écran cassé', '129,00'); 
INSERT INTO `wp_model_service` VALUES (327, '35', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (328, '35', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (329, '34', 'Vitre cassée', '79,00'); 
INSERT INTO `wp_model_service` VALUES (330, '34', 'écran LCD', '89,00'); 
INSERT INTO `wp_model_service` VALUES (332, '34', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (333, '34', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (334, '44', 'Vitre cassée', '89,00'); 
INSERT INTO `wp_model_service` VALUES (335, '33', 'Vitre cassée', '69,00'); 
INSERT INTO `wp_model_service` VALUES (337, '33', 'écran LCD', '119,00'); 
INSERT INTO `wp_model_service` VALUES (339, '44', 'écran LCD', '109,00'); 
INSERT INTO `wp_model_service` VALUES (340, '33', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (341, '33', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (343, '32', 'Vitre cassée', '69,00'); 
INSERT INTO `wp_model_service` VALUES (344, '44', 'Bloc écran', '129,00'); 
INSERT INTO `wp_model_service` VALUES (345, '32', 'écran LCD', '89,00'); 
INSERT INTO `wp_model_service` VALUES (346, '32', 'Bloc écran', '109,00'); 
INSERT INTO `wp_model_service` VALUES (347, '32', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (348, '44', 'Bouton Navigation', '49,00'); 
INSERT INTO `wp_model_service` VALUES (349, '32', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (350, '44', 'Connecteur de Charge', '59,00'); 
INSERT INTO `wp_model_service` VALUES (351, '31', 'écran cassé', '89,00'); 
INSERT INTO `wp_model_service` VALUES (352, '44', 'Lecteur SIM', '69,00'); 
INSERT INTO `wp_model_service` VALUES (353, '31', 'Haut	Parleur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (354, '31', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (355, '44', 'Haut Parleur', '59,00'); 
INSERT INTO `wp_model_service` VALUES (356, '31', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (357, '44', 'Micro', '69,00'); 
INSERT INTO `wp_model_service` VALUES (358, '30', 'écran cassé', '199,00'); 
INSERT INTO `wp_model_service` VALUES (359, '30', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (360, '44', 'Ecouteur', '59,00'); 
INSERT INTO `wp_model_service` VALUES (361, '30', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (362, '44', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (363, '29', 'écran cassé', '269,00'); 
INSERT INTO `wp_model_service` VALUES (364, '29', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (365, '29', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (366, '28', 'écran cassé', '159,00'); 
INSERT INTO `wp_model_service` VALUES (367, '45', 'Vitre cassée', '89,00'); 
INSERT INTO `wp_model_service` VALUES (368, '28', 'Lecteur	SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (369, '28', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (370, '45', 'Vitre Blanc', '89,00'); 
INSERT INTO `wp_model_service` VALUES (371, '45', 'écran LCD', '139,00'); 
INSERT INTO `wp_model_service` VALUES (372, '45', 'Bloc écran', '159,00'); 
INSERT INTO `wp_model_service` VALUES (374, '45', 'Bouton de Navigation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (375, '45', 'Connecteur de Charge', '59,00'); 
INSERT INTO `wp_model_service` VALUES (376, '45', 'Lecteur SIM', '69,00'); 
INSERT INTO `wp_model_service` VALUES (377, '45', 'Haut Parleur', '59,00'); 
INSERT INTO `wp_model_service` VALUES (378, '45', 'Micro', '69,00'); 
INSERT INTO `wp_model_service` VALUES (379, '45', 'Ecouteur', '59,00'); 
INSERT INTO `wp_model_service` VALUES (380, '45', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (381, '46', 'écran LCD', '89,00'); 
INSERT INTO `wp_model_service` VALUES (382, '46', 'Bouton de Navigation', '49,00'); 
INSERT INTO `wp_model_service` VALUES (383, '46', 'Connecteur de Charge', '49,00'); 
INSERT INTO `wp_model_service` VALUES (384, '46', 'Lecteur SIM', '69,00'); 
INSERT INTO `wp_model_service` VALUES (385, '46', 'Micro', '59,00'); 
INSERT INTO `wp_model_service` VALUES (386, '46', 'Haut Parleur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (387, '46', 'Ecouteur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (388, '46', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (389, '47', 'écran LCD', '89,00'); 
INSERT INTO `wp_model_service` VALUES (390, '47', 'Bouton de Navigation', '49,00'); 
INSERT INTO `wp_model_service` VALUES (391, '47', 'Connecteur de Charge', '49,00'); 
INSERT INTO `wp_model_service` VALUES (392, '47', 'Lecteur SIM', '69,00'); 
INSERT INTO `wp_model_service` VALUES (393, '47', 'Micro', '59,00'); 
INSERT INTO `wp_model_service` VALUES (394, '47', 'Haut Parleur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (395, '47', 'Ecouteur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (396, '47', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (397, '48', 'Vitre cassée', '109,00'); 
INSERT INTO `wp_model_service` VALUES (398, '48', 'écran LCD', '109,00'); 
INSERT INTO `wp_model_service` VALUES (399, '48', 'bloc écran', '159,00'); 
INSERT INTO `wp_model_service` VALUES (400, '48', 'Bouton de Navigation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (401, '48', 'Connecteur de Charge', '69,00'); 
INSERT INTO `wp_model_service` VALUES (402, '48', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (403, '48', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (404, '49', 'Vitre cassée', '89,00'); 
INSERT INTO `wp_model_service` VALUES (406, '49', 'écran LCD', '119,00'); 
INSERT INTO `wp_model_service` VALUES (407, '49', 'bloc écran', '159,00'); 
INSERT INTO `wp_model_service` VALUES (408, '49', 'Bouton de Navigation', '49,00'); 
INSERT INTO `wp_model_service` VALUES (409, '49', 'Connecteur de Charge', '59,00'); 
INSERT INTO `wp_model_service` VALUES (410, '49', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (411, '49', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (412, '49', 'Haut Parleur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (413, '49', 'Ecouteur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (414, '50', 'écran LCD', '59,00'); 
INSERT INTO `wp_model_service` VALUES (415, '50', 'Bouton de Navigation', '49,00'); 
INSERT INTO `wp_model_service` VALUES (416, '50', 'Connecteur de Charge', '49,00'); 
INSERT INTO `wp_model_service` VALUES (417, '50', 'Micro', '49,00'); 
INSERT INTO `wp_model_service` VALUES (418, '50', 'Ecouteur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (419, '50', 'Haut Parleur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (420, '50', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (421, '50', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (422, '51', 'écran LCD', '89,00'); 
INSERT INTO `wp_model_service` VALUES (423, '51', 'Bouton de Navigation', '49,00'); 
INSERT INTO `wp_model_service` VALUES (424, '51', 'Connecteur de Charge', '59,00'); 
INSERT INTO `wp_model_service` VALUES (425, '51', 'Micro', '49,00'); 
INSERT INTO `wp_model_service` VALUES (426, '51', 'Ecouteur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (427, '51', 'Haut Parleur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (428, '51', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (429, '51', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (430, '52', 'écran LCD', '129,00'); 
INSERT INTO `wp_model_service` VALUES (431, '52', 'Bouton de Navigation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (432, '52', 'Connecteur de Charge', '59,00'); 
INSERT INTO `wp_model_service` VALUES (433, '52', 'Micro', '49,00'); 
INSERT INTO `wp_model_service` VALUES (434, '52', 'Ecouteur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (435, '52', 'Haut Parleur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (436, '52', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (437, '52', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (438, '53', 'écran LCD', '59,00'); 
INSERT INTO `wp_model_service` VALUES (439, '53', 'Bouton de Navigation', '49,00'); 
INSERT INTO `wp_model_service` VALUES (440, '53', 'Connecteur de Charge', '49,00'); 
INSERT INTO `wp_model_service` VALUES (441, '53', 'Micro', '49,00'); 
INSERT INTO `wp_model_service` VALUES (442, '53', 'Ecouteur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (443, '53', 'Haut Parleur', '49,00'); 
INSERT INTO `wp_model_service` VALUES (444, '53', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (445, '53', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (446, '102', 'écran cassé', '299,00'); 
INSERT INTO `wp_model_service` VALUES (447, '102', 'Dock de charge', '79,00'); 
INSERT INTO `wp_model_service` VALUES (448, '102', 'Nappe Power', '79,00'); 
INSERT INTO `wp_model_service` VALUES (449, '102', 'Batterie', '59,00'); 
INSERT INTO `wp_model_service` VALUES (450, '102', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (451, '101', 'écran cassé', '299,00'); 
INSERT INTO `wp_model_service` VALUES (452, '101', 'Bouton capteur empreinte', '99,00'); 
INSERT INTO `wp_model_service` VALUES (453, '101', 'Dock de charge', '79,00'); 
INSERT INTO `wp_model_service` VALUES (454, '101', 'Nappe Power', '79,00'); 
INSERT INTO `wp_model_service` VALUES (455, '101', 'Batterie', '59,00'); 
INSERT INTO `wp_model_service` VALUES (456, '101', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (500, '201', 'écran cassé', '249,00'); 
INSERT INTO `wp_model_service` VALUES (501, '201', 'Vitre cassée', '139,00'); 
INSERT INTO `wp_model_service` VALUES (502, '201', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (503, '201', 'Dock de charge', '79,00'); 
INSERT INTO `wp_model_service` VALUES (504, '201', 'Haut Parleur', '59,00'); 
INSERT INTO `wp_model_service` VALUES (505, '201', 'Batterie', '39,00'); 
INSERT INTO `wp_model_service` VALUES (511, '205', 'écran cassé', '299,00'); 
INSERT INTO `wp_model_service` VALUES (512, '205', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (513, '205', 'Dock de charge', '79,00'); 
INSERT INTO `wp_model_service` VALUES (514, '205', 'Haut Parleur', '59,00'); 
INSERT INTO `wp_model_service` VALUES (515, '205', 'Batterie', '39,00'); 
INSERT INTO `wp_model_service` VALUES (601, '215', 'écran cassé', '149,00'); 
INSERT INTO `wp_model_service` VALUES (602, '215', 'Vitre cassée', '99,00'); 
INSERT INTO `wp_model_service` VALUES (603, '215', 'Désoxydation', '59,00'); 
INSERT INTO `wp_model_service` VALUES (604, '215', 'Lecteur SIM', '59,00'); 
INSERT INTO `wp_model_service` VALUES (605, '215', 'Haut Parleur', '69,00'); 
INSERT INTO `wp_model_service` VALUES (606, '215', 'Ecouteurs', '69,00'); 
INSERT INTO `wp_model_service` VALUES (607, '215', 'Nappe Power', '69,00');
#
# End of data contents of table `wp_model_service`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_model_sub_service`
# --------------------------------------------------------


#
# Delete any existing table `wp_model_sub_service`
#

DROP TABLE IF EXISTS `wp_model_sub_service`;


#
# Table structure of table `wp_model_sub_service`
#

CREATE TABLE `wp_model_sub_service` (
  `mss_id` int(2) NOT NULL,
  `ms_id` varchar(30) COLLATE latin1_general_ci DEFAULT NULL,
  `sub_service_name` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `sub_service_price` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`mss_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ;

#
# Data contents of table `wp_model_sub_service`
#
 
INSERT INTO `wp_model_sub_service` VALUES (7, '3', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (8, '3', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (10, '4', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (11, '4', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (12, '4', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (13, '5', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (14, '5', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (15, '5', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (16, '6', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (17, '6', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (18, '6', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (19, '7', 'En Boutique', '79,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (20, '7', 'Par courrier', '79,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (21, '7', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (22, '8', 'En Boutique', '14,00'); 
INSERT INTO `wp_model_sub_service` VALUES (23, '8', 'Par courrier', '14,00'); 
INSERT INTO `wp_model_sub_service` VALUES (24, '8', 'Technicien ÃƒÂ  domicile', '33,00'); 
INSERT INTO `wp_model_sub_service` VALUES (25, '9', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (26, '9', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (27, '9', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (28, '10', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (29, '10', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (30, '10', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (31, '11', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (32, '11', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (33, '11', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (34, '12', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (35, '12', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (36, '12', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (37, '13', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (38, '13', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (39, '13', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (40, '14', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (41, '14', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (42, '14', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (43, '15', 'En Boutique', '55,00'); 
INSERT INTO `wp_model_sub_service` VALUES (44, '15', 'Par courrier', '55,00'); 
INSERT INTO `wp_model_sub_service` VALUES (45, '15', 'Technicien ÃƒÂ  domicile', '74,00'); 
INSERT INTO `wp_model_sub_service` VALUES (46, '16', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (47, '16', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (48, '16', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (49, '17', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (50, '17', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (51, '17', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (52, '18', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (53, '18', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (54, '18', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (55, '19', 'En Boutique', '29,00'); 
INSERT INTO `wp_model_sub_service` VALUES (56, '19', 'Par courrier', '29,00'); 
INSERT INTO `wp_model_sub_service` VALUES (57, '19', 'Technicien ÃƒÂ  domicile', '48,00'); 
INSERT INTO `wp_model_sub_service` VALUES (58, '20', 'En Boutique', '14,00'); 
INSERT INTO `wp_model_sub_service` VALUES (59, '20', 'Par courrier', '14,00'); 
INSERT INTO `wp_model_sub_service` VALUES (60, '20', 'Technicien ÃƒÂ  domicile', '33,00'); 
INSERT INTO `wp_model_sub_service` VALUES (61, '21', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (62, '21', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (63, '21', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (64, '22', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (65, '22', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (66, '22', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (67, '23', 'En Boutique', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (68, '23', 'Par courrier', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (69, '23', 'Technicien ÃƒÂ  domicile', '118,00'); 
INSERT INTO `wp_model_sub_service` VALUES (70, '24', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (71, '24', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (72, '24', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (73, '25', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (74, '25', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (75, '25', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (76, '26', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (77, '26', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (78, '26', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (79, '27', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (80, '27', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (81, '27', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (82, '28', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (83, '28', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (84, '28', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (85, '29', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (86, '29', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (87, '29', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (88, '30', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (89, '30', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (90, '30', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (91, '31', 'En Boutique', '55,00'); 
INSERT INTO `wp_model_sub_service` VALUES (92, '31', 'Par courrier', '55,00'); 
INSERT INTO `wp_model_sub_service` VALUES (93, '31', 'Technicien ÃƒÂ  domicile', '74,00'); 
INSERT INTO `wp_model_sub_service` VALUES (94, '32', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (95, '32', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (96, '32', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (97, '33', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (98, '33', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (99, '33', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (100, '34', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (101, '34', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (102, '34', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (103, '35', 'En Boutique', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (104, '35', 'Par courrier', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (105, '35', 'Technicien ÃƒÂ  domicile', '58,00'); 
INSERT INTO `wp_model_sub_service` VALUES (106, '36', 'En Boutique', '29,00'); 
INSERT INTO `wp_model_sub_service` VALUES (107, '36', 'Par courrier', '29,00'); 
INSERT INTO `wp_model_sub_service` VALUES (108, '36', 'Technicien ÃƒÂ  domicile', '48,00'); 
INSERT INTO `wp_model_sub_service` VALUES (109, '37', 'En Boutique', '14,00'); 
INSERT INTO `wp_model_sub_service` VALUES (110, '37', 'Par courrier', '14,00'); 
INSERT INTO `wp_model_sub_service` VALUES (111, '37', 'Technicien ÃƒÂ  domicile', '33,00'); 
INSERT INTO `wp_model_sub_service` VALUES (112, '38', 'En Boutique', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (113, '38', 'Par courrier', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (114, '38', 'Technicien ÃƒÂ  domicile', '58,00'); 
INSERT INTO `wp_model_sub_service` VALUES (115, '39', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (116, '39', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (117, '39', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (118, '40', 'En Boutique', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (119, '40', 'Par courrier', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (120, '40', 'Technicien ÃƒÂ  domicile', '118,00'); 
INSERT INTO `wp_model_sub_service` VALUES (121, '41', 'En Boutique', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (122, '41', 'Par courrier', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (123, '41', 'Technicien ÃƒÂ  domicile', '58,00'); 
INSERT INTO `wp_model_sub_service` VALUES (124, '42', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (125, '42', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (126, '42', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (127, '43', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (128, '43', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (129, '43', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (130, '44', 'En Boutique', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (131, '44', 'Par courrier', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (132, '44', 'Technicien ÃƒÂ  domicile', '58,00'); 
INSERT INTO `wp_model_sub_service` VALUES (133, '45', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (134, '45', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (135, '45', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (136, '46', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (137, '46', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (138, '46', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (139, '47', 'En Boutique', '35,00'); 
INSERT INTO `wp_model_sub_service` VALUES (140, '47', 'Par courrier', '35,00'); 
INSERT INTO `wp_model_sub_service` VALUES (141, '47', 'Technicien ÃƒÂ  domicile', '54,00'); 
INSERT INTO `wp_model_sub_service` VALUES (142, '48', 'En Boutique', '35,00'); 
INSERT INTO `wp_model_sub_service` VALUES (143, '48', 'Par courrier', '35,00'); 
INSERT INTO `wp_model_sub_service` VALUES (144, '48', 'Technicien ÃƒÂ  domicile', '54,00'); 
INSERT INTO `wp_model_sub_service` VALUES (145, '49', 'En Boutique', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (146, '49', 'Par courrier', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (147, '49', 'Technicien ÃƒÂ  domicile', '58,00'); 
INSERT INTO `wp_model_sub_service` VALUES (148, '50', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (149, '50', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (150, '50', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (151, '51', 'En Boutique', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (152, '51', 'Par courrier', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (153, '51', 'Technicien ÃƒÂ  domicile', '58,00'); 
INSERT INTO `wp_model_sub_service` VALUES (154, '52', 'En Boutique', '25,00'); 
INSERT INTO `wp_model_sub_service` VALUES (155, '52', 'Par courrier', '25,00'); 
INSERT INTO `wp_model_sub_service` VALUES (156, '52', 'Technicien ÃƒÂ  domicile', '44,00'); 
INSERT INTO `wp_model_sub_service` VALUES (157, '53', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (158, '53', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (159, '53', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (160, '54', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (161, '54', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (162, '54', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (163, '55', 'En Boutique', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (164, '55', 'Par courrier', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (165, '55', 'Technicien ÃƒÂ  domicile', '58,00'); 
INSERT INTO `wp_model_sub_service` VALUES (166, '56', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (167, '56', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (168, '56', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (169, '57', 'En Boutique', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (170, '57', 'Par courrier', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (171, '57', 'Technicien ÃƒÂ  domicile', '58,00'); 
INSERT INTO `wp_model_sub_service` VALUES (172, '58', 'En Boutique', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (173, '58', 'Par courrier', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (174, '58', 'Technicien ÃƒÂ  domicile', '58,00'); 
INSERT INTO `wp_model_sub_service` VALUES (175, '59', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (176, '59', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (177, '59', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (178, '60', 'En Boutique', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (179, '60', 'Par courrier', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (180, '60', 'Technicien ÃƒÂ  domicile', '58,00'); 
INSERT INTO `wp_model_sub_service` VALUES (181, '61', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (182, '61', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (183, '61', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (184, '62', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (185, '62', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (186, '62', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (187, '63', 'En Boutique', '35,00'); 
INSERT INTO `wp_model_sub_service` VALUES (188, '63', 'Par courrier', '35,00'); 
INSERT INTO `wp_model_sub_service` VALUES (189, '63', 'Technicien ÃƒÂ  domicile', '54,00'); 
INSERT INTO `wp_model_sub_service` VALUES (190, '64', 'En Boutique', '35,00'); 
INSERT INTO `wp_model_sub_service` VALUES (191, '64', 'Par courrier', '35,00'); 
INSERT INTO `wp_model_sub_service` VALUES (192, '64', 'Technicien ÃƒÂ  domicile', '54,00'); 
INSERT INTO `wp_model_sub_service` VALUES (193, '65', 'En Boutique', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (194, '65', 'Par courrier', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (195, '65', 'Technicien ÃƒÂ  domicile', '58,00'); 
INSERT INTO `wp_model_sub_service` VALUES (196, '66', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (197, '66', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (198, '66', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (199, '67', 'En Boutique', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (200, '67', 'Par courrier', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (201, '67', 'Technicien ÃƒÂ  domicile', '58,00'); 
INSERT INTO `wp_model_sub_service` VALUES (202, '68', 'En Boutique', '25,00'); 
INSERT INTO `wp_model_sub_service` VALUES (203, '68', 'Par courrier', '25,00'); 
INSERT INTO `wp_model_sub_service` VALUES (204, '68', 'Technicien ÃƒÂ  domicile', '44,00'); 
INSERT INTO `wp_model_sub_service` VALUES (205, '69', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (206, '69', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (207, '69', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (208, '70', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (209, '70', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (210, '70', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (211, '71', 'En Boutique', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (212, '71', 'Par courrier', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (213, '71', 'Technicien ÃƒÂ  domicile', '58,00'); 
INSERT INTO `wp_model_sub_service` VALUES (214, '72', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (215, '72', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (216, '72', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (217, '73', 'En Boutique', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (218, '73', 'Par courrier', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (219, '73', 'Technicien ÃƒÂ  domicile', '58,00'); 
INSERT INTO `wp_model_sub_service` VALUES (220, '74', 'En Boutique', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (221, '74', 'Par courrier', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (222, '74', 'Technicien ÃƒÂ  domicile', '58,00'); 
INSERT INTO `wp_model_sub_service` VALUES (223, '75', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (224, '75', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (225, '75', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (226, '76', 'En Boutique', '189,00'); 
INSERT INTO `wp_model_sub_service` VALUES (227, '76', 'Par courrier', '189,00'); 
INSERT INTO `wp_model_sub_service` VALUES (228, '76', 'Technicien ÃƒÂ  domicile', '278,00'); 
INSERT INTO `wp_model_sub_service` VALUES (229, '77', 'En Boutique', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (230, '77', 'Par courrier', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (231, '77', 'Technicien ÃƒÂ  domicile', '168,00'); 
INSERT INTO `wp_model_sub_service` VALUES (232, '78', 'En Boutique', '209,00'); 
INSERT INTO `wp_model_sub_service` VALUES (233, '78', 'Par courrier', '209,00'); 
INSERT INTO `wp_model_sub_service` VALUES (234, '78', 'Technicien ÃƒÂ  domicile', '278,00'); 
INSERT INTO `wp_model_sub_service` VALUES (238, '80', 'En Boutique', '159,00'); 
INSERT INTO `wp_model_sub_service` VALUES (239, '80', 'Par courrier', '159,00'); 
INSERT INTO `wp_model_sub_service` VALUES (240, '80', 'Technicien ÃƒÂ  domicile', '178,00'); 
INSERT INTO `wp_model_sub_service` VALUES (241, '81', 'En Boutique', '59,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (242, '81', 'Par courrier', '59,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (243, '81', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (244, '82', 'En Boutique', '229,00'); 
INSERT INTO `wp_model_sub_service` VALUES (245, '82', 'Par courrier', '229,00'); 
INSERT INTO `wp_model_sub_service` VALUES (246, '82', 'Technicien ÃƒÂ  domicile', '248,00'); 
INSERT INTO `wp_model_sub_service` VALUES (247, '83', 'En Boutique', '229,00'); 
INSERT INTO `wp_model_sub_service` VALUES (248, '83', 'Par courrier', '229,00'); 
INSERT INTO `wp_model_sub_service` VALUES (249, '83', 'Technicien ÃƒÂ  domicile', '248,00'); 
INSERT INTO `wp_model_sub_service` VALUES (250, '84', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (251, '84', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (252, '84', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (253, '85', 'En Boutique', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (254, '85', 'Par courrier', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (255, '85', 'Technicien ÃƒÂ  domicile', '148,00'); 
INSERT INTO `wp_model_sub_service` VALUES (256, '86', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (257, '86', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (258, '86', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (259, '87', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (260, '87', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (261, '87', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (262, '88', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (263, '88', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (264, '88', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (265, '89', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (266, '89', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (267, '89', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (268, '90', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (269, '90', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (270, '90', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (271, '91', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (272, '91', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (273, '91', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (274, '92', 'En Boutique', '10,00'); 
INSERT INTO `wp_model_sub_service` VALUES (275, '92', 'Par courrier', '10,00'); 
INSERT INTO `wp_model_sub_service` VALUES (276, '92', 'Technicien ÃƒÂ  domicile', '29,00'); 
INSERT INTO `wp_model_sub_service` VALUES (277, '93', 'En Boutique', '10,00'); 
INSERT INTO `wp_model_sub_service` VALUES (278, '93', 'Par courrier', '10,00'); 
INSERT INTO `wp_model_sub_service` VALUES (279, '93', 'Technicien ÃƒÂ  domicile', '29,00'); 
INSERT INTO `wp_model_sub_service` VALUES (280, '94', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (281, '94', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (282, '94', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (283, '95', 'En Boutique', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (284, '95', 'Par courrier', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (285, '95', 'Technicien ÃƒÂ  domicile', '218,00'); 
INSERT INTO `wp_model_sub_service` VALUES (286, '96', 'En Boutique', '199,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (287, '96', 'Par courrier', '199,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (288, '96', 'Technicien ÃƒÂ  domicile', '218,00'); 
INSERT INTO `wp_model_sub_service` VALUES (289, '97', 'En Boutique', '59,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (290, '97', 'Par courrier', '59,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (291, '97', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (292, '98', 'En Boutique', '49,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (293, '98', 'Par courrier', '49,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (294, '98', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (295, '99', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (296, '99', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (297, '99', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (298, '100', 'En Boutique', '69,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (299, '100', 'Par courrier', '69,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (300, '100', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (301, '101', 'En Boutique', '89,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (302, '101', 'Par courrier', '89,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (303, '101', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (304, '102', 'En Boutique', '79,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (305, '102', 'Par courrier', '79,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (306, '102', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (307, '103', 'En Boutique', '59,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (308, '103', 'Par courrier', '59,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (310, '104', 'En Boutique', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (311, '104', 'Par courrier', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (312, '104', 'Technicien ÃƒÂ  domicile', '218,00'); 
INSERT INTO `wp_model_sub_service` VALUES (313, '105', 'En Boutique', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (314, '105', 'Par courrier', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (315, '105', 'Technicien ÃƒÂ  domicile', '158,00'); 
INSERT INTO `wp_model_sub_service` VALUES (316, '106', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (317, '106', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (318, '106', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (319, '107', 'En Boutique', '59,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (320, '107', 'Par courrier', '59,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (321, '107', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (322, '108', 'En Boutique', '199,00'); 
INSERT INTO `wp_model_sub_service` VALUES (323, '108', 'Par courrier', '199,00'); 
INSERT INTO `wp_model_sub_service` VALUES (324, '108', 'Technicien ÃƒÂ  domicile', '218,00'); 
INSERT INTO `wp_model_sub_service` VALUES (325, '109', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (326, '109', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (327, '109', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (328, '110', 'En Boutique', '159,00'); 
INSERT INTO `wp_model_sub_service` VALUES (329, '110', 'Par courrier', '159,00'); 
INSERT INTO `wp_model_sub_service` VALUES (330, '110', 'Technicien ÃƒÂ  domicile', '238,00'); 
INSERT INTO `wp_model_sub_service` VALUES (331, '111', 'En Boutique', '289,00'); 
INSERT INTO `wp_model_sub_service` VALUES (332, '111', 'Par courrier', '289,00'); 
INSERT INTO `wp_model_sub_service` VALUES (333, '111', 'Technicien ÃƒÂ  domicile', '308,00'); 
INSERT INTO `wp_model_sub_service` VALUES (334, '112', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (335, '112', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (336, '112', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (337, '113', 'En Boutique', '289,00'); 
INSERT INTO `wp_model_sub_service` VALUES (338, '113', 'Par courrier', '289,00'); 
INSERT INTO `wp_model_sub_service` VALUES (339, '113', 'Technicien ÃƒÂ  domicile', '308,00'); 
INSERT INTO `wp_model_sub_service` VALUES (340, '114', 'En Boutique', '20,00'); 
INSERT INTO `wp_model_sub_service` VALUES (341, '114', 'Par courrier', '20,00'); 
INSERT INTO `wp_model_sub_service` VALUES (342, '114', 'Technicien ÃƒÂ  domicile', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (343, '115', 'En Boutique', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (344, '115', 'Par courrier', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (345, '115', 'Technicien ÃƒÂ  domicile', '168,00'); 
INSERT INTO `wp_model_sub_service` VALUES (346, '116', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (347, '116', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (348, '116', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (349, '117', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (350, '117', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (351, '117', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (352, '118', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (353, '118', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (354, '118', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (355, '119', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (356, '119', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (357, '119', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (358, '120', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (359, '120', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (360, '120', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (361, '121', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (362, '121', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (363, '121', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (364, '122', 'En Boutique', '10,00'); 
INSERT INTO `wp_model_sub_service` VALUES (365, '122', 'Par courrier', '10,00'); 
INSERT INTO `wp_model_sub_service` VALUES (366, '122', 'Technicien ÃƒÂ  domicile', '29,00'); 
INSERT INTO `wp_model_sub_service` VALUES (367, '123', 'En Boutique', '10,00'); 
INSERT INTO `wp_model_sub_service` VALUES (368, '123', 'Par courrier', '10,00'); 
INSERT INTO `wp_model_sub_service` VALUES (369, '123', 'Technicien ÃƒÂ  domicile', '29,00'); 
INSERT INTO `wp_model_sub_service` VALUES (370, '124', 'En Boutique', '59,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (371, '124', 'Par courrier', '59,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (372, '124', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (373, '125', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (374, '125', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (375, '125', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (376, '126', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (377, '126', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (378, '126', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (379, '127', 'En Boutique', '229,00'); 
INSERT INTO `wp_model_sub_service` VALUES (380, '127', 'Par courrier', '229,00'); 
INSERT INTO `wp_model_sub_service` VALUES (381, '127', 'Technicien ÃƒÂ  domicile', '248,00'); 
INSERT INTO `wp_model_sub_service` VALUES (382, '128', 'En Boutique', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (383, '128', 'Par courrier', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (385, '129', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (386, '129', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (387, '129', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (388, '130', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (389, '130', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (390, '130', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (391, '131', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (392, '131', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (393, '131', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (394, '132', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (395, '132', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (396, '132', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (397, '133', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (398, '133', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (399, '133', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (400, '134', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (401, '134', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (402, '134', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (403, '135', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (404, '135', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (405, '135', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (406, '136', 'En Boutique', '199,00'); 
INSERT INTO `wp_model_sub_service` VALUES (407, '136', 'Par courrier', '199,00'); 
INSERT INTO `wp_model_sub_service` VALUES (408, '136', 'Technicien ÃƒÂ  domicile', '288,00'); 
INSERT INTO `wp_model_sub_service` VALUES (409, '137', 'En Boutique', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (410, '137', 'Par courrier', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (411, '137', 'Technicien ÃƒÂ  domicile', '118,00'); 
INSERT INTO `wp_model_sub_service` VALUES (412, '138', 'En Boutique', '269,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (413, '138', 'Par courrier', '269,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (414, '138', 'Technicien ÃƒÂ  domicile', '288,00'); 
INSERT INTO `wp_model_sub_service` VALUES (415, '139', 'En Boutique', '20,00'); 
INSERT INTO `wp_model_sub_service` VALUES (416, '139', 'Par courrier', '20,00'); 
INSERT INTO `wp_model_sub_service` VALUES (417, '139', 'Technicien ÃƒÂ  domicile', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (418, '140', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (419, '140', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (420, '140', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (421, '141', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (422, '141', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (423, '141', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (424, '142', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (425, '142', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (426, '142', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (427, '143', 'En Boutique', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (428, '143', 'Par courrier', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (429, '143', 'Technicien ÃƒÂ  domicile', '118,00'); 
INSERT INTO `wp_model_sub_service` VALUES (430, '144', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (431, '144', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (432, '144', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (433, '145', 'En Boutique', '25,00'); 
INSERT INTO `wp_model_sub_service` VALUES (434, '145', 'Par courrier', '25,00'); 
INSERT INTO `wp_model_sub_service` VALUES (435, '145', 'Technicien ÃƒÂ  domicile', '44,00'); 
INSERT INTO `wp_model_sub_service` VALUES (436, '146', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (437, '146', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (438, '146', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (439, '147', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (440, '147', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (441, '147', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (442, '148', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (443, '148', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (444, '148', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (445, '149', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (446, '149', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (447, '149', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (448, '150', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (449, '150', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (450, '150', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (451, '151', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (452, '151', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (453, '151', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (454, '152', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (455, '152', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (456, '152', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (457, '153', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (458, '153', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (459, '153', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (460, '154', 'En Boutique', '219,00'); 
INSERT INTO `wp_model_sub_service` VALUES (461, '154', 'Par courrier', '219,00'); 
INSERT INTO `wp_model_sub_service` VALUES (462, '154', 'Technicien ÃƒÂ  domicile', '238,00'); 
INSERT INTO `wp_model_sub_service` VALUES (463, '155', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (464, '155', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (465, '155', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (466, '156', 'En Boutique', '219,00'); 
INSERT INTO `wp_model_sub_service` VALUES (467, '156', 'Par courrier', '219,00'); 
INSERT INTO `wp_model_sub_service` VALUES (468, '156', 'Technicien ÃƒÂ  domicile', '238,00'); 
INSERT INTO `wp_model_sub_service` VALUES (469, '157', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (470, '157', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (471, '157', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (472, '158', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (473, '158', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (474, '158', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (475, '159', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (476, '159', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (477, '159', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (478, '160', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (479, '160', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (480, '160', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (481, '161', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (482, '161', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (483, '161', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (484, '162', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (485, '162', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (486, '162', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (487, '163', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (488, '163', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (489, '163', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (490, '164', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (491, '164', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (492, '164', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (493, '165', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (494, '165', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (495, '165', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (496, '166', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (497, '166', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (498, '166', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (499, '167', 'En Boutique', '159,00'); 
INSERT INTO `wp_model_sub_service` VALUES (500, '167', 'Par courrier', '159,00'); 
INSERT INTO `wp_model_sub_service` VALUES (501, '167', 'Technicien ÃƒÂ  domicile', '178,00'); 
INSERT INTO `wp_model_sub_service` VALUES (502, '168', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (503, '168', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (504, '168', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (505, '169', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (506, '169', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (507, '169', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (508, '170', 'En Boutique', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (509, '170', 'Par courrier', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (510, '170', 'Technicien ÃƒÂ  domicile', '118,00'); 
INSERT INTO `wp_model_sub_service` VALUES (511, '171', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (512, '171', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (513, '171', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (514, '172', 'En Boutique', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (515, '172', 'Par courrier', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (516, '172', 'Technicien ÃƒÂ  domicile', '148,00'); 
INSERT INTO `wp_model_sub_service` VALUES (517, '173', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (518, '173', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (519, '173', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (520, '174', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (521, '174', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (522, '174', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (523, '175', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (524, '175', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (525, '175', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (526, '176', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (527, '176', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (528, '176', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (529, '177', 'En Boutique', '169,00'); 
INSERT INTO `wp_model_sub_service` VALUES (530, '177', 'Par courrier', '169,00'); 
INSERT INTO `wp_model_sub_service` VALUES (531, '177', 'Technicien ÃƒÂ  domicile', '188,00'); 
INSERT INTO `wp_model_sub_service` VALUES (532, '178', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (533, '178', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (534, '178', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (535, '179', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (536, '179', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (537, '179', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (538, '180', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (539, '180', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (540, '180', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (541, '181', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (542, '181', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (543, '181', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (544, '182', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (545, '182', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (546, '182', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (547, '183', 'En Boutique', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (548, '183', 'Par courrier', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (549, '183', 'Technicien ÃƒÂ  domicile', '118,00'); 
INSERT INTO `wp_model_sub_service` VALUES (550, '184', 'En Boutique', '119,00'); 
INSERT INTO `wp_model_sub_service` VALUES (551, '184', 'Par courrier', '119,00'); 
INSERT INTO `wp_model_sub_service` VALUES (552, '184', 'Technicien ÃƒÂ  domicile', '138,00'); 
INSERT INTO `wp_model_sub_service` VALUES (553, '185', 'En Boutique', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (554, '185', 'Par courrier', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (555, '185', 'Technicien ÃƒÂ  domicile', '168,00'); 
INSERT INTO `wp_model_sub_service` VALUES (556, '186', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (557, '186', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (558, '186', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (559, '187', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (560, '187', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (561, '187', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (562, '188', 'En Boutique', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (563, '188', 'Par courrier', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (564, '188', 'Technicien ÃƒÂ  domicile', '128,00'); 
INSERT INTO `wp_model_sub_service` VALUES (565, '189', 'En Boutique', '20,00'); 
INSERT INTO `wp_model_sub_service` VALUES (566, '189', 'Par courrier', '20,00'); 
INSERT INTO `wp_model_sub_service` VALUES (567, '189', 'Technicien ÃƒÂ  domicile', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (568, '190', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (569, '190', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (570, '190', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (571, '191', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (572, '191', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (573, '191', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (574, '192', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (575, '192', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (576, '192', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (577, '193', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (578, '193', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (579, '193', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (580, '194', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (581, '194', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (582, '194', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (583, '195', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (584, '195', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (585, '195', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (586, '196', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (587, '196', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (588, '196', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (589, '197', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (590, '197', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (591, '197', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (592, '198', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (593, '198', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (594, '198', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (595, '199', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (596, '199', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (597, '199', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (598, '200', 'En Boutique', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (599, '200', 'Par courrier', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (600, '200', 'Technicien ÃƒÂ  domicile', '118,00'); 
INSERT INTO `wp_model_sub_service` VALUES (601, '201', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (602, '201', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (603, '201', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (604, '202', 'En Boutique', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (605, '202', 'Par courrier', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (606, '202', 'Technicien ÃƒÂ  domicile', '128,00'); 
INSERT INTO `wp_model_sub_service` VALUES (607, '203', 'En Boutique', '119,00'); 
INSERT INTO `wp_model_sub_service` VALUES (608, '203', 'Par courrier', '119,00'); 
INSERT INTO `wp_model_sub_service` VALUES (609, '203', 'Technicien ÃƒÂ  domicile', '138,00'); 
INSERT INTO `wp_model_sub_service` VALUES (610, '204', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (611, '204', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (612, '204', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (613, '205', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (614, '205', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (615, '205', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (616, '206', 'En Boutique', '119,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (617, '206', 'Par courrier', '119,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (618, '206', 'Technicien ÃƒÂ  domicile', '138,00'); 
INSERT INTO `wp_model_sub_service` VALUES (619, '207', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (620, '207', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (621, '207', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (622, '208', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (623, '208', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (624, '208', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (625, '209', 'En Boutique', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (626, '209', 'Par courrier', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (627, '209', 'Technicien ÃƒÂ  domicile', '168,00'); 
INSERT INTO `wp_model_sub_service` VALUES (628, '210', 'En Boutique', '299,00'); 
INSERT INTO `wp_model_sub_service` VALUES (629, '210', 'Par courrier', '299,00'); 
INSERT INTO `wp_model_sub_service` VALUES (630, '210', 'Technicien ÃƒÂ  domicile', '318,00'); 
INSERT INTO `wp_model_sub_service` VALUES (631, '211', 'En Boutique', '149,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (632, '211', 'Par courrier', '149,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (633, '211', 'Technicien ÃƒÂ  domicile', '168,00'); 
INSERT INTO `wp_model_sub_service` VALUES (634, '212', 'En Boutique', '299,00'); 
INSERT INTO `wp_model_sub_service` VALUES (635, '212', 'Par courrier', '299,00'); 
INSERT INTO `wp_model_sub_service` VALUES (636, '212', 'Technicien ÃƒÂ  domicile', '318,00'); 
INSERT INTO `wp_model_sub_service` VALUES (637, '213', 'En Boutique', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (638, '213', 'Par courrier', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (639, '213', 'Technicien ÃƒÂ  domicile', '118,00'); 
INSERT INTO `wp_model_sub_service` VALUES (640, '214', 'En Boutique', '399,00'); 
INSERT INTO `wp_model_sub_service` VALUES (641, '214', 'Par courrier', '399,00'); 
INSERT INTO `wp_model_sub_service` VALUES (642, '214', 'Technicien ÃƒÂ  domicile', '418,00'); 
INSERT INTO `wp_model_sub_service` VALUES (643, '215', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (644, '215', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (645, '215', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (646, '216', 'En Boutique', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (647, '216', 'Par courrier', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (648, '216', 'Technicien ÃƒÂ  domicile', '148,00'); 
INSERT INTO `wp_model_sub_service` VALUES (649, '217', 'En Boutique', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (650, '217', 'Par courrier', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (651, '217', 'Technicien ÃƒÂ  domicile', '148,00'); 
INSERT INTO `wp_model_sub_service` VALUES (652, '218', 'En Boutique', '139,00'); 
INSERT INTO `wp_model_sub_service` VALUES (653, '218', 'Par courrier', '139,00'); 
INSERT INTO `wp_model_sub_service` VALUES (654, '218', 'Technicien ÃƒÂ  domicile', '158,00'); 
INSERT INTO `wp_model_sub_service` VALUES (655, '219', 'En Boutique', '129,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (656, '219', 'Par courrier', '129,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (657, '219', 'Technicien ÃƒÂ  domicile', '148,00'); 
INSERT INTO `wp_model_sub_service` VALUES (658, '220', 'En Boutique', '199,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (659, '220', 'Par courrier', '199,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (660, '220', 'Technicien ÃƒÂ  domicile', '218,00'); 
INSERT INTO `wp_model_sub_service` VALUES (661, '221', 'En Boutique', '189,00'); 
INSERT INTO `wp_model_sub_service` VALUES (662, '221', 'Par courrier', '189,00'); 
INSERT INTO `wp_model_sub_service` VALUES (663, '221', 'Technicien ÃƒÂ  domicile', '208,00'); 
INSERT INTO `wp_model_sub_service` VALUES (664, '222', 'En Boutique', '299,00'); 
INSERT INTO `wp_model_sub_service` VALUES (665, '222', 'Par courrier', '299,00'); 
INSERT INTO `wp_model_sub_service` VALUES (666, '222', 'Technicien ÃƒÂ  domicile', '318,00'); 
INSERT INTO `wp_model_sub_service` VALUES (667, '223', 'En Boutique', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (668, '223', 'Par courrier', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (669, '223', 'Technicien ÃƒÂ  domicile', '118,00'); 
INSERT INTO `wp_model_sub_service` VALUES (670, '224', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (671, '224', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (672, '224', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (673, '225', 'En Boutique', '239,00'); 
INSERT INTO `wp_model_sub_service` VALUES (674, '225', 'Par courrier', '239,00'); 
INSERT INTO `wp_model_sub_service` VALUES (675, '225', 'Technicien ÃƒÂ  domicile', '258,00'); 
INSERT INTO `wp_model_sub_service` VALUES (676, '226', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (677, '226', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (678, '226', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (679, '227', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (680, '227', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (681, '227', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (682, '228', 'En Boutique', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (683, '228', 'Par courrier', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (684, '228', 'Technicien ÃƒÂ  domicile', '128,00'); 
INSERT INTO `wp_model_sub_service` VALUES (685, '229', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (686, '229', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (687, '229', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (688, '230', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (689, '230', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (690, '230', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (691, '231', 'En Boutique', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (692, '231', 'Par courrier', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (693, '231', 'Technicien ÃƒÂ  domicile', '148,00'); 
INSERT INTO `wp_model_sub_service` VALUES (694, '232', 'En Boutique', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (695, '232', 'Par courrier', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (696, '232', 'Technicien ÃƒÂ  domicile', '128,00'); 
INSERT INTO `wp_model_sub_service` VALUES (697, '233', 'En Boutique', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (698, '233', 'Par courrier', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (699, '233', 'Technicien ÃƒÂ  domicile', '148,00'); 
INSERT INTO `wp_model_sub_service` VALUES (700, '234', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (701, '234', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (702, '234', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (703, '235', 'En Boutique', '299,00'); 
INSERT INTO `wp_model_sub_service` VALUES (704, '235', 'Par courrier', '299,00'); 
INSERT INTO `wp_model_sub_service` VALUES (705, '235', 'Technicien ÃƒÂ  domicile', '318,00'); 
INSERT INTO `wp_model_sub_service` VALUES (706, '236', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (707, '236', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (708, '236', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (709, '237', 'En Boutique', '399,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (710, '237', 'Par courrier', '399,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (711, '237', 'Technicien ÃƒÂ  domicile', '418,00'); 
INSERT INTO `wp_model_sub_service` VALUES (712, '238', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (713, '238', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (714, '238', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (715, '239', 'En Boutique', '119,00'); 
INSERT INTO `wp_model_sub_service` VALUES (716, '239', 'Par courrier', '119,00'); 
INSERT INTO `wp_model_sub_service` VALUES (717, '239', 'Technicien ÃƒÂ  domicile', '138,00'); 
INSERT INTO `wp_model_sub_service` VALUES (718, '240', 'En Boutique', '119,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (719, '240', 'Par courrier', '119,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (720, '240', 'Technicien ÃƒÂ  domicile', '138,00'); 
INSERT INTO `wp_model_sub_service` VALUES (721, '241', 'En Boutique', '159,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (722, '241', 'Par courrier', '159,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (723, '241', 'Technicien ÃƒÂ  domicile', '178,00'); 
INSERT INTO `wp_model_sub_service` VALUES (724, '242', 'En Boutique', '229,00'); 
INSERT INTO `wp_model_sub_service` VALUES (725, '242', 'Par courrier', '229,00'); 
INSERT INTO `wp_model_sub_service` VALUES (726, '242', 'Technicien ÃƒÂ  domicile', '248,00'); 
INSERT INTO `wp_model_sub_service` VALUES (727, '243', 'En Boutique', '89,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (728, '243', 'Par courrier', '89,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (729, '243', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (730, '245', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (731, '245', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (732, '245', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (733, '246', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (734, '246', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (735, '246', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (736, '247', 'En Boutique', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (737, '247', 'Par courrier', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (738, '247', 'Technicien ÃƒÂ  domicile', '128,00'); 
INSERT INTO `wp_model_sub_service` VALUES (739, '248', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (740, '248', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (741, '248', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (742, '249', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (743, '249', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (744, '249', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (745, '250', 'En Boutique', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (746, '250', 'Par courrier', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (747, '250', 'Technicien ÃƒÂ  domicile', '118,00'); 
INSERT INTO `wp_model_sub_service` VALUES (748, '251', 'En Boutique', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (749, '251', 'Par courrier', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (750, '251', 'Technicien ÃƒÂ  domicile', '118,00'); 
INSERT INTO `wp_model_sub_service` VALUES (751, '252', 'En Boutique', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (752, '252', 'Par courrier', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (753, '252', 'Technicien ÃƒÂ  domicile', '118,00'); 
INSERT INTO `wp_model_sub_service` VALUES (754, '253', 'En Boutique', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (755, '253', 'Par courrier', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (756, '253', 'Technicien ÃƒÂ  domicile', '168,00'); 
INSERT INTO `wp_model_sub_service` VALUES (757, '254', 'En Boutique', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (758, '254', 'Par courrier', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (759, '254', 'Technicien ÃƒÂ  domicile', '168,00'); 
INSERT INTO `wp_model_sub_service` VALUES (760, '255', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (761, '255', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (762, '255', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (763, '256', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (764, '256', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (765, '256', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (766, '257', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (767, '257', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (768, '257', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (769, '258', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (770, '258', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (771, '258', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (772, '259', 'En Boutique', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (773, '259', 'Par courrier', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (774, '259', 'Technicien ÃƒÂ  domicile', '128,00'); 
INSERT INTO `wp_model_sub_service` VALUES (775, '260', 'En Boutique', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (776, '260', 'Par courrier', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (777, '260', 'Technicien ÃƒÂ  domicile', '128,00'); 
INSERT INTO `wp_model_sub_service` VALUES (778, '261', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (779, '261', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (780, '261', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (781, '262', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (782, '262', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (783, '262', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (784, '263', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (785, '263', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (786, '263', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (787, '264', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (788, '264', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (789, '264', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (790, '265', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (791, '265', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (792, '265', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (793, '266', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (794, '266', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (795, '266', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (796, '267', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (797, '267', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (798, '267', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (799, '268', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (800, '268', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (801, '268', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (802, '269', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (803, '269', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (804, '269', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (805, '270', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (806, '270', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (807, '270', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (808, '271', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (809, '271', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (810, '271', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (811, '272', 'En Boutique', '109,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (812, '272', 'Par courrier', '109,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (813, '272', 'Technicien ÃƒÂ  domicile', '128,00'); 
INSERT INTO `wp_model_sub_service` VALUES (814, '273', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (815, '273', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (816, '273', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (817, '274', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (818, '274', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (819, '274', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (820, '275', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (821, '275', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (822, '275', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (823, '276', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (824, '276', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (825, '276', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (826, '277', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (827, '277', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (828, '277', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (829, '278', 'En Boutique', '59,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (830, '278', 'Par courrier', '59,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (831, '278', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (832, '279', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (833, '279', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (834, '279', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (835, '280', 'En Boutique', '229,00'); 
INSERT INTO `wp_model_sub_service` VALUES (836, '280', 'Par courrier', '229,00'); 
INSERT INTO `wp_model_sub_service` VALUES (837, '280', 'Technicien ÃƒÂ  domicile', '248,00'); 
INSERT INTO `wp_model_sub_service` VALUES (838, '281', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (839, '281', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (840, '281', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (841, '282', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (842, '282', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (843, '282', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (844, '284', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (845, '284', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (846, '284', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (847, '285', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (848, '285', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (849, '285', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (850, '286', 'En Boutique', '119,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (851, '286', 'Par courrier', '119,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (852, '286', 'Technicien ÃƒÂ  domicile', '138,00'); 
INSERT INTO `wp_model_sub_service` VALUES (853, '287', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (854, '287', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (855, '287', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (856, '288', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (857, '288', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (858, '288', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (859, '289', 'En Boutique', '79,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (860, '289', 'Par courrier', '79,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (861, '289', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (862, '290', 'En Boutique', '79,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (863, '290', 'Par courrier', '79,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (864, '290', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (865, '291', 'En Boutique', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (866, '291', 'Par courrier', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (867, '291', 'Technicien ÃƒÂ  domicile', '118,00'); 
INSERT INTO `wp_model_sub_service` VALUES (868, '292', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (869, '292', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (870, '292', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (871, '293', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (872, '293', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (873, '293', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (874, '294', 'En Boutique', '179,00'); 
INSERT INTO `wp_model_sub_service` VALUES (875, '294', 'Par courrier', '179,00'); 
INSERT INTO `wp_model_sub_service` VALUES (876, '294', 'Technicien ÃƒÂ  domicile', '198,00'); 
INSERT INTO `wp_model_sub_service` VALUES (877, '295', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (878, '295', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (879, '295', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (880, '296', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (881, '296', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (882, '296', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (883, '297', 'En Boutique', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (884, '297', 'Par courrier', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (885, '297', 'Technicien ÃƒÂ  domicile', '128,00'); 
INSERT INTO `wp_model_sub_service` VALUES (886, '298', 'En Boutique', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (887, '298', 'Par courrier', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (888, '298', 'Technicien ÃƒÂ  domicile', '118,00'); 
INSERT INTO `wp_model_sub_service` VALUES (889, '299', 'En Boutique', '169,00'); 
INSERT INTO `wp_model_sub_service` VALUES (890, '299', 'Par courrier', '169,00'); 
INSERT INTO `wp_model_sub_service` VALUES (891, '299', 'Technicien ÃƒÂ  domicile', '188,00'); 
INSERT INTO `wp_model_sub_service` VALUES (892, '300', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (893, '300', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (894, '300', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (895, '301', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (896, '301', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (897, '301', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (898, '302', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (899, '302', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (900, '302', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (901, '303', 'En Boutique', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (902, '303', 'Par courrier', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (903, '303', 'Technicien ÃƒÂ  domicile', '168,00'); 
INSERT INTO `wp_model_sub_service` VALUES (904, '304', 'En Boutique', '199,00'); 
INSERT INTO `wp_model_sub_service` VALUES (905, '304', 'Par courrier', '199,00'); 
INSERT INTO `wp_model_sub_service` VALUES (906, '304', 'Technicien ÃƒÂ  domicile', '218,00'); 
INSERT INTO `wp_model_sub_service` VALUES (907, '305', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (908, '305', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (909, '305', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (910, '306', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (911, '306', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (912, '306', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (913, '307', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (914, '307', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (915, '307', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (916, '308', 'En Boutique', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (917, '308', 'Par courrier', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (918, '308', 'Technicien ÃƒÂ  domicile', '128,00'); 
INSERT INTO `wp_model_sub_service` VALUES (919, '309', 'En Boutique', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (920, '309', 'Par courrier', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (921, '309', 'Technicien ÃƒÂ  domicile', '168,00'); 
INSERT INTO `wp_model_sub_service` VALUES (922, '310', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (923, '310', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (924, '310', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (925, '311', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (926, '311', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (927, '311', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (928, '312', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (929, '312', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (930, '312', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (931, '313', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (932, '313', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (933, '313', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (934, '314', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (935, '314', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (936, '314', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (937, '315', 'En Boutique', '119,00'); 
INSERT INTO `wp_model_sub_service` VALUES (938, '315', 'Par courrier', '119,00'); 
INSERT INTO `wp_model_sub_service` VALUES (939, '315', 'Technicien ÃƒÂ  domicile', '138,00'); 
INSERT INTO `wp_model_sub_service` VALUES (940, '316', 'En Boutique', '169,00'); 
INSERT INTO `wp_model_sub_service` VALUES (941, '316', 'Par courrier', '169,00'); 
INSERT INTO `wp_model_sub_service` VALUES (942, '316', 'Technicien ÃƒÂ  domicile', '188,00'); 
INSERT INTO `wp_model_sub_service` VALUES (943, '317', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (944, '317', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (945, '317', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (946, '318', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (947, '318', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (948, '318', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (949, '319', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (950, '319', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (951, '319', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (952, '320', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (953, '320', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (954, '320', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (955, '321', 'En Boutique', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (956, '321', 'Par courrier', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (957, '321', 'Technicien ÃƒÂ  domicile', '128,00'); 
INSERT INTO `wp_model_sub_service` VALUES (958, '322', 'En Boutique', '169,00'); 
INSERT INTO `wp_model_sub_service` VALUES (959, '322', 'Par courrier', '169,00'); 
INSERT INTO `wp_model_sub_service` VALUES (960, '322', 'Technicien ÃƒÂ  domicile', '188,00'); 
INSERT INTO `wp_model_sub_service` VALUES (961, '323', 'En Boutique', '49,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (962, '323', 'Par courrier', '49,00	'); 
INSERT INTO `wp_model_sub_service` VALUES (963, '323', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (964, '324', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (965, '324', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (966, '324', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (967, '325', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (968, '325', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (969, '325', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (970, '326', 'En Boutique', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (971, '326', 'Par courrier', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (972, '326', 'Technicien ÃƒÂ  domicile', '148,00'); 
INSERT INTO `wp_model_sub_service` VALUES (973, '327', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (974, '327', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (975, '327', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (976, '328', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (977, '328', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (978, '328', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (979, '329', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (980, '329', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (981, '329', 'Technicien ÃƒÂ  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (982, '330', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (983, '330', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (984, '330', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (985, '331', 'En Boutique', '119,00'); 
INSERT INTO `wp_model_sub_service` VALUES (986, '331', 'Par courrier', '119,00'); 
INSERT INTO `wp_model_sub_service` VALUES (987, '331', 'Technicien ÃƒÂ  domicile', '138,00'); 
INSERT INTO `wp_model_sub_service` VALUES (988, '332', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (989, '332', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (990, '332', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (991, '333', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (992, '333', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (993, '333', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (994, '334', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (995, '334', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (996, '334', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (997, '335', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (998, '335', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (999, '335', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1000, '336', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1001, '336', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1002, '336', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1003, '337', 'En Boutique', '119,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1004, '337', 'Par courrier', '119,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1005, '337', 'Technicien ÃƒÂ  domicile', '138,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1006, '338', 'En Boutique', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1007, '338', 'Par courrier', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1008, '338', 'Technicien ÃƒÂ  domicile', '118,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1009, '339', 'En Boutique', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1010, '339', 'Par courrier', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1011, '339', 'Technicien ÃƒÂ  domicile', '128,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1012, '340', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1013, '340', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1014, '340', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1015, '341', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1016, '341', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1017, '341', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1018, '342', 'En Boutique', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1019, '342', 'Par courrier', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1020, '342', 'Technicien ÃƒÂ  domicile', '148,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1021, '343', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1022, '343', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1023, '343', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1024, '344', 'En Boutique', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1025, '344', 'Par courrier', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1026, '344', 'Technicien ÃƒÂ  domicile', '148,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1027, '345', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1028, '345', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1029, '345', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1030, '346', 'En Boutique', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1031, '346', 'Par courrier', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1032, '346', 'Technicien ÃƒÂ  domicile', '128,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1033, '347', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1034, '347', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1035, '347', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1036, '348', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1037, '348', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1038, '348', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1039, '349', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1040, '349', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1041, '349', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1042, '350', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1043, '350', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1044, '350', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1045, '351', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1046, '351', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1047, '351', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1048, '352', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1049, '352', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1050, '352', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1051, '353', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1052, '353', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1053, '353', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1054, '354', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1055, '354', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1056, '354', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1057, '355', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1058, '355', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1059, '355', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1060, '356', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1061, '356', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1062, '356', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1063, '357', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1064, '357', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1065, '357', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1066, '358', 'En Boutique', '199,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1067, '358', 'Par courrier', '199,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1068, '358', 'Technicien ÃƒÂ  domicile', '218,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1069, '359', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1070, '359', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1071, '359', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1072, '360', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1073, '360', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1074, '360', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1075, '361', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1076, '361', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1077, '361', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1078, '362', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1079, '362', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1080, '362', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1081, '363', 'En Boutique', '269,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1082, '363', 'Par courrier', '269,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1083, '363', 'Technicien ÃƒÂ  domicile', '288,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1084, '364', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1085, '364', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1086, '364', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1087, '365', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1088, '365', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1089, '365', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1090, '366', 'En Boutique', '159,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1091, '366', 'Par courrier', '159,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1092, '366', 'Technicien ÃƒÂ  domicile', '178,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1093, '367', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1094, '367', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1095, '367', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1096, '368', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1097, '368', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1098, '368', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1099, '369', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1100, '369', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1101, '369', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1102, '370', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1103, '370', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1104, '370', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1105, '371', 'En Boutique', '139,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1106, '371', 'Par courrier', '139,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1107, '371', 'Technicien ÃƒÂ  domicile', '158,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1108, '372', 'En Boutique', '159,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1109, '372', 'Par courrier', '159,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1110, '372', 'Technicien ÃƒÂ  domicile', '188,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1111, '373', 'En Boutique', '169,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1112, '373', 'Par courrier', '169,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1113, '373', 'Technicien ÃƒÂ  domicile', '188,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1114, '374', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1115, '374', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1116, '374', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1117, '375', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1118, '375', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1119, '375', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1120, '376', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1121, '376', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1122, '376', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1123, '377', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1124, '377', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1125, '377', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1126, '378', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1127, '378', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1128, '378', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1129, '379', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1130, '379', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1131, '379', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1132, '380', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1133, '380', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1134, '380', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1135, '381', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1136, '381', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1137, '381', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1138, '382', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1139, '382', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1140, '382', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1141, '383', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1142, '383', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1143, '383', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1144, '384', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1145, '384', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1146, '384', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1147, '385', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1148, '385', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1149, '385', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1150, '386', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1151, '386', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1152, '386', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1153, '387', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1154, '387', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1155, '387', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1156, '388', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1157, '388', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1158, '388', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1159, '389', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1160, '389', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1161, '389', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1162, '390', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1163, '390', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1164, '390', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1165, '391', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1166, '391', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1167, '391', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1168, '392', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1169, '392', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1170, '392', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1171, '393', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1172, '393', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1173, '393', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1174, '394', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1175, '394', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1176, '394', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1177, '395', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1178, '395', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1179, '395', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1180, '396', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1181, '396', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1182, '396', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1183, '397', 'En Boutique', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1184, '397', 'Par courrier', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1185, '397', 'Technicien ÃƒÂ  domicile', '128,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1186, '398', 'En Boutique', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1187, '398', 'Par courrier', '109,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1188, '398', 'Technicien ÃƒÂ  domicile', '128,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1189, '399', 'En Boutique', '159,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1190, '399', 'Par courrier', '159,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1191, '399', 'Technicien ÃƒÂ  domicile', '178,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1192, '400', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1193, '400', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1194, '400', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1195, '401', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1196, '401', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1197, '401', 'Technicien ÃƒÂ  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1198, '402', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1199, '402', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1200, '402', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1201, '403', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1202, '403', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1203, '403', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1204, '404', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1205, '404', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1206, '404', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1207, '405', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1208, '405', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1209, '405', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1210, '406', 'En Boutique', '119,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1211, '406', 'Par courrier', '119,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1212, '406', 'Technicien ÃƒÂ  domicile', '138,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1213, '407', 'En Boutique', '159,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1214, '407', 'Par courrier', '159,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1215, '407', 'Technicien ÃƒÂ  domicile', '178,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1216, '408', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1217, '408', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1218, '408', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1219, '409', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1220, '409', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1221, '409', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1222, '410', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1223, '410', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1224, '410', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1225, '411', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1226, '411', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1227, '411', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1228, '412', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1229, '412', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1230, '412', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1231, '413', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1232, '413', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1233, '413', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1234, '414', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1235, '414', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1236, '414', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1237, '415', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1238, '415', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1239, '415', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1240, '416', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1241, '416', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1242, '416', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1243, '417', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1244, '417', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1245, '417', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1246, '418', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1247, '418', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1248, '418', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1249, '419', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1250, '419', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1251, '419', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1252, '420', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1253, '420', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1254, '420', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1255, '421', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1256, '421', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1257, '421', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1258, '422', 'En Boutique', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1259, '422', 'Par courrier', '89,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1260, '422', 'Technicien ÃƒÂ  domicile', '108,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1261, '423', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1262, '423', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1263, '423', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1264, '424', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1265, '424', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1266, '424', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1267, '425', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1268, '425', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1269, '425', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1270, '426', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1271, '426', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1272, '426', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1273, '427', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1274, '427', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1275, '427', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1276, '428', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1277, '428', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1278, '428', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1279, '429', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1280, '429', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1281, '429', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1282, '430', 'En Boutique', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1283, '430', 'Par courrier', '129,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1284, '430', 'Technicien ÃƒÂ  domicile', '148,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1285, '431', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1286, '431', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1287, '431', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1288, '432', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1289, '432', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1290, '432', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1291, '433', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1292, '433', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1293, '433', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1294, '434', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1295, '434', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1296, '434', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1297, '435', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1298, '435', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1299, '435', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1300, '436', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1301, '436', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1302, '436', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1303, '437', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1304, '437', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1305, '437', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1306, '438', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1307, '438', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1308, '438', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1309, '439', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1310, '439', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1311, '439', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1312, '440', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1313, '440', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1314, '440', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1315, '441', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1316, '441', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1317, '441', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1318, '442', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1319, '442', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1320, '442', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1321, '443', 'En Boutique', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1322, '443', 'Par courrier', '49,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1323, '443', 'Technicien ÃƒÂ  domicile', '68,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1324, '444', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1325, '444', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1326, '444', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1327, '445', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1328, '445', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1329, '445', 'Technicien ÃƒÂ  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1330, '2', 'Par courrier', '299,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1331, '2', 'Technicien ÃƒÂ  domicile', '318,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1332, '1', 'Par courrier', '159.00'); 
INSERT INTO `wp_model_sub_service` VALUES (1333, '1', 'En boutique', '159.00'); 
INSERT INTO `wp_model_sub_service` VALUES (1334, '446', 'En Boutique', '299,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1335, '446', 'Par courrier', '299,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1336, '447', 'En boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1337, '447', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1338, '448', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1339, '448', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1340, '449', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1341, '449', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1342, '450', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1343, '450', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1344, '451', 'En Boutique', '299,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1345, '451', 'Par courrier', '299,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1346, '452', 'En Boutique', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1347, '452', 'Par courrier', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1348, '453', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1349, '453', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1350, '454', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1351, '454', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1352, '455', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1353, '455', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1355, '456', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (1356, '456', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2001, '501', 'En Boutique', '139,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2002, '501', 'Par courrier', '139,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2003, '502', 'En boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2004, '502', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2005, '503', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2006, '503', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2007, '504', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2008, '504', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2009, '505', 'En Boutique', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2010, '505', 'Par courrier', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2011, '511', 'En Boutique', '249,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2012, '511', 'Par courrier', '249,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2013, '512', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2014, '512', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2015, '513', 'En Boutique', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2016, '513', 'Par courrier', '79,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2017, '514', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2018, '514', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2019, '515', 'En Boutique', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2020, '515', 'Par courrier', '39,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2021, '500', 'En Boutique', '249,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2022, '500', 'Par courrier', '249,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2023, '79', 'En Boutique', '119,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2024, '79', 'Par courrier', '119,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2030, '601', 'En Boutique', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2031, '601', 'Par courrier', '149,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2032, '602', 'En Boutique', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2033, '602', 'Par courrier', '99,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2034, '603', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2035, '603', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2036, '604', 'En Boutique', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2037, '604', 'Par courrier', '59,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2038, '605', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2039, '605', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2040, '606', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2041, '606', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2042, '607', 'En Boutique', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (2043, '607', 'Par courrier', '69,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3001, '3', 'Technicien ÃƒÂ?  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3002, '4', 'Technicien ÃƒÂ?  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3003, '1', 'Technicien ÃƒÂ?  domicile', '178,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3010, '103', 'Technicien ÃƒÂ?  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3011, '128', 'Technicien ÃƒÂ?  domicile', '148,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3012, '2', 'En boutique', '299,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3013, '446', 'Technicien ÃƒÂ?  domicile', '318,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3014, '447', 'Technicien ÃƒÂ?  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3015, '448', 'Technicien ÃƒÂ?  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3016, '449', 'Technicien ÃƒÂ?  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3017, '450', 'Technicien ÃƒÂ?  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3018, '451', 'Technicien ÃƒÂ?  domicile', '318,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3019, '452', 'Technicien ÃƒÂ?  domicile', '118,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3020, '453', 'Technicien ÃƒÂ?  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3021, '454', 'Technicien ÃƒÂ?  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3022, '455', 'Technicien ÃƒÂ?  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3023, '456', 'Technicien ÃƒÂ?  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3024, '500', 'Technicien ÃƒÂ?  domicile', '268,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3025, '501', 'Technicien ÃƒÂ?  domicile', '158,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3026, '502', 'Technicien ÃƒÂ?  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3027, '503', 'Technicien ÃƒÂ?  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3028, '504', 'Technicien ÃƒÂ?  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3029, '505', 'Technicien ÃƒÂ?  domicile', '58,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3030, '511', 'Technicien ÃƒÂ?  domicile', '268,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3031, '512', 'Technicien ÃƒÂ?  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3032, '513', 'Technicien ÃƒÂ?  domicile', '98,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3033, '514', 'Technicien ÃƒÂ?  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3035, '515', 'Technicien ÃƒÂ?  domicile', '58,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3036, '601', 'Technicien ÃƒÂ?  domicile', '168,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3038, '602', 'Technicien ÃƒÂ?  domicile', '118,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3040, '603', 'Technicien ÃƒÂ?  domicile', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3041, '604', 'Par courrier', '78,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3042, '605', 'Technicien ÃƒÂ?  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3044, '606', 'Technicien ÃƒÂ?  domicile', '88,00'); 
INSERT INTO `wp_model_sub_service` VALUES (3045, '607', 'Technicien ÃƒÂ?  domicile', '88,00');
#
# End of data contents of table `wp_model_sub_service`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_phone_company`
# --------------------------------------------------------


#
# Delete any existing table `wp_phone_company`
#

DROP TABLE IF EXISTS `wp_phone_company`;


#
# Table structure of table `wp_phone_company`
#

CREATE TABLE `wp_phone_company` (
  `pc_id` int(2) NOT NULL,
  `pc_name` varchar(30) COLLATE latin1_general_ci DEFAULT NULL,
  `pc_image` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `pc_hover_image` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`pc_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ;

#
# Data contents of table `wp_phone_company`
#
 
INSERT INTO `wp_phone_company` VALUES (1, 'Apple', 'images/company_model/1367238423apple.png', 'images/company_model/1367238423apple_hover.png'); 
INSERT INTO `wp_phone_company` VALUES (2, 'Samsung', 'images/company_model/1367238780samsung.png', 'images/company_model/1367238780samsung_hover.png'); 
INSERT INTO `wp_phone_company` VALUES (3, 'Blackberry', 'images/company_model/1367238804blackberry.png', 'images/company_model/1367238804blackberry_hover.png'); 
INSERT INTO `wp_phone_company` VALUES (4, 'Sony Ericsson', 'images/company_model/1367238845sony.png', 'images/company_model/1367238845sony_hover.png'); 
INSERT INTO `wp_phone_company` VALUES (5, 'LG', 'images/company_model/1367238871lg.png', 'images/company_model/1367238871lg_hover.png'); 
INSERT INTO `wp_phone_company` VALUES (6, 'Nokia', 'images/company_model/1367238898nokia.png', 'images/company_model/1367238898nokia_hover.png'); 
INSERT INTO `wp_phone_company` VALUES (7, 'HTC', 'images/company_model/1367238922htc.png', 'images/company_model/1367238922htc_hover.png'); 
INSERT INTO `wp_phone_company` VALUES (8, 'ASUS', 'images/company_model/1367238937asus.png', 'images/company_model/1367238937asus_hover.png');
#
# End of data contents of table `wp_phone_company`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_phone_model`
# --------------------------------------------------------


#
# Delete any existing table `wp_phone_model`
#

DROP TABLE IF EXISTS `wp_phone_model`;


#
# Table structure of table `wp_phone_model`
#

CREATE TABLE `wp_phone_model` (
  `pm_id` int(2) NOT NULL,
  `pc_id` varchar(30) COLLATE latin1_general_ci DEFAULT NULL,
  `model_name` varchar(30) COLLATE latin1_general_ci DEFAULT NULL,
  `model_image` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`pm_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ;

#
# Data contents of table `wp_phone_model`
#
 
INSERT INTO `wp_phone_model` VALUES (22, '6', 'Lumia 920', 'images/phone_model/1364292554lumia_920.png'); 
INSERT INTO `wp_phone_model` VALUES (23, '6', 'Lumia 820', 'images/phone_model/1364292578lumia_820.png'); 
INSERT INTO `wp_phone_model` VALUES (24, '6', 'Lumia 800', 'images/phone_model/1364292627lumia_800.png'); 
INSERT INTO `wp_phone_model` VALUES (25, '6', 'Lumia 610', 'images/phone_model/1364292653lumia_610.png'); 
INSERT INTO `wp_phone_model` VALUES (26, '8', 'Nexus 7 LED', 'images/phone_model/1364293836Nexus_7_LED.png'); 
INSERT INTO `wp_phone_model` VALUES (27, '8', 'Eee Pad(10.1")', 'images/phone_model/1364294421Eee_pad_10.png'); 
INSERT INTO `wp_phone_model` VALUES (28, '7', 'One X', 'images/phone_model/1364299399htc_one_x.png'); 
INSERT INTO `wp_phone_model` VALUES (29, '7', 'One S', 'images/phone_model/1364299434htc_one_s.png'); 
INSERT INTO `wp_phone_model` VALUES (30, '7', 'One V', 'images/phone_model/1364299461htc_one_v.png'); 
INSERT INTO `wp_phone_model` VALUES (31, '7', 'HD2', 'images/phone_model/1364299493htc_hd_2.png'); 
INSERT INTO `wp_phone_model` VALUES (32, '7', 'HD', 'images/phone_model/1364299517htc_hd.png'); 
INSERT INTO `wp_phone_model` VALUES (33, '7', 'HD Mini', 'images/phone_model/1364299543htc_hd_mini.png'); 
INSERT INTO `wp_phone_model` VALUES (34, '7', 'Nexus One', 'images/phone_model/1364299578htc_nexus_one.png'); 
INSERT INTO `wp_phone_model` VALUES (35, '7', 'Desire HD', 'images/phone_model/1364299628htc_desire_hd.png'); 
INSERT INTO `wp_phone_model` VALUES (36, '7', 'Desire', 'images/phone_model/1364299655htc_desire.png'); 
INSERT INTO `wp_phone_model` VALUES (37, '7', 'Desire S', 'images/phone_model/1364299678htc_desire_s.png'); 
INSERT INTO `wp_phone_model` VALUES (38, '7', 'Desire Z', 'images/phone_model/1364299705htc_desire_z.png'); 
INSERT INTO `wp_phone_model` VALUES (39, '7', 'Desire C', 'images/phone_model/1364299731htc_desire_c.png'); 
INSERT INTO `wp_phone_model` VALUES (40, '7', 'Sensation', 'images/phone_model/1364299757htc_sensation.png'); 
INSERT INTO `wp_phone_model` VALUES (41, '7', 'Sensation XL', 'images/phone_model/1364299784htc_sensation_xl.png'); 
INSERT INTO `wp_phone_model` VALUES (42, '7', 'Wildfire', 'images/phone_model/1364299811htc_wildfire.png'); 
INSERT INTO `wp_phone_model` VALUES (43, '7', 'Wildfire S', 'images/phone_model/1364299840htc_wildfire_s.png'); 
INSERT INTO `wp_phone_model` VALUES (44, '3', 'Bold 9900', 'images/phone_model/1364300175blackberry_bold_9900.png'); 
INSERT INTO `wp_phone_model` VALUES (45, '3', 'Bold 9790', 'images/phone_model/1364300210blackberry_bold_9790.png'); 
INSERT INTO `wp_phone_model` VALUES (46, '3', 'Bold 9780', 'images/phone_model/1364300225blackberry_bold_9780.png'); 
INSERT INTO `wp_phone_model` VALUES (47, '3', 'Bold 9700', 'images/phone_model/1364300249blackberry_bold_9700.png'); 
INSERT INTO `wp_phone_model` VALUES (48, '3', ' Torch 9860', 'images/phone_model/1364300276blackberry_torch_9860.png'); 
INSERT INTO `wp_phone_model` VALUES (49, '3', 'Torch 9800', 'images/phone_model/1364300300blackberry_torch_9800.png'); 
INSERT INTO `wp_phone_model` VALUES (50, '3', 'Curve 9300 (3G)', 'images/phone_model/1364300332blackberry_torch_9300(3g).png'); 
INSERT INTO `wp_phone_model` VALUES (51, '3', 'Curve 9360', 'images/phone_model/1364300355blackberry_curve_9360.png'); 
INSERT INTO `wp_phone_model` VALUES (52, '3', 'Curve 9320', 'images/phone_model/1364300375blackberry_curve_9320.png'); 
INSERT INTO `wp_phone_model` VALUES (53, '3', 'Curve 8520', 'images/phone_model/1364300391blackberry_curve_8520.png'); 
INSERT INTO `wp_phone_model` VALUES (54, '5', 'Optimus L9', 'images/phone_model/1364300592optimus_L9.png'); 
INSERT INTO `wp_phone_model` VALUES (55, '5', 'Optimus L7', 'images/phone_model/1364300690optimus_L7.png'); 
INSERT INTO `wp_phone_model` VALUES (56, '5', 'Optimus L3', 'images/phone_model/1364300710optimus_L3.png'); 
INSERT INTO `wp_phone_model` VALUES (57, '5', 'Optimus Black', 'images/phone_model/1364300726optimus-black.png'); 
INSERT INTO `wp_phone_model` VALUES (58, '5', 'Optimus One', 'images/phone_model/1364300744optimus-one.png'); 
INSERT INTO `wp_phone_model` VALUES (59, '5', 'Optimus Nexus 4', 'images/phone_model/1364300768optimus-nexus_4.png'); 
INSERT INTO `wp_phone_model` VALUES (60, '4', 'Xperia V', 'images/phone_model/1364301043Xperia V.png'); 
INSERT INTO `wp_phone_model` VALUES (61, '4', 'Xperia J', 'images/phone_model/1364301162xperia J.png'); 
INSERT INTO `wp_phone_model` VALUES (62, '4', 'Xperia T', 'images/phone_model/1364301187XperiaT.png'); 
INSERT INTO `wp_phone_model` VALUES (63, '4', 'Xperia GO', 'images/phone_model/1364301209Xperia-GO.png'); 
INSERT INTO `wp_phone_model` VALUES (64, '4', 'Xperia P', 'images/phone_model/1364301233Xperia-P.png'); 
INSERT INTO `wp_phone_model` VALUES (65, '4', 'Xperia S', 'images/phone_model/1364302555Xperia-S.png'); 
INSERT INTO `wp_phone_model` VALUES (66, '4', 'Xperia Arc', 'images/phone_model/1364302581xperia_arc.png'); 
INSERT INTO `wp_phone_model` VALUES (67, '4', 'Xperia Arc S', 'images/phone_model/1364302618Xperia-Arc-S.png'); 
INSERT INTO `wp_phone_model` VALUES (68, '4', 'Xperia X10', 'images/phone_model/1364302646Xperia-X10.png'); 
INSERT INTO `wp_phone_model` VALUES (101, '1', 'iPhone 5s', 'images/phone_model/1363962217iphone_5s.png'); 
INSERT INTO `wp_phone_model` VALUES (102, '1', 'iPhone 5c', 'images/phone_model/1363962218iphone_5c.png'); 
INSERT INTO `wp_phone_model` VALUES (103, '1', 'iPhone 5', 'images/phone_model/1364290077iPhone_5.png'); 
INSERT INTO `wp_phone_model` VALUES (104, '1', 'iPhone 4S', 'images/phone_model/1364290101iPhone_4S.png'); 
INSERT INTO `wp_phone_model` VALUES (105, '1', 'iPhone 4', 'images/phone_model/1364290136iPhone_4.png'); 
INSERT INTO `wp_phone_model` VALUES (106, '1', 'iPhone 3GS', 'images/phone_model/1364290170iPhone_3GS.png'); 
INSERT INTO `wp_phone_model` VALUES (107, '1', 'iPhone 3G', 'images/phone_model/1364290228iPhone_3G.png'); 
INSERT INTO `wp_phone_model` VALUES (108, '1', 'iPad Retina', 'images/phone_model/1364290351iPad_retina.png'); 
INSERT INTO `wp_phone_model` VALUES (109, '1', 'iPad 2', 'images/phone_model/1364290268iPad_2.png'); 
INSERT INTO `wp_phone_model` VALUES (110, '1', 'iPod Touch 4G', 'images/phone_model/iPod-touch-4G_1.png'); 
INSERT INTO `wp_phone_model` VALUES (111, '1', 'iPod Touch 3G', 'images/phone_model/iPod-touch-3G_1.png'); 
INSERT INTO `wp_phone_model` VALUES (201, '2', 'Galaxy s4', 'mages/phone_model/samsung_galaxy_s4.png'); 
INSERT INTO `wp_phone_model` VALUES (202, '2', 'Galaxy S3', 'images/phone_model/1364290760samsung_galaxy_s3.png'); 
INSERT INTO `wp_phone_model` VALUES (203, '2', 'Galaxy S2', 'images/phone_model/1364290804samsung_galaxy_s2.png'); 
INSERT INTO `wp_phone_model` VALUES (204, '2', 'Galaxy S', 'images/phone_model/1364290835samsung_galaxy_s.png'); 
INSERT INTO `wp_phone_model` VALUES (205, '2', 'Samsung Note 3', 'images/phone_model/samsung_note_3.png'); 
INSERT INTO `wp_phone_model` VALUES (206, '2', 'Galaxy Note 2', 'images/phone_model/1364290868samsung_note_2.png'); 
INSERT INTO `wp_phone_model` VALUES (207, '2', 'Galaxy Note', 'images/phone_model/1364290918samsung_note.png'); 
INSERT INTO `wp_phone_model` VALUES (208, '2', 'Galaxy Nexus', 'images/phone_model/1364290950samsung_galaxy_nexus.png'); 
INSERT INTO `wp_phone_model` VALUES (209, '2', 'Google Nexus S', 'images/phone_model/google_nexus_s.png'); 
INSERT INTO `wp_phone_model` VALUES (210, '2', 'Galaxy Ace', 'images/phone_model/1364291038samsung_galaxy_ace.png'); 
INSERT INTO `wp_phone_model` VALUES (211, '2', 'Galaxy Tab 2 (10.1")', 'images/phone_model/1364201248samsung_galaxy-tab_2_10_1.png'); 
INSERT INTO `wp_phone_model` VALUES (212, '2', 'Galaxy Tab 2 (7")', 'images/phone_model/1364291611samsung_galaxy_tab_2(7).png'); 
INSERT INTO `wp_phone_model` VALUES (213, '2', 'Galaxy Note (10.1")', 'images/phone_model/samsung_galaxy_note10-1.png'); 
INSERT INTO `wp_phone_model` VALUES (214, '2', 'Galaxy Tab (8.2")', 'images/phone_model/1364292303samsung_galaxy_tab_8-2.png'); 
INSERT INTO `wp_phone_model` VALUES (215, '2', 'Galaxy S3 mini', 'images/phone_model/galaxy_s3_mini.png');
#
# End of data contents of table `wp_phone_model`
# --------------------------------------------------------

